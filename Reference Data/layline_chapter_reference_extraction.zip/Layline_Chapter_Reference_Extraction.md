# Layline Chapter Reference Data Extraction

OCR extraction from all uploaded PDF files with "Chapter" in the filename. Text is organized by source file and page.


---

## Chapter 3 1_2.pdf


### Page 1


CHAPTER 3:

STARTING STRATEGY

3.1 InTRODUCTION: ELEMENTS OF STRATEGY

3.2 First LEG STRATEGY
3.3 THe SET OF THE LINE
3.4. Maxine 1T WorK
3.5 APPROACHES

3.6 CONCLUSION

waa oncanmiltictoad
(alerts ord readings 0+ (odio df

FF merce smenatds
te vgn (readics ee

: Vora Chacht - uu Gest
Wore no Bae due Udall
frocleter gmatl ef — YR
Vows. owtiy coudcter ~
Jeon tly $0 Slaw © reat =
Bye On VON



### Page 2


ae

i
Fig, 2- Simply put, start right 10 go right, start left to go left,
and start in the middle to keep your options open.

Starting strategy means deciding where on the line to
start. When deciding where to start, consider three factors:

1. Race Strategy for the First Leg.

2. The Set of the Line.

3. Making it Work.
Race Strategy will effect starting strategy, as we shall see.
‘The Set of the Line refers to the angle of the line to the wind.
In Making It Work we will look at balancing race strategy,
line set, and other concerns.

3.2 First Leg Strategy

Race Strategy for the first leg. is the first factor to
consider in deciding where on the line to start.

If strategic considerations suggest sailing up the right
hand side of the beat, then a start at the right end of the line is
preferred. By starting at the right end we are free to tack and
20 right immediately after starting. Clear air is relatively

@
oOo’
Left-Favored Uh o
‘No favored end

igh Favored

Fig. 3 - The upwind end of the line is the favored end.

unimportant, as we will be tacking away. Freedom to tack
and go right is the first priority.

If our race strategy says go left, then a start near the left
end is called for. The advantage here is not as strong as
starting right to go right. More critical than the exact position
is clear air, and the freedom to continue to the left unim-
peded.

If there is no clear advantage to either side, then a
midline start is indicated. There are several advantages to a
midline start. From a starting perspective, itis often the
easiest and least crowded place to start. From a race strategy
perspective, a midline start gives the greatest flexibility, as it
offers the freedom to go either way. For further discussion of
Upwind Strategy, see Chapter 7.

‘Simply put: Start right to go right, start left to go left,
start in the middle to keep your options open (Fig. 2).

Chapter 3: Starting Strategy Page 15



### Page 3


x

YAY)

Right-Favored

\

\ Left-Favored &

Fig. 6 - You can determine the favored end by observing
other starts. If the fleet comes off the line bow to bow, the
right is favored; bow to stern, then the left is favored.

3. Observe other starts. If the fleet lines up bow to bow
off the line, then the windward end is favored. If the
fleet lines up bow to stern, then the pin end is favored
(Fig. 6).

4, Sail past one end of the line closehauled, and observe
the relative distance as you pass abeam of the other
end. This offers only a rough measurement.

No matter which technique (or combination) you use, you
must recheck the line if the wind shifts. The first technique is
preferred because it allows you to quickly recalculate after a
wind shift. It also allows you to determine how many degrees
off square the line is set, and the magnitude of the advantage,
as we shalll see.

Fig. 7 - You need not start on port tack to take advantage of a
left end favored line. You will realize the advantage when you
tack.

Q2. How Much Difference Does It Make?

‘Two boats starting from opposite ends of a square
will be equally far from an upwind mark. If they were on
converging tacks, they would hit bow to bow. If the line is
not square to the wind, then one will start ahead, as shown in
Figure 3.

You don't need to start on port tack to take advantage of
‘a pin-favored line. You will realize the advantage when you
tack to port (Fig. 7).

How Far Ahead?

For a line 5 degrees off square (most are), the advantage
is 12.5% of the distance between the boats. Ifthe line is 10
degrees off square (not uncommon), the advantage is 25% of
the distance between the boats.

Chapter 3: Starting Strategy Page 17



### Page 4


i 4

Fig. 10 - Pick a section of the line for your start. Your exact
starting spot will depend on how the start plays out tactically.
Each section has many names

3.4 Making It Work

Where to start? In addition to our first leg strategy and
the set of the line, there are a collection of other factors
which we will lump under the heading of Making It Work.
Wind shifts, crowding, and clear air are among the issues we
must consider.

‘A start near the favored end, but clear of congestion, is
best. It provides the advantages of the favored end without
risking clear air and the freedom to maneuver and accelerate,
Remember—you don’t need to win the start the win the race;
you just need a good one. We'll look at a couple of situations
to get a feel for how to decide where to start.

k a Section

You don't so much pick a spot on the line as we pick a
section: left, middle, or right (Fig. 10).

Midline Starts

Unless there are strong reasons to push toward an end,
midline start is the best choice (Fig. 11). The advantages

% #
a
Vaw® 8Y

Fig. 11 - Midline starts are preferred if you do not have
compelling reasons to push toward an end.

include minimal crowding on the approach and strategic
flexibility once you clear the line. You can set up for your
start with a variety of approaches (details in the next section),
and you can often get a jump by avoiding midline sag

Starting at the Favored End

When your choice is one of the ends, it is best to target
near—but not right at—the favored end. A favored end draws
crowd, and you will get much more consistent starts by
staying out of crowds. Slide down the line just far enough to
clear the crowd, and you will have a much easier time getting
€ good start. In fact, you may end up with the best start, as
the boats in the crowd deprive each other of the air and room
necessary to accelerate off the line.

Even when one or more boats do get good starts right at
the favored end, many more are buried, By hedging toward
the middle of the line, you dramatically increase the odds of
getting a good start.

Chapter 3: Starting Strategy Page 19



### Page 5


3.5 Approaches

The next step, after deciding where on the line to start, is
to decide how to get there. We must select our approach. The
approach we choose will form the basis of our starting plan.
There are a variety of approaches available, each with advan-
tages and disadvantages. It is best to be well-versed and
comfortable with each, so we can select the one which best
fits the prevailing strategic and tactical circumstances.

‘The approaches covered in the following pages include:

+ Reach Out and Back

‘+ Half Speed Approach

‘+ Triangle Approach

* Vanderbilt Start

+ Port Tack Approach / Pin End Start
+ Port Tack Approach / Midline Start
+ Port Tack Start

+ Luffing Start

Elvstrom Start

+ Dip Start

Reach Out and Back

‘The most commonly used approach is the Reach Out
and Back. Often the fleet moves én mass, reaching out on
port tack one and a half to two minutes before the start. At
around a minute everyone tacks back and reaches to the line,
trimming up to closehauled for the last fifteen to thirty
seconds.

‘Advantages

‘The Reach Out and Back is simple.

Danger!

This approach creates clumps of boats. You want to
avoid crowds. This is also a barging set up. There are better
approaches.

‘The Secret to Success

The key is to hold a position with clear air in the front
row. Try to leave room for acceleration ahead and to leeward
by sweeping down and luffing up, effectively stalling while
those ahead sail further down the line. Then use the space to
accelerate. The biggest problem is keeping the space for
yourself. Some boats will try to go over and under you to
Steal it; others will come in on port tack.

Chapter 3: Starting Strategy Page 21



### Page 6


‘Triangle Approach

‘The Triangle Approach avoids the problem of searching
for room to tack or jibe in a crowd. Initiate the triangle at the
spot from which you want to start, Sail from your starting
spot on a port beam reach, along the line and its extension,
Next, jibe to a starboard broad reach and sail down to the
final approach layline, Finally, head up to closehauled for the
run at the line. Each leg of the triangle is of about the same
duration-usually 30 to 45 seconds each for a 30-foot boat,
scaled up or down for larger or smaller boats.

Advantages

The turn onto your final approach doesn't slow you
down and doesn't take much room. You are also very maneu-
verable as you reach in, The triangle approach allows more
room to accelerate than other approaches. Recommended for
light to moderate air. Works anywhere on the line.

Danger!

Don't be late. If you are late, you may not have time to
get through the crowd and around the bargers.

‘The Secret to Success

If you fear you are running late on leg two, cut the
comer, Often legs two and three turn into one long continu-
ous sweeping turn

Vanderbilt Start &,

The Vanderbilt Start is a
popular but flawed approach. The basic plan is to sail away
from the line on a port tack broad reach on the reciprocal of
your starboard tack closehauled course. You then tack or jibe,
and return to the place from which you departed.

Advantages

‘The attraction of this approach is its simplicity.

Danger!

‘The problem? It doesn't work. At least not in a competi-
tive fleet it doesn't. The flaw is that you cannot make your
turn at the appointed place and time because other boats will
be there; and should you somehow find room for your turn,
you will lack the clear air necessary to accelerate.

The Secret to Success

Ina small, uncompetitive fleet you might succeed with
this start, but you would do better to practice a technique
which will be of more use when you move up.

If you insist on using this approach, remember that the
speeds out and back are not necessarily equal, and you must
allow sufficient time for your tack or jibe. The Vanderbilt
start was developed for match racing and is used there with
some success. Congestion and disturbed air make it a poor
choice for fleet racing.

Chapter 3: Starting Strategy Page 23



### Page 7


Port Tack Start

Approach the line on port tack, shoot through a gap, and
cross the fleet. This approach requires great timing and
nerves of steel.

Advantages

If the line is port end favored and the right-hand side of
the course is advantaged, a port tack start lets you blast off
toward the favored side.

Danger!

Poor timing or unsteady nerves can lead to disaster.
Other boats doing the same thing can make it messy.

The Secret to Success

‘Timing, anticipation, and a bail out plan. It is always
better to duck boats than to slam in a last second tack. Look
ahead as the fleet sets up and pick your gap. Close reach with
lots of speed and trim into your gap. Be ready to search for a
new gap on a moments notice. An adverse current can hold
up the fleet and make it easier to succeed with this approach.
(It has also been suggested that this approach be reserved for
times when you are sailing someone else's boat.)

Luffing Start

Select a spot and luff near the line. Trim for speed in the
final seconds before the gun. The object is to secure a spot on
the line.

‘Advantages

In a crowded fleet on a short line, this is one way to
secure a spot in the front row.

Danger!

‘The dangers are not leaving enough room to accelerate,
and having other boats sail over and under you before you
can respond.

The Secret to Success

Preserve as much space as possible ahead and to lee-
ward, while preserving clear air and holding your space in the
front row. You'll need this room to accelerate.

This approach is popular in dinghies and windsurfers, as
‘well as in some one-design keelboats, particularly in large
fleets where it is difficult to find room on the line. It is not
practical for any but the lightest keelboats. If your boat is
relatively light for your fleet, set up to leeward of the crowd,
luff everyone, and then blast off while others wallow.

Chapter 3: Starting Strategy Page 25



---

## Chapter 3 2_2.pdf


### Page 1


CuaPpTER 3: STARTING STRATEGY

3.1 Introduction: Elements of Strategy

‘The start of a sailboat race is one of the most exciting
and demanding moments in sports. Starts require judgement,
timing, and teamwork. They require an understanding of
wind and weather, and knowledge of strategy, tactics, and
rules. Starts demand dexterity at close-quartered maneuver-
ing. Finally, starts require the ability to stay cool and concen-
trate in an environment packed with distractions. These
requirements create a uniquely thrilling, and at times baffling,
challenge.

Given so many areas of concern, our success will de-
pend on our ability to prioritize—to determine which factors
are critical to a particular start. The goal is to hit the starting
line at the gun at the favored end, with speed and clear air,
and freedom to maneuver at will. A good start is one which
finds us in the front row, free and clear, not just at the gun,
but a minute later, after the sprint off the line.

To succeed we must create order from the chaos of the
starting line. First we need a Starting Strategy—a game plan
based on the information gathered during our race prepara-

jon, Once we have a plan, then starting tactics will be used
to implement the plan. This chapter will look at starting
strategy—how to make a plan. The next chapter will show us
how to execute the plan.

‘The importance of a good start cannot be understated.
While it is not necessary to win the start in order to win the
race, a good start is usually required. A good start gives the

Fig. 1 - Starts are chaos. To succeed, we will first
need a starting plan (strategy). Then we will need to execute
the plan (tactics) despite all the distractions. A good start is
one which finds us free to pursue our race strategy a minute
or two after the gun.

freedom to pursue strategic objectives without interference
(Fig. 1). A poor start means compromising strategy and
setting off in the wrong direction, or sailing in bad air to
pursue strategic goals.

In this chapter we will concentrate on upwind starts.
Chapter 6 covers Offbeat Starts.

Page 14 ai Performance Racing Tactics



### Page 2


Fig. 4 - To find the favored end, compare the compass course

of the line to the wind direction. If the line is 90° from the
wind then the line is square. If the wind is less than 90° from
the line you are headed toward the favored end; greater than
90° and you are sailing away from the favored end.

3.3 The Set of the Line

The set of the line means the angle of the line to the
wind, Since we are racing upwind, there is an advantage to
starting at the end which is furthest upwind—we call this the
favored end. A starting line set perpendicular to the wind
does not have a favored end. When the line is not square to
the wind then one end—the upwind end—is favored (Fig. 3).

‘Two questions come to mind:
QL. How can you figure out which end is favored?
Q2. How much difference does it make?

QI. Which End is Favored?
‘There are several ways to find the favored end of the
starting line. Some are better than others:
1. Compare the compass bearing of the line to the wind
direction. You can then plot which is the favored end.

Fig. 5 - You can determine the favored end-and ruin your
sails-by luffing into irons, either on the line or off one end.

Once you know the bearing of the line, you can
update your calculations as the wind changes. For
example, in the illustration, the line is set at 320°. If
the wind direction were 230° the line would be square
to the wind. With the wind at 240” the right end is 10°
favored. With the wind at 220° the left end is 10°
favored (Fig. 4).

2. Luff into irons on the line (or off one end).
Sight across your boat (using the traveler bar,
your sight will be square to the wind. While this is a
Popular technique, I recommend against it for two
reasons: First, you must redo it every time the wind
shifis; second, itis hell on your sails—the worst thing
you can do to them (Fig. 5),

Page 16 - Performance Racing Tactics



### Page 3


A
Od.
OY

Fig. 8 - For a line that is 10° off square, the advantage >
«the favored end is 25% of the length of the line—
That's 5 boat lengths on a line 20 lengths long!

On a typical starting line, 20 boat lengths long, and 10°
off square, the advantage from end to end is 5 boat lengths!
AS length lead off the line is no small matter—clearly the set
of the line is an important factor in our decision where to
start (Fig. 8).

Mark Position and Favored End Not Related

Not so clear is the fact that the position of the windward
mark does not determine the favored end of the line. Boats
starting at the upwind end will be in the lead, and will be able
to cross boats starting from the downwind end and lead them
to the mark. Even though the downwind end may be closer
as the crow flies, it will be further in upwind sailing distance
(Fig. 9).

Fig. 9 - The position of the windward mark does not determine
the favored end of the line. The set of the line relative to the
wind, not the mark, determines the favored end.

The position of the mark may be a factor in our first leg
strategy, and thus may impact our decision on where to start,
but it does not determine the favored end of the line. The fa-
vored end is a function of wind direction—not mark position.

Page 18 Performance Racing Tactics



### Page 4


Fig. 12 - To go right, try a start just below
y the crowd at the boat end. You can get off
the line with clear air and be a leader

going to the favored side.

Go Right!

If your goal is to start right and tack out immediately, it
may be worth it to go for a start right at the boat. If you get
the perfect start congratulations—and more power to you!

Even if you end up in the second row it's OK, since
you'll be tacking out. Sounds good—but in reality the front
row boats will be tacking immediately, and you will have to
delay your tack to avoid tacking in bad air. A position in the
front row a little bit down the line will allow you to sail full
speed until you do tack, and may actually allow you to tack
sooner! Plus, you avoid the hazards of barging (see Chapter
5: Starting Rules for more on barging), and of other crowd-
related problems (Fig. 12).

How badly do you need to be the first boat to tack out?
‘What are the odds of pulling it off? Can you afford the risk
of being buried? How does that compare with much higher
‘odds of being the third boat to tack by starting down the Tine?

Fig. 13 - To go left, a start with clear "
air is essential—you can't tack out.

Once again, setting up just clear of

the crowd helps assure a good start.

LS ~
Sa

Go Left!

If everything favors the left side, then get ready to
battle! There is little margin for error in these starts, and few
spaces in the front row when the pin end is favored. The boat
furthest left may be the only one with clear air, but any
hesitation may allow the next boat up the line to roll over the
top. Again, a start part way up the line may be the easiest way
to get the second best start (Fig. 13). You'll be able to create
space for clear air and room to accelerate. In fact, a jam up at
the pin may leave you with the best start! We'll look at the
tactics of this position in detail in the next chapter.

Hit the Shifts

The best start in shifty conditions is one which allows
you to sail to the shift with speed and affords you the room to
tack when the shift arrives. Blast off from the middle of the
line, tack if the next shift is coming from the right, and sail
fast. When racing to a shift, speed is more important than
pointing, and room to tack is critical if you are going to take
advantage of the shift when you get to it. Stay clear of
crowds and sail fast.

Page 20

Performance Racing Tactics



### Page 5


Half Speed Approach

The Half Speed Approach is popular and effective. Sail
away from a spot on the line and turn back early to allow for
the congestion and bad air of the fleet. Once headed for the
line, speed is adjusted to properly time the approach. The
object is to approach at half speed with final trim coming
early enough to reach full speed and hit the line at the gun.

Advantages

The half speed approach is relatively simple and reli-
able-a good choice in moderate to heavy air. It gets you set
up early and puts you in the front row. This approach is
effective in any part of the line. For a right-hand end start,
you can bottle up the crowd reaching in above you.

Danger!

Tacking kills speed. Jibing carries you away from the
line. Allow plenty of time for your turn. At the same time,
beware setting up too close to the line, without room to

accelerate. Also, avoid this approach in light air, or in a heavy
boat which is slow to build speed.

Another problem with the half speed approach is that
‘you must sail on port tack into oncoming starboard boats and
find room to make a full 180° turn.

The Secret to Success
important to maintain at least half speed throughout
the approach, in order to be able to accelerate readily to full
speed. In big fleets there is rarely sufficient room to be fully
accelerated at the gun. The key is to hold a position with
clear air in the front row. Boats tend to push to the line early
to keep clear air. While you might prefer to hang back to
leave room to accelerate, but you have to stay in the front,
row to keep clear air,

Page 22 Performance Racing Tactics



### Page 6


Port Tack Approach for a Pin End Start

From the starting pin, sail up the line on port tack,
toward the fleet. As you near the pack of starboard tack boats
working down the line, tack to leeward of the crowd and lead
them back toward the pi

‘Advantages

A port tack approach allows you to set up late and is the
‘easiest way to judge the timing for a pin end start.

Danger!

Where do we begin? There are the obvious port-star-
board and tacking-too-close risks, the danger of not finding a
space to tack into, and the need to tack and accelerate late in
the sequence. This can be particularly difficult in light air.

The Secret to Success

This is an excellent set up for a pin end start. Note the
time as you sail past the pin, and keep track of the split time
as you sail up the line. It may be necessary to duck some
arly starboard tackers and then jump into the next gap.
Obviously, good crew work is essential to a smooth tack and
quick acceleration. Your approach should set up three to four
boat lengths from the line. Also, to carry speed into the tack,
head up and trim on port before tacking to starboard.

Port Tack Approach for a Midline Start

As with the pin end start, come in from the left end of
the line about three boat lengths below the line. As you near
the pack of starboard tack boats, duck the early bunches and
tack into a gap.

Advantages

‘A port tack approach allows you to set up late and avoid
clumps of boats which have set up early. It protects you from
attack, and allows you to attack others if you choose.

Danger!

‘As with the Port Approach for a Pin End Start, there are
right-of-way hazards and the challenge of tacking and accel-
erating late in the sequence.

The Secret to Success

This is a great set up for a midline start. Your tactician
should be looking ahead to find a gap. Once you find a gap,
the key is to tack into the windward edge, leaving room to
drive off to leeward and accelerate. Allow plenty of time to
search out a gap, tack, and get up to speed. Again, good crew
work is essential to a smooth tack and quick acceleration.

Page 24 Z Performance Racing Tactics



### Page 7


Elvstrom Start

Thisis an approach I observed Paul ’S
Elystromusing in shifty conditions. He positioned
himself to leeward of the R.C. Boat and luffed on the star-
board tack layline. If the last shift before the start was a lift,
he sailed it to start at the favored boat end of the line; if the
last shift was header, he sailed it to the favored pin end.

Advantage:

In shifty conditions, this approach allows a last minute
decision based on the final shift before the gun.

Danger!

Timing is tricky. Be sure to allow enough time to get to
the line in a header—and be sure you will be able to fetch.

The Secret to Success

‘The beauty is that while the rest of us luffed on the line
and battled to hit the first shift after the start, Elvstrom was a
step ahead, hitting the last shift before the start.

Dip Start

Approaching from the wrong side of the line, find a gap
and dip into it from above

Advantages

‘When the line is difficult to approach from below due to
light wind and strong current, you drop into a front row seat.

This approach is useful only when the line is difficult to
approach in the conventional way.

Danger!

‘The danger of being over early or of being luffed by
Jeeward boats limits the usefulness of this approach. Also
illegal if the One Minute Rule is invoked.

The Secret to Success

The Dip Start can succeed in light air and adverse
current. A large R.C. boat with the line site near the bow
increases the chances of success, as does a pin favored line.

3.6 Conclusion

Starting strategy is a game of choices, requiring a
balance between overall strategic goals, line set, and crowd-
ing. Once the strategic decision has been made on where to
start, we must select an approach appropriate to the condi-
tions. This strategic plan lays the groundwork for our start.
‘We now turn to Chapter 4: Starting Tactics, to turn our plans
into reality.

Page 26 Performance Racing Tactics



---

## Chapter 4 1_2.pdf


### Page 1


i . ps yy = Ov x ie srs
a [Praia eo ra oman
= Lperpmgn- pawn / own 7 ii
4 PRAM [om WIM
we» ear eI
matharenrelle - pyre my 7") ninygp

prepon~ Raper ys very rime SHAMS amore) A
Srey Bun rrOId fe ca) LS - pep pS ies eS
Pra prane}p AY ieee puro epyed Aaroln dh vn} heap 2991 vo POL
ey, yy = 2
# whi punt MP Vane 3 5 Vespny ear eoteey e
yop. Pree pon, -hthop pomerereahy ats pancho GRMN S
Opp 47 4-40] -» bea “> Awrso REVOSYY -OR LAP £

~yucqyn brad - wyypop) 9%
SNOLLSANO ZING ONUAVLY LP
vaalemre hywmde 4% STIS ONIATING 9b

SHPO AMO AD WOH NOISNIINOD Sr
hanes ll x STIVILd £F
yey JIVLS FHL, Sb
+ : NOLLVAYOAN] IVI, TF
: NOLLNGOMLNT ["f
pugmp ado ins t
Parveen Pum)
SOLLOV I, ONILAVLS' 7 ff MALAVHD
puripsh jou
Yreprapnprenees) PM de “A

B. SS WA Sinner neo won
oFap ug /bos/ mpm eo tap momen aa

pwon /epmyg — *7hysdsvapoy has/teney AP



### Page 2


62 a8 souany Supsnig.: 4a1douy

sun agp yun youg yay 249 PJoy O1 aU B4p Jo prEAaa| On TIS
“says aut © axe no J souuostad somo.) 2Oey 012108121095

-rondeyo snotaaid ayp ut paquasap soyseord
-de aup Jo U0 Woy asooyD o} podu [IM am ‘uEjd BupIS
no x0, “Leys sno aynoaxa sn day [fM WoREWOyU NTI SUL,
‘¢'99U19}21 AATUYOp v 490 Jo|fe OUI
‘amp Jo sXe aun “yoroudde yeury snok uo ywoq sonTUTLHO
auf) mau are nos J] “juEA\ am WHA axe (pud uid 4p JO
ywoq sor}oads 40 180g saapnf v se Yons) 10g pazoysUT

ssauypso] ays Y9UD ~ AZ
“auyy ays aun - 07
“foo ma s1 pua auo fo mays sn08 uoyss wa49 iar ee ee oe
‘uy ay 4t02 nos day 9 S1Y Bs UH] HL
ai ie “spua ays fo sists aut 125 - 22 “Std

as Se ca

ae SVT
Sap e

+ 5 paxmpunep, $20,490)
}) Gur

are ae DOW
i ater F

%,



### Page 3


re 280d

anony Susans :p103d0y

nouns ayeoqo09e 0} woo! aXe 3H TE BU 2M OF 280}9 O01

aye wort seg ‘2uH au} 0} 278979908 0 ODE TIA EG PLOW

‘oy iueas no “OUUE DUIES at TY “AYEIA|BOON O HNOWLEP Ste om.

‘peg ont fey nos J] "NOK punose esoul uaao Mog ok coax
‘01 1uEA NOK “Ie swa[D dooy Or jueyodut st uy] Oy) VON
apy 1ea[ davy OL “Ss

(jBuuaa1s

-xgao ye ywas8 Wh] aU [fo MAH KYA) "HE Teo} pur aonds Sur

-_aqrasaud ‘Keyne sxupo daoy (EM Aqpeanen9 Suna poads nok

doay “(J Bq) 2ournstp wax Buys pur Supsoays-1000 Xq st
‘umn exo Jyo wing 07 Kem 21199 v “UaOP MOPS WEAN JME
aun, WM OL “P

‘aWe] 00} st uNT

ogy ae Surunuey, “Pood yay ve aU ou AL nos os yovosdde sok

uty," paau nO UOYN WN [ng avEy NOK Os KIse LEN 10}
qyea—tousd w win oy sum Bu © SOyeD HEED soquisUtay,

“au pry 08 Ko
aanoaffo un sy Suusoarssaag - £ Put

“(9 Big) prema 01 aoeds Burasasaud pur dn mog ay) Surpjoy
Suupay JoyTWIM SayaUd SIU], “POUL UTPU OYD daay pur yay qt
‘ayn gyn *yoeoadde anoX Sump UMOP Mojs oF PI n0K JL
paads [osju0D Of, “€
+(g ‘B1g) premputm 01 sieoq spun
dn Suryourd £q woox amas no, are peg owt UMop SurLES
Jo 108uep aup plone pur Apyoinb azo! ayesafa0o" und NOA “ovds
‘a[qnop v Suir Aq “premoay Woy 2ouds9y 1911 Aue axeH 1,4OA
‘NOX os “UIs auf saype 40} Soeds yp Jo L4Dd aaws 0 st [ROR NOR
-poads jny 01 ayes9]9998 pue Jo DAUIP o1 a0eds stup Jo Zand as
uot NOK, “premaa| 01 aonds a/qnop & aiwou9 st yovosdde peuLy
ap uo op ueo nog Sump weodur sou apsurs ayp scey.teg

(aav sbodeud ) ae. wooY A194) OL ZT
“paody ini deis nox day {ya yoryas yovordde

euy a4p Suumnp asn ura NOX sonbruyoor je1OAss axe a1,

‘ayosa]a990 01 fo ase WaHLL
cdn azaonbs ssuif ‘woos ava? of - 6 “Sty

woos ayvaua sdjay pun dn swoq ays sdaoy sr

sma ermenry Pret dyyrg 20) a

wt

-ysarf qu ayn ng ‘paods jousuos oy - 9 “Sty

pred noe dona i ears — db yoy, VOD —

pom Hoe

ql

Ime

p Asp ogra apo sh ay

pop pow 2%



### Page 4


g¢.230d

sonany Sumavis. :ps2idy.9

(gat uop:

cyoseas we sueys 78 uordureyD 1991] 94 WOU JsINOK pun}

nok sath sou} [8 HOE JpuoN NOK SOACU EPL) OU

‘up yo Burwod aouaso}s24u $89] JO pasnsse 24 [1 no ‘s1e0q

xoys yale osinos punouins Ue nos JI “(ZIBte ) Aqueau do yas.
vy moyjeuugsseu, & Puy oS} anbruyoor [ajasn Z9qNOUY
MOTTCUTYSILIA! & AEON WEIS °6

‘ands anof aasasaud

pure au 4 01 Kem oanioagso We SE STL ‘umop pur dn suum Sup
Pijooms wala st £souIO) NOK Toa}ONM Ww NOK Kem FOMOUY

uty S08 [Thm NOK

«dn unin nox sy “weanp # 24 01 YBNOUD 38) NOK YINOALP 2ALP OY

ayqe 291 HoH 1e0q PAPOIES axp PU “WHY ONO DAL nok 010}9q

Meads ano ou aye19,990" PUB AH 01 dIAP 24 A.4om 1949H1 HOM

avy 20nd sno€ oyu Sup saxno wage ABOM HOP UeMN SEP
euy ano uo poads piing or Putas KprayTe NPY NOK IT

‘moypounysapu D 409u LOIS - ZT Bk

ham

“(qe 11 “Bty) ooeds anf anes 01 21g 99 PINOYS NOK Ing ‘9AouL
SiKp MEA Yooy Op JJo PrEMpUIM 0} ogyIOU INK 19] eu
nog “dn 0g sno€ SuLNg 0} J940 way o4p INd pure prey UEC
‘up unin ‘passed sey reastp aip 20uQ “pawavoo} ueYA JOU “IEA
putas 01 aoeds aup ayer Aeur soar pukoguers oup [4a “Our
‘up UNOP anUTUOD Pinoys Wog YorI-HOd ay “SIowUNY amnsean
‘af Jo autos prnoys stUp “(oan 10} YBnouD Ziq) aBny st aoeds
au ssaqun ‘sonds snoK Sso1oe yWoq snOK YoIasIs pue UMOP MOG
no wan ‘Suygny sires IAA cuOHISOd nok pusyop NOx UD NOH
ur mo 01 aovds v 105 Suryoo| ‘sways SuPfonp J9YorI PrwOGuEYS
F298 nos J0 ‘ods sno Sur9ca ‘uy axp UMP SuITERS 10g
‘yor1 od v 29s nok asoddng ‘aut a4p oF ysep peut EU anoK
ayou nos axojoq “Bung ‘aur Buy Ly ase NOK ay uoddey
‘eur stu. “Keave 1 [BOIS pInom Oya asoup wos} 11 pudsap 01 ane
nut nox *premaa] 01 ao0ds v ptm dn 39s a1 NOK 29
aaedg anof purja(l OL, *8

‘{ydeoys dn poay uoys pun ‘ssod wy 19] 10 ‘nos anoqn
tn wy aany ‘syo0100 yAnys Yo! pavoqunrs v UayAK - qT SLL
“Buffing sjivs anos yitat aapds anos sso4s0 yp0q nok ayDI04
saypvod yoor-uod v wouf aands amok puafop of - VET St

Mt
epee qui ty >I ay)

gy KORA we | fae
ronwh VY

poy |-verdn g NEN  o
AporaaTO

4 rebS OM) 9 '

ths (anos, praman yvodsynn"O x

uns 99900 248
pv HL AUS

Oy pane)
eo ae De



### Page 5


pessoas

souany Sunanig :p sardoyy

(g1 Sta) ‘arqenear sooeds yous j,uore

axauy 3} uy 2tp dn anuruoo oq] “Aja Yong wan) wou Sut

xds omni tuo axe axaup Jt - peoye sdes ou)

«dv 109 Suryoswas ‘ouyy ayn dn Furyovar
‘oog aayp Jo party sup ‘yaoxdde your wod v wo nox
foueae, ONE

(L1 1g) pua saypo a4p Uo no WHO

youn Jo Anuogd aney nok 2uns axe nok ssayun YONP 1.40 At

"sg 30} papeat| oq anok daay 0} Jabs St soo tot Keul

sae yop 01 ets no 20u9 ‘PUod FunTers ste > PABOgEs
‘atpo Jo Sta1s BupyoNG] "YP Psvrogrels UO ‘suoddey sty.
‘Kea BUOIAA a4 BULOD IYBNED Jo UOS “7

saxupop4 ou a1 a4ays fi S'UD9
yng winy pun - sannds 21qoqo4D a4 01 1004
ag dn yosow ypoesdde yoo! Hod 9 UO - 81 Std

ww ee

XS aeeme

QB

aprs.soyro ay —
no auog 01 awn fo Suajd aavy nos aans
wgabo aun nos fi siv0q yonp 14uOd - £1 St breve syd, a8

‘funy ano yo soueyeq 2up Jo Koroe98 a4p Y>eI Keuw pure “kessw9y pute
uuolreasasqo uo poseg st wonD9s sm, “2194 paquiosap soyqnan amp Jo Aue
poouatiadxa éqqeuosiad 29490 aA 91009 fo 2M :2HON SOHN

(g} Big) out] arp premoy og sok
qutog ‘Kpwa Yo" WIN, “AUOAIAAS puTYog Pure are] 2q [ILM nok
yorg pouin 198 pur pud Joyo ay) WO} omuauia nox aun ay)
Aq ‘astauroung “pavouo ayp ott 193 nox axo}9q WM puE PEaye
YOO] ‘PMOID dU UE WAN] OF WIOOI PUY O ajqissodut oq wea Ht
‘un axp 18 una e 403 dn swuoy Yoed aup sy “punoze wm oy aoryd
'v 10} 3UrYoo] “Yoe) Hod uo auy| aM Wop BuIyoeAI 21,N0K
Key SuorAy ayy BupOH WyBNVD “T
“sajna pu ‘391005 & MOJaq “IOYDUId v aAOgE “OISIA
yauuny are peg sueys au we pauing “urd amp yoray yuvo “Burssaq
‘uma 001 “ayej 001 “SULT axp WHOAy sj 00} “Kean SuOIm axp) BUIOs
juBned Jo wos ‘Kem Suorm oup Sur03 aySnee :s|yepid pure 4Soer
stu pauosse 1910 puL ‘oye] Su!9q J0y Sosa! YOUNLLIOD ISOULE
up are A094 PaIst] “A|sLa J9AO Buj9q st WOULD SS9] YORI
“as at 20} a Bulag st ayerstu WoULUOD YSOUr OU}, “oUt,
Surueys ou punose weap anu AYO siIp St O1OYMON *SAYCISTAL
ysomoy op SupyeUr Mayo ayy Aq wom duB S9Des TOTES

SUTRA PP

kot Stout ays Suyo8 pawo1y

uy ny8nvo 198 3,uod - 91 td ae ag
=
>

=
se ON

e\ahwoe

* ke
sn OTH IK

hn hb? bn

orp be vo sees

ln rr pa ny a OOM
Ce NAC Uno aOG I ADO NS

— pur eT aN
and, bpUTpye ¢



### Page 6


1g 230d.

somany SUMUDIS.

paoidouy

‘pearsut soueunioysad anos Jo
jo ogi aup sazzonbs Suruuusn-19A0 “Towea ado pure at 1waf9
tay paods jyny 18 axe no€ [HUN] WG amp JO INO aoueunsoyiad Jo
ya ise 61949 az9anbs oF BuyAn a1v NOK snyd—yuawionoxo pur
wearers reup iy ‘woud {AA St SHEYS 18 BUNGIE!
‘++ pure yputd pure WEN J9A0 pure 19015
‘oxo nok payoxo 08 108 pure OUT Wo WYSE SUL] OM WH NOK,
woIstA PUUNL, “ZT
}USOOP ITY EOF 99S.
uatp ‘suoddey 1 20599 1H INOGE YUILL “HeIs Ped e JO quana oy)
‘ar pugus ur wojd Kouaduru0d v aAeY PInOYs WEIN) IL
* Plime anos Rao 01 AN} NOK se ysnf UO payoer ZuI9q Jo ONE
-sray Jann atp Psinos azeds 01 Ka, “ures aun OP ob Suuedosd
‘nok apIstl S1POG 40} 110 YOHEAL “INO PLY OF OL P.nos 1
‘ (qZz “Bta) Amuraa ue W998
rn 1 yBnout—aqty HONS #20} ste Peg FumeD yU!OM oq Ket

-amo yoo 40 uo Suny uv9 nok ‘PoLNg PU - AZ “Bt
suis ays 1b pauing,
198 uvo nos , 408840 ays yd, 01 ops 240 MOK - P22 BLE

11 apis pasoney axp 40} papeay axe nok Jf 40 39k) PaIOAe) ay
uo ame nos J] “Kom Tey) INO 103 0} SUAaIS Maj B BUEINP YOM 2g,
‘Kes 1 woyp 1ySus O# OF 1UBA NOK JT “ABorEAIS [[eIOA0 4NOK JOPIS
-uo9 “op 0} YM aNsuN are NOK J] “INO swaps 0} GURY B AAP
nos pur dn uodo sBurp aroyaq samnuput oye wed yy {Te 2wa]9
‘ju Jo aauup 40 dn azaanbs am wed {yo"1 am ueD ‘suondo Jo
uonenjead yomb v sarinbas ste peg ut out] yp Jo Suret0 >
any peg ur Supaeis “TT
“(8ZZ “B1g) 1 pau NO arojaq WHEN 40} |e “Peeds ‘ares9[209y
“WILL “TED “WYSnoyy, :sdars ¢ sayer Apeos ay OF .poads paou
1, 1ySnorp arp wos, ‘AjsnoouRyURISUL UY IUD 1,UOP S[PS
‘dumf aup 193 nok punoze asoyp ‘TueIsUr U0 £q
aaed au? {Jo a4,n0K J] ,;uoULIED v Jo Ino ou aM YURI P,nOk
say OS YOO] THIN Jo Y9Eq auf INO OYs 2M “Pouaddey SuNOu
pure 08 0) pouruEn aa uatp ‘our pautoos SumpAroAg,,

ARIS ayP We paLIng “OT

“aking,
j.uop pun sauypsn} ayy uaansag koig - q “NOK aaps upd sno 1104
Guipa uv ‘ourjdoy uid ays sojag fasinos pun nok ff - PTZ “8th



### Page 7


6¢ 2804 sopony Suunig. sp s0doy

-aouanbas ays fo oa 40 aimuyus iso] yf 40f
s1o0q oa 40 2U0 uo woyassD Amok smDof 4aayf ausua aut y>rDM
“oy &ay uy 424sDy "210492990 01 od4 ap249 pup yovouddo
suoyo svoy 228 01 2uy ays prnyag wus ayorDN 4, "24042]0020
pun Sos siaayfsayio soy 29s 01 pus uid ays fo wonsod » ky
SUIS 42430 YOIOAM,

cAop Kapa v uo rutod ays Sunsom

at (pavog wo ons 882) yoru) uy 24) [102 081 81 SPU NOH
saat uy pus 0115} puDy KOH “Stop 8} oquiau M249 Yo?
yt fo apt uo 128 oF suoutsod 249 2yp}04‘a2y2p4d Bun
suomsod 210104

-1aq 1 ‘001 14s paouow 24,70K) 21] 240 Mok UaYs 180] $1 1H
punt a4a}ts24 0} SH} UDYL Buy a1SDA 01 493809 Yom SFI] D2
spuoaas oxif uo1s 0} unjd ‘SUL "2ouonbas ay} OsM spuor2s
suay 10 aarp nurxo uo uy png ‘suapis 4of yp} Syponngoy 240 NOS ff
210] 241,00

“ynys Suuinys suodun-ypo s1yp
auufan uno nos 20qsonud 21D Yn, 1009 Ja4r0UD 40 10d qo
vio cong » ysoouddo nox sD wo9uny ays fo mo pup ui—08 nos
prayancsana 1 OC] 240g” [tp Sunuay oyr wa sips Suyonoped 2g
jo nog caay wouf ay 24H 01 198 01 sm 2yD1 1 I BUC] SOFT
aouvisiq pads / aut,

ssommmut aayf K1ada urvso 11 op pun yo04 241)
d(aouvrsip

pup away ut) ayps 11 saop Suoj mop ‘paads jynf o4 dn 1a8 01 woo
‘aany 01 Kong ays wouf ySnoua sof x4nd 40 fry und ays wp paods
Inf w Song v Buissod fo p08 ays yao jap Suyovas 240f 10 08

pup doys anog wadas ‘2949 Sunuanys (aimunu anf) woys D Burs)
Sumit, PPV

-sayouy maf D
siaays ayy asa pun ffo.s09q Sunyavad azof fo mno 24012]2290 OL,
jy90) mauaapour uv on

many aq Sow nog asrauayig yong o1 stamis 1 fi qul ays LM,

01 — puny ur jaays ays yi — kpoad aq pynoys taununsy ql ay,
‘quay aus ays 0 ustop Susoys pun 38194

Suppjoy s0f wa4p) “apow youd 4adns v fo wos - pursey20q 10
ng ‘fos o8 16 gil ay], “Suous OM tow Inq ‘paymnyaso}> 2004?
dn poay ‘paynoyasoy9 paunurss sos yng, “Buufiny moysio uKop
o}s pup uoysod ploy pun yand 01 Koa v sy Suryovoy 240
Sumyov2y aod

ui9YDUE AIY,, ‘22 4Of [109 01 pos
app un paau jj,nok pun - nos uo mous wt dn sasojo yorys dB
sof papooy a1,nok ways Kopowos sts poau Sou nox “yP4q
“41D uo aqwa1o 01 woog ay uo no ysnd Mato aan “001 LAD
Suiddons ay wo yoy, “suopipuod vas pun puss waLaffip sof
(yonu soy q nq ‘upu atofag gif) aauanbas was pup 213up
18g ay) puif o1 suommsadyy ‘paads jinf 0} apvsa]9290 pen wy
tuoyy “Suuf}ny spros yen asanoo paynnyasoy9 b wo 1v0g AnOK AAP
mud 09 puo dois

SIPS Sunseyg SuIpyINg - 9"p



---

## Chapter 4 2_2.pdf


### Page 1


Cuapter 4: StartiInG Tactics
4.1 Introduction

With our strategic plan set, Starting Tactics will be used to
execute a start which meets our strategic goals. Our goal is to
arrive at the selected spot on the line at the gun at full speed
with clear air and no interference from other competitors. No
mean feat ( Fig. 1).

In this chapter will look first at the tactical information we
need, and how to gather it. Next, we will look at the start
those final fractions of a minute which can unravel the
laid plan. This section includes the final approach, the
I sprint off the line, and some common pitfalls.

4.2 Tactical Information

We gather tactical information (Fig. 2) about the line to
help us execute our approach. This is different from the strate-
information we gathered to decide where on the line to
start.
‘The information we need includes:
The timed sailing length of the starting line (Fig. 2a).
This information will help us judge our timing as we set
up for our start and as we make our final run at the line.
It can also help us figure out if other boats are close
enough to pose a threat to our plans.
Laylines to each end of the line (Fig. 2b).
Knowing the layline to each end, particularly if you
plan to start near the end, will help you set up. Obvi-
ously, you want to be inside the right end layline to
avoid barging, and inside the left layline to fetch. But

Fig. 1 - Tactics will give us the tools to hit the line at the gun in
clear air at full speed at the favored end.

you also can use the layline to position yourself up or
down the line. For example, if you want to start five
boat lengths down the line, you need to make your turn
five lengths after crossing the layline, not five lengths
after passing under the end of the line.

Line Sights off each end of the line (Fig. 2c).
Line sights to each end of the line can help us judge
how close to the line we are. This is particularly useful
for midline starts, or when other boats obstruct our view
of one end. Compass bearings are nor an effective way
to judge the line, as it is not practical to sight the line
with a hand bearing compass as you approach. Line
sights using a range to an object on shore or to a nearby

Page 28 Performance Racing Tactics



### Page 2


Fig. 3 - The Practice Start: Whichever approach you choose,
do a practice run to prepare for the real start.

4.3 The Start

Regardless of the approach we choose, the details of
timing, speed, and clear air can be a struggle. Our approach
gets us set up. We have taxied into place. Next is our sprint
down the runway and the climb out.

The Practice Start
A practice start helps assure succ
our planned approach (Fig. 3) lets us:
1. Confirm lines of sight and bearings on the line.

A dress rehearsal of

3. Confirm wind direction and close hauled headings.
4. Approximate timing for the final approach.
5. Check sail trim for acceleration off the line.
6. Confirm crew organization and communications.
A practice start is an important part of preparing for our
final approach. Obviously, it lacks some of the frenzy of the
real thing, but it offers a valuable base line.

Toften us the five minute signal for our practice start.

BAY

Fig. 4 - The Final Approach: Sail your boat. Ignore the
chaos around you. Appoint a spokesman to handle inter-
boat "dialogue."

‘The Final Approach

Our goal is to hit the line at the gun, with full speed, clear
air, and no interference from other boats. Here are some things
you can do to accomplish this: Sail your boat, create room,
Control speed, kill time, keep clear air, accelerate, sail faster
than full speed, defend your space, start near a marshmallow,
call the line, call time, speed and distance, and get off the line.

1, Sail Your Boat

On the final approach you must charge the line. This is no
place for the timid. Push hard (o hit the line with full speed at
the gun. Don’t hold back. With the practice run under your belt,
you should be able to communicate easily with the crew and
concentrate on speed and timing. Do not let the histrionics on
boats nearby distract you. Appoint a “spokesman” to handle
boat-to-boat “conversation.” If the tactician, helmsman, and
sail trimmers sail the boat, you will leave the chaos in your
wake (Fig. 4).

Page 30 i Performance Racing Tactics



### Page 3


4

WRAA

Fig. 8 - To keep clear air, hold
your bow up. But hang back to
keep room to accelerate.

being over early; boats which are too far back will be in bad
air. This is a difficult balance to strike (Fig. 8)

The more room you can preserve in front of you for
acceleration the easier it will be to preserve space to leeward,
which you can use later if needed. If you use up your forward
Space, you will be forced to drive down and give up some of
your cushion to leeward. You may even be driven down into
the exhaust of the boat to leeward,

6. To Accelerate

To accelerate from half speed, bear off a few degrees from
closehauled. Trim the jib first to drive the bow down, then trim
the main. If the main comes in too early it creates weather
helm, making it difficult to bear off and accelerate. It also may
push the bow up and over early. Trim the jib to accelerate, trim
the main to squeeze up to course as speed builds (Fig. 9).

Setting up with a space to leeward helps insure a good
start. Without the space to drive off it will be difficult to accel-

Fig. 9 To accelerate from a lufing
position, drive off by trimming the jib
‘first; then trim the main.

Fig. 10 - With enough room you can
accelerate to faster than closchauled
speed and then trim up.

erate. You may end up backwinded by boats close to keward,
or blanketed by boats driving over on top of you. If you have a
good double space you can start with full speed and keep clear
air off the line. In fact it may be possible to start going faster
than full speed.

7. Faster than Full Speed?

Full speed is passé. Our goal is to hit the starting line at
Saster than full speed. But how?

If you have room to leeward to drive down the line you
can accelerate on a close reach to speeds faster than close-
hauled. When you trim up to course you will carry the =xtra
speed for a few boat lengths—enough to squirt you out in front
of the pack as you come off the line (Fig. 10). We wont settle
for full speed anymore—we want to come off the line faster
than full speed!!

Page 32 Performance Racing Tactics



### Page 4


Fig. 13 - Call the line accurately t0 avoid midline sag.

10. Call the Line

‘A crew member in the bow pulpit should signal. informa-
tion about other boats and distance to the line. Point at other
boats with fingers, and hold fingers up to give boat lengths to
the line. Signal where to go with a thumb: up to accelerate,
down to slow, windward to head up, and leeward to bear off.
The bow crew needs a watch to call the start effectively. As
soon as she (or he) knows you will be clear, she/he should get
off the bow (Fig. 13).

11. Calling Time, Speed, and Distance

Calling starts is tricky—you need to know when to put the
hammer down. Too early, and you'll be over, or you'll have to
stall at the last moment; too late and you'll be buried by those
around you. At every moment during the sequence you should
know how far from the line you are (Fig. 14). As you sail away
this includes time for a turn.

It isn’t easy, but with practice you will find you are able to
guess time to the line quite accurately. It is an important skill.

12. Getting Off the Line

The starting signal marks the midpoint of the start. We've
dashed down the runway—now for the climb out. The final
seconds before the start, and the two minutes after, are often a
pure sprint for clear air. Speed is the key ingredient. A little

Fig. 14 - You should always know your time to the line.
With practice you will be able to make accurate calls,

ARAN By
ae \
BRAWN

iN

Fig. 15 - At the gun, blast off the line and Sail Fast. Only
those with speed will be free to pursue strategy unimpeded.
Others will have to compromise strategy to keep clear air.

extra speed or pointing here translates into a big advantage.
Make sure you are tuned up before the start; concentrate on
sailing your boat; ignore others. Try to start faster than full
speed if possible, and blast off. Settle the crew and concentrate
on steering and trim.

‘The tactician should watch the compass and the fleet for
shifts and room to tack. Being a shade slow or a litle low
eventually leads to bad air, and problems multiply. Keep clear
air and keep moving. Nothing else matters (Fig. 15).

Page 34

Performance Racing Tactics



### Page 5


Fig, 19 - As the leading boat on a port tack
‘approach you need to overturn your tack t0
keep from being squeezed by the trailing boat.

4, Squeeze

If you are the lead boat on a port tack approach then
beware the trailing boat tacking when you do, and putting you
in the squeeze. Over turn on your tack to force the trailing boat
to spin its tack, and then trim up hard to open a gap. (Fig. 19).

5. Too Far from the Line

When the fleet gets between you and the line there is no
way to get through, and you get only bad air. In most condi
tions it pays to stay within a few lengths of the line. In light air
or adverse current stay right on the line. It is easy to get pushed
away and hard to get back (Fig. 20a).

6. Too Late

You approach too late, get bad air, and can never acceler-
ate. Has this ever happened to you? Me neither.

Once, when I was stuck in a streak of late starts I adjusted
my timing to try to be five seconds early. It is easier to kill time
than to recreate it. Set yourself up to be a few seconds early
(Fig. 20b). Don't be late!

Fig. 20a - Don't get too far from the line.
b- Don't be late.
¢- Don't be too early either!

7. Arrive Too Early

You either end up over early, or you stall and start
speed and get run over. Timing is tricky-close enough to
control part of the line, but far enough back to have room to
accelerate (Fig. 20c).

8. Barging

Stay below the layline to the windward end. Any time
your final approach is from above the layline, you are asking
for trouble (Fig. 21b). Barging is reviewed in
Chapter 5: Starting Rules.

9. Can’t Fetch the Pin

When you find yourself outside the layline to the pin, bail
out. At the first sign of trouble jibe around. Tacking to port is
suicide. You may be able to come away with a decent start,
instead of being wrapped around the pin as the gun fires. For a
pin-end approach, you must know the layline and stay above it
(Fig. 21a).

no

Page 36 Performance Racing Tactics



### Page 6


Fig. 23a - A pincher below you can ruin your
start—and his own.

Fig. 23b - Try to gas off a footer before the
speedster rolls over you.

13. Start above a Pincher

You come off the line fine, but the guy below you sticks
his boat up and pinches. He is slow, but just fast enough to
sneak under you and give you bad air. As he ruins your start it
is little consolation that he is hurting himself too (Fig. 23a).

14. Start below a Footer

This can be a problem, or a blessing. If we are inspired to
new heights of performance in order to hold off the speedster,
this can work to our advantage. If the speedster rolls over the
top of us then, we have a problem (Fig. 23b).

15. Rules

In addition to the regular racing rules, there are some
special rules which apply only at starts. Know the rules, and be
aware that others may not.

Starting rules are such an important topic that they de-
serve a chapter all their own, which is next.

Fig. 24 - Starts require a good plan, great teamwork, and
impeccable timing.

4.5 Conclusion

Starting Tactics guides us through the most important and
exciting part of sailboat racing. It is no wonder more and more
races are being run on short courses, with multiple race each
day-Everyone wants more chances to start.

Starts take teamwork built around a sound, flexible plan
directed toward clear strategic goals. Get the information you
need, practice your approach, and don't be late (Fig. 24),

Following are some ideas on how you can build your
starting skills:

Page 38 Performance Racing Tactics



### Page 7


4,7 - Starting Quiz Questions

1. While setting up for a port tack approach, you notice
another boat appears to be doing the same thing. What should
you do?

2. You are setting up for a boat end start using a triangle
approach and notice a surprise wind shift which makes the pin
end favored. What should you do?

3. How can you tell which end is favored and how much
difference does it make?

4. The right end is 10° favored, but the left side is favored
upwind. Where should you start?

J. What is the purpose of sailing the course in miniature before
the start? Why do a practice start? What else should you do
during the hour before the race?

6. How can you tell if you are over early when you can only see
one end of the line?

7. You are approaching the line close hauled. A rival skipper to
leeward is yelling at you: “up UP UP!”
How should you respond?

8 You are close hauled approaching the stern of the committee
boat and you hail an inside boat which is barging. Moments
later the gun fires and the return hail is, “Now we want room.”
What should you do?

9. You are the third smallest boat in a PHRF start with twenty
boats. How will your size affect your strategy? What if you are
the largest boat?

10. What are the best ways to waste time if you are early on
your approach?

Page 40 : Performance Racing Tactics



---

## Chapter 7 1_2.pdf


### Page 1


ZINO ANV “AAOMAWOP ‘SATAN VXF

a SIDATIMONY TWIOT 6'L

eA ALINAINOddQ HO UNV] AHL, :AYOLY LIOHS' 8°L

STVAIY SA AOALVALS Z°Z

ee INTAIND OL
ye: SLAMS AO LIVAW] AHL, S°Z
SLAMS NIM $'L

he ANIM €°Z

SNOILIGNOD ONILIIGIA TL

ee ADALVALS OL NOLLINGOYLNT [LZ

" ADALVALS' GNIMd ()
Atty Gres rm SZ YALAVHD

haar gom wrod) eproy) ~

mm Prarypytoy dn sxred tony ronal ox 5
@

as erp) PIN
on Pop-poxg bare - shay pom tng yop

X



### Page 2


$5 80g

amas pundy iz s01d04

sez

eet]
oezi|
ett

aa
eczi|
ozzi|

ste]
zee
tozi|

$

é

é

é

é

é

é
7 on fs} eyo]
ex eu [ee| - [eeu
siz se Z| cloeu
Se oa 6s| eeu
ox ou _|os| * [seul
= apace
ee loca sit gs! 6|sz-11
4 [e=4 gs] 6iiz:t
sot Pg} efor
= oa. ral eer
i le<4 zs] e{ sit

Mod DUTY pas Bll 2
a|2\e
ydeay pur g\s

‘suompuod s,kepor ut ssadans 01 oy auf

se 998 aM 1B UO spuadap snd0} INQ "widDuOD INeUIWOP otf 24

[110 paads 180g suonspuod ajqers uy “ssasons sno 0129 qI198 £39

~teals queyodurt o10u otp “IuaxiN9 pue PULA oxp IquLTEA 210
24, ‘hea Jououe UF parejas axe SuONpuOD pue ABIES

-pauyjap [9m sso} 9q 111% wep sno

Uuoqp “ureuigoun st seayoy sno way Ay “UY WY B YEU OF 21qe

24 [ILM am “Joadx9 01 1eyA MOLLY aAN tIDY AA “SUORIPUCD paredxo
ou punoye saajoaas Zuyuurjd o1ayens sno “pres am Sy
suonIpueg pur KBayE.1¢

“sured 9jqissod aseaxout pur sysis 2onpau o1

sppo a) 2utXeyd oF uop sjioq Suruueyd ano pur ‘ayemnoow UeKp

sa aaoud ayo suonrpard sno sonowad uy “sea Afoantea4

‘suounjoso
fo wound s9nia1 Kaas.» smoys tavyo puss topnonurd

SIL wand pun ay1 fo a8ouy jonsts v 198 04 ssaquinu ay1 10}
amt “Barnuis ano asopdn pun untd sn djay jp uonpuaofin sr.
“aane v fo Bap ssarf ays Stump pup savis ayy 04 401d suomypu0d
fo Korsny v moys a1ay parsy s4oquinu ay ‘suourpuor
parotpaed pu pasaasqo uo pasog <Barnus uDjd ~ Z BLY



### Page 3


Lg ag

Samus pundy :f s01d04

‘rauso9 atp ory sayy
ou “opppru ay pre mor [es Op 01 TeYA JopUEd NOK OTIYAL +
“slosimo< pry i,uop :Su1o8 are sBunyp Moy moge onstyeay og +
yyord ayp iia Aers iqnop ut uayAA “Siaq NOK aH «
(jaw {121 n0K
MON) ‘AIPPIU ay Aeyd—eEM WIFaq 01 IHWIODIBAO 1.UOC «
ss1aipo Jo aatiatiadxo ay
uo Ajaind paseg seapr maj # JayJo wed | “sIYsISUt 4940 01 PIE,
Str gposKuu ayeistur ® yons ope SurAey 19AaU ‘9siN09 JO,
*sasinZ ‘pua axp UL peaye Ino aWHOd
1 Yuas Yomas oy asoup Furaas uoMp pue Kwa ano Suyrg st
uonensnyy ayeuyn axp ‘pury Jay a4 UO “SOSso] INO and pur
Bay amp dn Kem sqey no req NOK J1 ssapea] yp oF dn pu nos
80]9 Moy Zurstadans St 11 UOJ ‘wonsonb YBNOI e SH WELL GIT
oye apis pazoAry axp 10U SEF aztqeax pue “Ieaq amp dn ea Jey
108 “apis pazoavy a4p OF [Hes NOK J OP NOK PINOYS TeYAL
EIB A MON F9pig uo Ay ayy uo 3ysNeD
“aGiequeape atp 193 01 autiannxa ay} 01 OF ISNUL IAA »
pup KBayens sno noge 1WapYyUOD axe OA «
{JL Sopis ouranxa axp 01 {Hes K[uo pinom apy ‘suondo
+89} HEM pur UONISOd Jo Ino sn aAeay UeD Kay aDUES ‘S19UI09
‘lp ploav 0} suosvas [eonse) puk a1Boyens axe axatp “99s [CUS
‘9m St “Puodag “sOAODaL OF IINOLEP IF aYEUI PINON WOULULLOS

Pes

-yoo1 uo] ays Spanssaaou tou st
po! paroanf ays ‘Iaq pasiays D
ug) “yam pasoanf ay Isis YOO.
Su0} ays asnfiuos 1,uog — p Bty

[e101 v pur Zuo aq 01 aAoud Kew KBareNS sno *2H0 40,4 “SOpIS
‘uia1nxX0 otf Ploav 0} SuOSwaL [BI9AAS ae ALOILL, ;PUOKIG JOU nq
PPI up JO 49] JO IY aU} O7 [HPS 01 S9q AjTIOUD St JOM
aUf 40 apis auo ssoAvy ABoreENS NO Ual|AA “OSNOD a4p JO OPPHL
pur ysis “yo] oy Sunuasaidan ‘syuouras peor9a dauyy oUt Zo]
PJUApUIN oY OpLAIp [LAN aM ABayENS JO UOIssNOsIp INO UT
AIPPHA 8 YT USE
“Boyes purmumop sno uefd 01 peaye Yoo] 2a se djoy [ILA
pasoary st apis ouo €yat ang “yorya snl JOU BuLMoUy “sosueyo
‘ura aqp [uN amnpus {[Lm afeIUEApe ow Wamp ‘aI0ys SuIpunoLMs
‘amp Jo Aydvadoa¥ oyp 01 onp st aBequeape ayy Jf ‘aSmuEApE ay)
asioaai uvo aph up UE aSuEyD OU ‘a|duUrexd 40} 10190} OMp St
quauind J] [Jom se paTuvyo sey asequvApe ayp pur posurys oary
Suonpuod JL uTWLIOP sn dyay [JIM UOseaL oy ZuLMOUY “KYA
nq “parang st apts Yorys AyuO OU AOU [Ea 946 AIINYOdOH
EParOAvy APIS SHULL St AU
1 a94e 08 0} aye] 001 10U StH “quaredde st aBeIUEApE
ue J] “9904 24p Jo sant May Is1¥y 4p 404 UONUANE Ke
“op NOK au0joq Jo 08 oYm asoy
Lyorem quona r904j afdiynuL v Uy “SUIS Ja4yI89 9A05G0 «
EpeOYE s,4AA “Y>"q S¥9"I LOIN pur — sayNUTET
¢ Aes — umn Jo junoure paquosaid v 40} apis 2U0 01
sites 1eog yous ‘Found Suruny w yA yay, “BuNSA IO +
nut jo ajdn09 &
Jo} aut] 4p Jo UoISUaTXO ay) {Jo Ino ZuIYKAY kq yPTUINS
pUIAL S91 uv NOX ywOq axp dn [res 9,9 NOK J! HOA
{apIs BuO 01 YJIYS JUaISISUOD v 40 ‘3z9Iq JONOq BOY ST
{EIS auf 0} LOUd assn0d ayp Jo SapIS ayp 01 [eS “BUNSL,«
“roqpans septs
ur souatadxo ysed uo paseg opis paroary ay ssond
nos djoy uvo oFpajmouy [eo0"] “aoustsadxa UNO INO, ©
:SAbmM awOS Oe 219]
PIs Yoryas [[21 NOK ued MOH

{PALOALT ST OPIS LUA

9081 auf a10J0q Pa1OAv]



### Page 4


66 280g ASowug pundn :z sardoyy

“ante Kayp azojaq syjtys 1otpaid pue az1uFose1

‘01 044 “SIP s9UHIO Uo 1294J9 SHE YoreA pure soya ayP UO pUrAL

tp aasasgo ‘sseduuios ayp 0} UONppe Uy ‘paauue sey Jaye
Aytys v inoge s{J>1 <fuO ssedwios oyp SuIpeas ‘asin09 JO.

‘sijtys Supwoodn oyedionue pue (1019 *Z “Bt. 99)

suioned 10} Yoo] uvo Nos ‘sytys ay) SuIproDas Kg “YD"I YORI

oJ SMO] pur SYTTY Jo ours v Ystquisa pur sBuipeay ssedwios

Jo piooar v daay ‘asinoo sseduioo pajneyasoyo snok Youn

01 SI SYjIYs puta Jo youn daay o1 Kem 189g OY, WAH Jo YUN
daay isu Nok sYytYs PUI Jo 2eIURAPE ayL} 0} J9PIO UY
suoppUuoD Suppeay,

sod syfiy (mopaq) ifa ays o1 yfiys
“papmay s1 yoo! tod pun

x ‘pathy st yo01 pavoquoss (14814 10)
SaySuu ays 01 Sunfiys prs a4 YA

“yen syuous ays wosf Koa papooy

papsputas ayt 01 aaunisip Suysos ay g ag 118 YO says0 ays arya yeoUL

suatsoys 4201 poyfi, ayt Suyros <q sifiys ceri ays panos dn payfiy aq [p19 yo01
puss fo aSviuvapo Suryny ~ £ Sty uo ‘syfiys pur ayt sy ~ 9 Bt



### Page 5


19 280d Sous pundy 2 tardy

‘umutoads 1ytys 4p Jo pud dutanxo oun 1e [uo apIs WU WHOA}
eave [pes pur ‘spui aftzoxe SuLMp apis pazoary atp puvAor

“yftys wx2u ayy parsso [Hes [uo plnom 94% ‘asino9 tp Jo apts aUO O} IUaLIND 40 PULA
Suyjos sows ‘1940 pun 1980 J9i9q St a194p JF “9Idurexa 10,{ -pomays oq eu sajSue SUNY"
Suny aus ayy op 36 spurs ies oi Ook 9m no ‘SuoneapistioD 91ayENS sOUPIO aut aUSUp IF “Sse LA

Sunnjposo uy oF 81 =6°3 ‘soyenb
aig en TBE, hy naires 108d ‘uo 10} od pure ‘98ures pul axp Jo siouenb oamyp 40} pavogsers
uo [12s 0} paau 1.0% uayp “Lod se paroqers You se sou 2axy)
‘01 pamays st Sa] yp J! “o]durexa 10,4 “yoreut o} parsnfpe aq asnut
Suryor) Jo} 9]Sur J9Aossoro ap uoyp ‘paouEjeg OU aue SIN
40 aj ayy uayAA ‘aseo axp sKeme r0U St sty, “pulmdn rysTENs
SE yzeur oy) pur adezaA0 Jo apis yora uo aumn jenbo spuods purm
OU} Jl WANs SYLOA\ OBPIOAR ay SaSSOID PULA ay Se SUPORI,
sBary paouejequy,

“tno sBunpi wos NOK ayyA
sqynd yxau ay spaemor 10 “yseU dy 0} 1S9S0I9 NOK SayyeI YOIYAN
yor) ayp [ies ‘oseyd Jo no Jjosinok pur NOK JT “ean yeUD YIOA

sAvasye 1,USa0p 1 MoYauOg ‘aseyd ut Keys 01 Asea aq Pinoys
11 ‘Ava INOK Ut SIOB OUO OU Pu 9949 Ae|NBaL v UE aULOD SYJLYS f
ou) JI “PABAUOPYsteNs Anard sures suonespioso wi Surpres
aseyd JOO
“parsnfpe oq 0) Savy [11a
sraquinu papeay pue pay] sno ‘2Buryo suompuod Jy °283n09
afvsoav 40 ‘paproy “parpl| v Suyptes axe 9m 194 !OyN TWOWOLL
‘Aue ye Mouy pynoys am ‘sassoaoud aova au sv uoreULOsUL SUL
-rwpdn pu aovs auf a40J0q VOReULIOJUT pum SuNID9I}09 KE
ase W139,
sytys pue sSur
-prai sseduioo uaaavyaq UOrR[aL109 yp JaquIdWOL 0} PIE Ue Se
dappapy ‘tay Sip] ‘og aseayd axp asp “Y9e1 01 aUIN S111 1SaBsNs
ayy 2aurs Stopray az1udooa1 0} ueLOdUN ow! SHY] YPED"

1 qd “Hv st 19Mo} Hod uO opray e St oqUINU 1940]
AN secs { “yy st Suipeas sseduios 0ysiy v 3198) prwoquEIS UO



### Page 6


£9 280g ASawag pundy 2 sa1dvy

-siaq nok a8pay{ (‘peq rsnf axe nox—puryoq
ayn v jpey aq 01 Ayonyun you st a1 MoyaUUOS) “yuns axe NOK
“Buorm 9g 01 uaddey pu Woy omp yA ayjds NOK J1 spucsag
UOU INO St OY 98 DUOKIDAD
2p} [TEA Je urSsCUI a[quIO;IOD w ISMf :yoMUE B01 Kq UHH OF HUD
juop nox “Ryany asnf a1am nox YuIyp [1x BuOxIEAD pure “peaye
‘Kem dn pua [1a nog yst4 ou NOX pue yds NO JE “ISH
:SuOSRaL OAM} 10} “ToaHy aMp yA £y>r01d
-wio9 14d 3,40] “Fay aMp Jo Yo] 24p 01 JLesINOK uorsod uIP
‘ yo] u108 st pura oxp uIIN NOK pure AYBHE S008 190] Otp JT
Peoyy Avy OOL,
‘yr aup Jo apisino amp
punose payry 3umo8 ‘ainou a]a119 wa18 94s Se WOU St YA
‘Suyjres dn popu sweog 4981 Hod aU, as10Mm pUE aSIOM YOO]
yor preoquens apeut yoryas “y>81 Hod uo Joyny pue JoypNy
aye] Suma day Kysea Ino payors YOIyN seOg IHL

WL OB

oot

ines?

‘of dardoyy ut
pappaquia s) saasup ayy, ¢udIs ays saif uarfo aow 40 4918Vf
afiys 01 wiaas uarfo puso ay saop Syms suousang e8uaypryy
“afiys 1xau ays punao1 payios am ‘skomyo sy ‘pula siou
parsodxa ays fo aBpjunspo ayp1 o1 <Bapnuss aov4 punos v wsof
01 ago aia am LOIS ays atofoq wouruuofia puss Susoysn® KE
“ssaquunu ano sajuase4 01 ydos8 purst ay 12824 04 PoY 20

CSET AV “ydo48 ano fo uns Suva. 11 1fo] kos sn payeoss pun
ay sy fa] ays 01 fiys suarstsad  smoys you PULA SELL
“yiys muarsisiag v 40f Barus pun ydoug pug ~ 11 “Std

srl
orzi
set!

sel
oezi
oezi
(Set
oz
sbzl
ovet
gor!

coz
ean

sol
sol oS
50 oS 49800

QOOT TT AAAKAMA

es

on
0

99HH00H000
a

oz aL
uod DOTA pas

ydery pur



### Page 7


59 ang Barus pundy +z sod

“puyag sypof pun ‘sifiys ays sa10u8s 0g yovIq ay, a40qD ‘190q
patayooyo ays &q usoys ‘sifiys ays fo aSv1unapn ayor ot KSor.as
 upjd 0} 2140 $1 unjon901 ay1 ‘woHDULLOf sty Suis) “ou 4040
puis Suppose un fo sojd ay smoys ydouy puyyy oy ~ ZT “St

ha

An) = hwy ~
thls WH ALA 6 WH]

my

oe

Mod Ly pas.

ydesy pura

Ti

9
3
a= ho 9a
Boat Spd | fh wi fi in nn
Wind Spd] o0 a9) © |y a]aao|oo\n00)00
a
9



### Page 8


19 ng

ASarug purndy “Z sadoyy

oe
—
¢@

-suonpyposo ays Sundnyd aprys apts paroanf ays pavssor
{0M 01 $1 SuoUIpUo? asoyL uy KBaIDUg “TyS}4 ay 01 SumayoiD4 Kponposs
spun Sunojpiaso ssoys suompuos paxtu sof dra Puig, omL— EL “BLL

ore soe eo] Tr] 9-21
ore 99% zo] tt] eee
OE 09% o9] OT} Tee
sve 00E 09] OT] sez)
ore soe WO)TT! see
SOE 09% volt) eee
ore 99% e'9| at] ove
SOE 098 eo] Tt} st3
ose ‘50E eo| ttlere
sve 00E 9] OF] ore
ove see 6S] OT] 80%
008 ose eo|tr| wz
OE 09% eo| tr] ez
ose SOE e9| TT] 10021
ore 56 6S | OT/ 8g:T
008 soz ss or| ss
ore O0E ge| 6] Ist
ove cee re! 6 |os't
Be ose zo| 9 |svr
[od ove rs| 8 [err
see ee gs] 6 joer
Be ose 6'e| or ser
ove 36e es orloe:r
068 she gs] 6 [ser
see 06e ws] 6 [rer
06e spe ws] 6 oer
fod ove rs| err
ose wee os] 8|srr
od PUT pas REE
a aes

ydet5 Pulm a



### Page 9


69 80g Sawa pusndy iL s01doy

‘are Kavay ur poounouoad ssaq ‘te yY8H] Ur oN eUTeAP azoUE st pue
“oun ayp [fe SOLUTE SISEXA I] “JOA9q Yap Te asoyp UeYP IOaUONS
‘9g 01 poay ysbu up 1 SpUIA 10} KouapUar yp St uaIpDAS
Puig “huatpoas purse yas says puss BSHJUOD 1,UOCL
(L{ 314) pooypseur sno ye MOUS JOU
Soop yoryas (pura payoadxo op 01 anja v pup) sways puLm v Pury
(01 31g8 94 [IIa NOK souaUiOg “sI#oq 10820] Jo speomseur au
ye Yoo"] 31291) paxiuy v UI Og [feUS ¥ aM NO JF YOLN v S,219H
yysus 03 “ysis ayp wosy St purm soddn axp Jy “PUFA oovyins ou
oojdstp AqjomuoAo [[1A0 11 Se ‘puta soddn ayp preavor [es ose9
sty utp atau ay pupsor pins skes ABoven)s purse jewwoU
-upun. “yueurwop awodag [1a puts Joddn ayp £4yes9usH
‘prvAUOYsiENS a1OW 9pHE SEH AqTEONINL, SPO]
24 Aes 01 Bujyeg 9q eo PeaLpseUU O1 Yop OU Woy TUAID}s!P
‘LOU JO OF PUIM auf IPE SUNUUUEN [Eg “yoTe pul wAIEAIP
1 pure “2ovjuns ay) Uo ate [009 Jo 40Ke] Arepunog v St aI9ULL
“yystu ae 40 ‘ep Buuds v uo
uma sarem ploo qnoouls 1940 Uayyo ISOUL SANO90 J] “oUOUN

“puja saao] ays soavjdsip Sjponsn

pe do} uo auo ‘sputss own fo Suryoors
Ce pst ays st aways puny — LI “St

si aways PULA “YoTe J94p0 aup pu “souyns oy) Ye BvO—PULA
4Jo SioKv] aze a19up arya UONEPUED v St ADEYS PLIA
aways PULL

sessed sq] aye pue SuLnp suontpuoo ayedionue

601 ajqe 2q Ae nok jJenbs yo ad axp Surzzudooos Key OY,

ody orOYIP AfammUd 9q [EM WoAy ayy PUIYE SUORIPUOD

uatp “uoaj pjoo Zurouvape ue Jo ued st jpenbs op JT “Ipenbs ayy

(0 104d parstxo Yiyas SuORIpUOD axp OF WIN} HoI}O S4ORIPUCD
sed jyenbs ayp s0yje uatp “pazyqeaoy st renbs ae FT

‘Zururen maid anof Jo ued 9q pynoys

1p renbs ¥ ‘soauue 1 29u0 40m pueaapurn prone o1— yo] au

(0) Sx9eq puIA oyp AfTeEnsn — Lys Mau ayp PrEMOs [TES “oIqISsod

aur sured oSny ‘ojquiesos s19tpo aya [Jenbs ay ysosy
sok pur fies torso4s or Kpeas aze nox sf “pasedaud og

‘sassed |Jenbs ayp se Jy}0 Oy

pue ‘sity trenbs oup se suo—santumuoddo ons a1eaio sjpenbs

“peoy Sif uo 1oo[j amTUA tp WIN) UD asayLL, “I[enbs UoOWIAYE
ane] pazyleooy v St pula worsKs soynram yo adi soIpouy
spur teabs

-ysv09 94} 01 108 aup se seaddestp U9Ae JO [TIS

uayo swiaisés Jayream JOUILUNG “parnpayos Sv OALIE 10 SOP

yorum atys v Sunoadxa pur suonpuod parsipaad axp Sursey>

UL JoBuup tv St ONOY,-sueMag Ing “SUIT snopuowo.n aq wes

‘au0tf IF 40} UOHNSOd ut aq pur (‘919 spnojd Maul) SUOTTPAIDSGO
40 siseaauoj UO paseg auEyo siyp ayedionue UeD 9M JT

qureaajaust sowodaq UOReULOJU! Zar ayp Te pue siadde

Duras 1uasoytp pue MoU v o10ya SUOISEDO axe ax2yp ‘OSNED at

OAD WY “SALUTE ABU PUIM WHaySAS JOYIAM MOU B JO “PULA

Aq apise paysnd oq Keur pur Zuypreaaud y soypoure aocydos
ued puLM auo ‘UoyBAM JO aAOU stHAISAS JOyIOM SY
adunyy s0feAl ¥

SUIS PULA WA'SAg JONVEINA,



### Page 10


1 280d ASawug pundy :z sardoyy

“rg :suonnpposo fo savduy ay wo worsmouey ~ 61 td

isifiys ay HH
‘gyrus sod spuooag og {aftr sad spuooas Og aavs
Uns [1,n04 ‘ouatouya G7 18 waAd Ing “Apoojied SIpIYS PULA
‘yp 3uyfres 10g ev Jog PUR “UOHETTDSO FENpLIB v OU — SLFIYS YO
JO 1YSU iq 40y axe siaquinu asau, ja[{U! UO Ut so;MUTUE OA
10 — spuosas QZ] siuasaidas stip s}OUy 9 Jo paads 10q & VY
(61 Sta) 1222} QOTL IMOgE 40 “4461 Kwa" st
pry ‘sojtur 97’ Jo SBurAes y “aouENsIp out] 1YsIENS ap SOWIE
ZL OF ZT wosy posnpas st pats sip ay
aSequmape Suryer Aq Yo" prBogueys uo sojruul 19° puw "yo" WOd
{Uo sojrus 19 Jo [eIO1 v [HES 01 aABq [THA oq oxp ‘puINdn ay.
uo Yeu vO} [Wes OY, “AqfeaHeURAp saroadunt douBULO}.1d HOY
suerpauu auf Jo opts J9yR19 0] Surpey|LOSo St PULA OU JT
{190) 009 49A0 — ott v Jo
‘yiuo) P J9AO Jo SBurAws & S,reU, “2dUEISIP SUT]-IYsFENS a SOW
(O€"[ 01 paonpar St paytes aaueysip ayp “sYIYs ou Jo aBeIUApE
Supyer hq Yor preoquers uo sajtui co" puw yoe1 Wod wo soyyur
{697 Jo [e101 & [eS 01 Avy TEN 10g Oy) “PUIMn [LUI BuO se
0} [les OF, “Kpuroytudis saxosduit eouewLopiod warp “ueIpeUt
‘ou Jo opis A919 .G Sv a] Se BULNEI|LOSO St PUIA OY JT
jot) prtoqeas uo soqiur |Z" pur "4921 Hod wo sop
IL: Jo [e101 [Hes 0} aAxy [ILM Og ax “purMAn ap auO sev |
(01 [es OY, ‘2OURISIP aut IyBrENs yp SoUIN Zp] SI pores aouersp
ayy EY puy am “(sayid) KnatuoUOsiN SuIsy) °.06 JO SUL.
Surjorn v yuu “purmdn Suypres wog w YA ISH WEIS TANK
suopey[pso Jo judul] OU,

aye |

saynu 19°

son ey
ye



### Page 11


EL ang Sarug pundy 2 4ardoyy

“sured 31g o1ur soqejsuen aFejueape yawns |feUs

B SpuIA ot Ue aJqrioipad puke a[qerfax axouL UAYJo St 1! SuoNS

‘suns quauins ay) UDYA\ “UOHeAIsgo THI paredutos suonaIpasd

_Hoip pur “Porpmis aq plnoys Suey uaLino pure Sa}qea epLL
-aiquioipaud st ‘poresoua® JAH 40 epH Joyoyas “WuaLIND,
yuo & 0} ‘9IqUIDIPAd

“(pt Ma)

WA Ur aSequeape 9,02 8 St 19949 aUN ‘papeaYy s9IN0 94

pur pargi] Yor) avo YNTA\ *.9 PAYS St puLA Suyres oy wuoLND

‘Jo 10UY ou0 pur puIM Jo SioUy UA} Ut ‘aydumexa 40,4 ‘popeay oq

TW nos “ways aL oy YA Burs ‘payt] aq {ILM NOK Auos

-ana aq owur Mog SuyRg “WuaLiM axp £q pasneD pura Surqres

tu auryp amp Jo afeueape ayer 01 ean NOK “Bay axp Jo axed BuO
uu z9Buons s1 pur asinoo axp ssosoe SUN ]uOLIND 2Up LOYAL
gsinoo auf ssoxoe 1UALIN)

‘sop ays
pia aBunyo uno aSonunapo ayy

‘assaapo fi Kaw [vs ‘ajqnsoanf

fist 01 08 ‘apts auo o1 suauana

S aaSuaus st a4ayy wayad — £2 Sb

“(cv Ba)

purmdn vase sip ploay sYoyatoy Suruuns uaund puv puis

‘aiwoiput ued JO1eA YBoouIS “KprepLUg “puldn yuaLmNo oy op

pue sara Addoyo aup out [eg “stip 40j Yoo] doy pasunow

oad v dn 30s ueo ‘putas oup ysurese Suyuuns Yuaxind opqusoAey

|y -OSIApe S111 J! apis yeUp ploae pu “2]quuoaey str JF OPIS eH
JNO Yaas apis BuO OF OBUONS St ALND aUp Jt AISNOLAGO,
apis au oy 1UALIN

“Buruueyd

o1Zayens 0} Koy s} oe IULApE WALIND v SUONIPUOD Pulm UT S29Ud

JOY Ip oNvUEAP axe a19Up SSa[UP] “ABareNS sno adeys wed esIN0o

‘OU SsOde S2OUDIOJJIC] “OBEIURAPE ax} NO Yds ISN 9A UO
“pare asmoo ayp $so19 aUues otf 10U SF WAND yp HOY AL
WLOJIUA JON St JALAN UAL

-yoo1 yona uo au fo agurjng ays SusSuoyo ‘esano9 ays says
spp ung juatang, "yarn ayy ony saute] uo st ropduty wa881q
ays 89} ays moysnorys uuofiun sy miasans ays wayyy — ZZ BL



### Page 12


La8d Barus punde 2f tardy

fo purr] au, w fasanos pusf pa nos 940} 40 4aU00$ =Lz ‘Sip

“(LC Big) CayMey MOK sem APOyY] UE B20UL

‘sapisag) “11 Jo INO BuNIa8 Uo sn99J s,J9]—Ssau SHI OUT OF
am MOU PUILU JOAONY “OaIeYD ay PINOYS NOK Joddiys v sy
1PM 3,u0q

-apminye YALA sus ssaoons pur “uorduneyD e Jo yeu a4

1 yuo 07 UMP YstUYJ [eoWIOUONse Ip ULIG oF ANTIqE ULL

jpaogai aAnnaduuoo asiavioqpo te sanreys UeD axoos [eaHOU

-onse ouQ “URLOdUH yo ay} UAYO St adeI ISIOM INOK $a}I0S
40 enegar Aur ur yp az1uooar ‘speI9p WUT BUM aU0Jog,
GOP MOK pjnoys wey “Y>"d YP UE Y>Eq a1,N0K “OS
savy juEpLodwy yoy PUL,

-paytyenb Ajonbrun yye axe aa “sur99s af “eM Ve :pUIYog 112

(01 SA oy) UO [fomp 10U [TIM J JOISesIP Zuypury wog vs

Big v “1eaq ISI} a]quuDstUN v “}2EIS MoI party e—a1OHp 108 Nos

ssou SMOUY OYA “OYJ axp Jo pud [11 a4p We JJOsINOK puly NOK
Uoppns ay) Jo ITV “819984 Jo 39g oy 0 UDAd ‘suaddey ay

Ayrunjioddg Jo pur] ay], 3°L

Xo a

‘Puyo axau ay 40 yuDUt
xu ay pup ways w22auag ois
-spaue fonya smo 19803 ~ 92 St

anof Zupenjeao uoyas soouaiaytp au deorpuey spisuoo
“gsim0o Jo “ISNU NOK, [RAL ay} MO|fO} O1 Ajduns st ABaENS
‘tp ase siyp Uy sOLIOs auf UF pea| B aArasaud OF aIqu oq 01 29%
tf UL puTyoq YBnoud asojo 9g AeuH NOK UaY SOLID OTe OU,
“yxau ‘souony puis °g sardoy as worssnostp JOyLNy 10]
-saniumyoddo sof 10} Yoo] pur juaned aq 01 dary Nox “pUIyoq
soypany nox aavay [fas Sumyds ‘Kea ysts oy Tuyo; st peat amp
pure puryog axe nos Jf “Sumuds Jo ayes ayp soy Aydutts you Inq,
Sqeaus oun uta ads 01 st Bares oIseq au PUIYEG USHA
*(97 “St rout 1xou atp pur uoNNnedu10s
‘up uaomiog Avis 07 SI peaye uaya ABareNS a18eq OL
‘rem oywatud no ZuIso| Jo soureyp Joa v pucIs
no waup “Aypeq [es NOs Jf -20"]d OVUE [ey [LLM ISA OM *1]OM
30g UMO AMOK [Tes NOK J] “FOIE atTayens duo Inq oe s[eALE
‘24.1, tuouoddo ayp Yat pardnonoasd Susuwos9q ut sosuyp e
S| 2401], 1]9M 180g UO INOK SurpPeS Woy NOK JRNSIP WOM 19]
20U op 1nq “sJeALs AsoJ9 NOK 9pIsuoD oF ABIES poo SIL
-surpunys aup ur sn 0} asoj9
‘are yoIy Seog sejnonuTed YIM pousaouO9 9q KeU dA SOLOS
v UL a1] SuuUD|d d1ZayenIs sno oyUE JoIUD UE s1eOg 19"!0
‘onss} jmonoe) v Ajpear SI steoq JOYIO YP SupeAp OVA
? — sjeary ‘sa 48978198 L°L



### Page 13


LL 280g ABawug pusndp :Z so1doyy

wi9Adg 24) Jono

juarens Tuuod spurs wsaduons pue arpears ay) 405 a1PPIU

UN JOAN, “SOpIS aUp 01 {Jo Yt] S193 Osye puLM oy, ‘PapEDY,

‘s1oU09 atp Wo} Y9Nq dUHO9 sIBoq pue “Y>H LIMIO4 v JOY LYS

aiquioaey v 198 z9xou ou, ‘pay ze apIs saypT9 01 Ino Fu

sreog]“1eaq amp Jo yeq| s9ddn ouput Apreqnanyed “wioAog om

{Jo 1no upy 0} spud} PUM DY “FOARY Wards o4p Jo yINoUL ay 1B

18 LeU PreApUTA OU PEA “AHOYS tase amp awoU pares KIqe

~roUo8 auw saavs 94, “UOUILUODUN JOU St K[s91S9m feIUOY-Isod &

ng “N JOANN PUIAS aMp axEI SIUOYY POD ISO “aBessed jeIUOIJ
gaye Kraisnyg auio99q tte9 sarpioisam Suypreaaid Ou
SOLJOISON,

-syreaoud ABarens puta pur uaxins aip S014 <}aAn

-oajJo pula au], ‘pUIN KLJOYINOS B ysUTETE waLND qqo SuoNS

v fares St axotp pu “1Jo] a4p 01 Yovay Jo mo Yayo st JauUEYD
‘yp ang 2103 payqeo St ABawenis aresopout aiow v *qqo oy) UO

‘uous! pra] SUBS

e248 Surpuoy purm ap yay “Iaxind oyp prove or (Kong,

‘e_ ATIOI, JOUOY 01 1910} 1,uUOp) seUIOYL, pure KyJO, Ho.AWIq
uy] dup 9pIsUE Yow) OF St 9H9ED S9q ap “POOL oy ISUIETY

‘yulog StwOUL] puR 1UIOg AIJOY, UIDANIAg A1OYSUE IIT

uv *yoo[9 07 pur spur, “Avg 4p da wysteas [104 1Z—.007

punome spurgy “(A'S 01 So1y weaD0 aus) parvadxo aq 1ystUI sv

‘ypnos a4f 0} RG 104 SBOP 1F *sPIENg 2Z001q 94p SY “PULA ISAK,
‘IMOg 01 YMog B SOLOJUIAL PU [TY [ILM az09Nq FS OY
aZaAIg BAS ISAA\ YINOS/INOS

“r9u109

yo] auf ploay “TwaLIno a4p UE 990 I4BLE AeAS Ing * yuaLIND BYP OF
793 0} [OUUBYD UTEUE aq OF [Hes “TUALIN punogino UE YA

ys up S1oAty os[e Y90]9

01 Kouspuay, “970019 d90y [INS pur jaLINd aUKOS PIoAv OF 14ST

vs 01 s9119q su19as a] -Paquosap rsnf aynod afout9 18ax3 01 sPHd|

Uuoyo siqp pue ‘[ouuEYo UreUE ayy UI WaLIND 4p PIOAE 01 B10Ys
uwroysea oxp 0} 280[9 A194 108 ySNUU NO NALIN oyP ISUIETY

‘aino4 9fo4i9 was axp aye 01 Aska pue—wod oo no oR 01
Injured 11 Supyeur pure preoqueys Suny] ‘asoyp K\soyINos O10 puE
sonysT] UNIO} spusy azaa1g OY, BOYS worse Oy PIEAOY UE sey
00) Sumas Jo aremag “eq ay) ssosde AyjeUOTEIp sn soyE) PULA
sty) aours Sueyodurt st waxing “Buons you Ing AyrYs AIpeuUas
aut SpuIM nog o1 Ise YIMog “9oxId UE ApwALy st Wioned JoyreIM
oUNO OU LDH} 10 KpaMNOS SuyueAdud Jo doy uo ut SaUOD

azaaig Bag YINOSs/seg INOS

“keg aywadesay wo Buses

08 nox uayas aorape a1Barens Kw MoIJOJ 01 YSNOUD Ys![00}
‘am nos JI nos aavs poo ‘suorssarduuy Ku axe SULMO|IOA,
JOWIEIDSIC

(28d sxau ays uo tanya ayy 01 40fox) S21Qr

pn aip Jo ayoF v Zuryeur sauMoWos “WuaLIND ay Uo 192yJ>

Big v ancy spuia auf eq axp sso.9e Kjopim Area pure Tuons

Uunu squouin a4, ‘SypSuians |e UE pue sturod ype WOsy ALO
Spuay ‘auoqp Sutoes Aww Jo aSoUK Op o1 wads J UoYAN “ey AUD UF
syuoyy pjoo Aq pasaneg 9q 01 yuoU YsNoUD Jy pur ‘S9z92I9 BAS
q paroaye 9g 01 ue990 ay) oF YSNoUD asoj> StI] ‘onUDA SUNS
SurFua|feyo v s1ayjo eq waxpIOU ax, “sHHodeuury Jo Ino “Keg
aywadesay.) uo oa) 40 Enea B ade | SWISH 109 YOR
syodeuuy ur Suey :a8papmouy [e907]

20t4 plnows | suonIpuoD SUIS pure sIBog ay BuLIOA0D
soyeurtueay Ku Kq soda Jo SuaZ0p 01 19}a4 pyn0d J “ajduexo 405
“uowsog Ur JoATY Sa}eD a4p| Uo UIE JUIN | UOYA ORE] “YOO
-o10u 8 o1u pajiduioa aay suodar eneas om [TY “paytes om ees
-a Arana 10} uodar ener v ayjdwuoo 0} sn pasnbay “urureluog,
2aaig “ureideo wear ano ‘apex ve AuperSayjos paoes | UOyAN
“J0} payfeo st yoy ABowens ay
‘MOUY pur suONIpUOD [eD0] 71UTODAI Oo} WIA] JSNILL NO, “98P
-1mouy [voo] to spuodap vam [e90] w Ut ssAdINS IUOISISUOD

adpa|mouy [220] 6°L



### Page 14


61 2804 ASamug panda :Z sardoyy

{SoyNpeULMPY Paso[D Koyp douIs SMO] U9Eq aAvy

SUryspoy Oy) YD paonioU NOK aavf{ “A UO [[eqIOO} YIEA UOT

‘sues ures op [HUN sMopuIM ULOIS ou UE Ind ‘Xap AvIs ‘oWOY,

Keng “kom oup Uo St ureY “auns 40} st Bury AUG “sazaaaq eq,
Jo YMOUyIP pue apyoy row ayy Suowre ose sarpIOIseD OULL,
pul Aposeg

-siryax Aeq ay

sv yensn ueyp JoSuous yon pue sBuo] una Kew! YOK POOL,

‘tf ageaog ing ‘gga uv JO} Yo] JOTeM JHE 9q [ILA azaK Aa

-yuiou Suons v Joyy yeu stp o1 Kem ay Uo jouUEYD urwLE oy)
‘$8019 0} OARY [TIM NOX sv ‘GOIDeY Big v aq UD JUALIN Oy],

‘ssopeoy Apoyyiou 81g pur axoys ay Jo

synd Kpraisva opjory ur Jayjns 1ydus ayy uo asoup a[HYM ‘9SsPUIq

‘dup Woy UMOP [for YoIyaN sd KpoyLIOU ayoUr £q paroALy

‘aq [IE apis pury 149] oy to4y Od UO UF ZUTWIOD sIeog Wag oy

Jo JIPY UDA oUp UT “UO J97e] Wa;qosd & aq [ILM IYSE oy 2104S

‘Waiseg oy JopuN jas st yseUU ayp JL Ng “Boj ay) UL ATWO Jo Ked

Aout ABoiens yeyp pur ‘Wyse oF OF st uoNMAduID) JUL, “IseayLOU
24) 01 Yo0I9 Illm az0919 94p Sape} PULA [rIUOY aXp SY
PUIAA ISP YON

“ypBuans si ysturunp Kew purm ayy

ysnowp ‘pooy v Jo oFeuvape ayPI 01 1YSL OD “go UE proae or

yoy Arig soIoNy Fig v wod9q ULI ALND “LYS wostsied yp

jo asvjueape oye) 0} ABorens v uepd voy BuLyoo[9 St PULA Up IT

“vq oyp Jo ued uado aup ut azaaig sanaq 9q osye Kew aso 1g,

sTeyOUAA Yo STL Wod owos aq Keur aratp aBpuQ ayy MO]Oq
jos YEU aD IIA “ABarENS poxy ou st aay APoyYOU v Uy
PUIAA UHON

“your ou OUT YON payr] B pur od oF You) v But

-moy[e “suapeay pmoqaas amv synd auf, “WaAag amp Woy snd

{Jo oreas ur Jo] aup O1 WuLAds w UaYO st dae ayp axoKp WO, “98E)

Sueape ue Sumure® ou ayn dn sieog ayp yum syt] Yo" pABOQuEYS

9q 01 puay azoup au] 4p 4Jo uRLUOD “ISb9 BYP Og NEAPH WO

4 Avg |eGau|AA JO YINoW a4p Ve 19s St Yo pseApuLN axp Avq

-pIu UL UIs t WOIL| “Burptes 189q s,1aK ays Jo owos aprAoud
SPULN “AVN Suons ayp [ey oMp UF aBessed [RIUOY vy
PUIAA IS9A\ YON

"VN 9tp1 01 273019 aU) Y90]9

01 puat []}m 1uoY} ZuoNs Vy “uooUIDye 4p UI “NY's amp 01 970019
‘ip ysnd Keur azaaig vas ayy Yeon st aBessed [eIUON xp JL

Fo] amp Jo

dor amp re azaaug a10u 10j kpear ag ‘axoys tarseo a4 UO UY
JOAL up £q J9BUONS 99 01 SpUdI PULA a4p “SO1 9189 OH UL

ouUreyD urPAL akp UL TUALIND 4p YS} OF

‘aaby 01 Tuva J,UOP NOK pure aIOYS Worst 9up HO JoWyTH] YORU

.9q 01 spuar pula uy, “(qa Ue Uo yLIOU ‘pool & Uo YINOS YOM)

Boy Oyp UF are] AE yA SuyLWS a1v NOK auns OCU OY Kw JUALIN

94) 40} 19aL10919A0 “EAL OU}. aU ABuONS SUN AND

ULL, Ba] premaoy Aure Jo sed sare] ayp Jo ann st Ure Oy,
juauina q pareurwuop st eq ayp ssoxoe YowaL puods OU,

“Gorey # 0g

ov are sind “4y'g AIo¥H1 azour ayp qutog AIfoI, Jopun s2so]9 ay)

340UL 24 Jo uoTSod 24p pur (;A JO ‘N10 “S) WoRDaAIp pum

‘up uo spuadap 1 “dn yeas 01 9[3dnuNs Moy UMop asoup O]LY

Sssouoe yoras ueaq ||IM apIsur S1eOq atp pu WHO AIjO_, apIsUL

auoys aif yo au0d jI1% yynd “AA “S B SaUINEWOS “Y>eas ISIN OM
‘uo Avat stip ino 320M Sceanfe 1,Uop SUL, “ONINYVAL

“noJ9q Wosy dn year oF a1qe aq 01 snoaTeIUEAPE

9q {1a 1 pur “ey pure anya fem 9z90Nq 4p Boj oxy UL IONE]

‘WOANG Up Wd} SPULM BuONS a4) Ur “Boj a4) Jo Ed Ajze OM

Luo Mo| [FBG “19s pure peaye oD ~OyeUUs w 405 1Y8N O01 sade

Bo] ayy ‘shop Aroisnyg up uo Kpejnonsed “sow pawaypurar

‘up Surpunos saypy “Iwog Kyfo, Jo aSea pur yNos ‘eg om
Jo ayppruu yp ut 19s St yseuH YoRaL oMp “Sede a|SUELN 10.1



---

## Chapter 7 2_2.pdf


### Page 1


Cuapter 7: Upwinp STRATEGY

7.1 Introduction to Strategy

Strategy ys Tactics

Strategy is our racing plan based on wind, wind shifts, and
current. Tactics, on the other hand, are techniques we use for
Positioning and control of other boats or groups of boats.
Strategy involves the big picture; tactics focuses in close.
Strategy is long term and planned, tactics is more immediate
and spontaneous.

Strategy is Wind, Wind Shifts, and Currents

‘There are three factors in planning strategy. We look for
better wind. We try to take advantage of wind shifts. And we
try to get favorable (or not unfavorable) current. The relative
importance of each factor depends on how variable each is
(Fig. 1).

7.2 Predicting Conditions

Our strategy is based on the expected conditions. The
‘more accurately we can predict the wind and current, the more
confidently we can form our strategic plan. As we discussed in
Chapter Two, our predictions are derived primarily from our
own observations during the hour before the start, and our
experience sailing in a particular area. We revise our predic-
tions as we continue to observe conditions during the race.

The figure shows a sample Wind Graph based on our pre-
race observations. By carefully tracking the wind we can more
accurately predict the wind for the race (Fig. 2).

Predictable vs Unpredictable

One issue in our strategic planning is our confidence in
our forecast. When conditions are highly predictable, we can

Wind Wind Shifts Current

Fig. 1 ~ Strategy vs Tactics. Strategy is our racing plan based
‘on wind, wind shifts, and current. Tactics, which we cover later,
involves implementing our strategy and dealing with other
boats.

pursue our strategy with conviction, When we are unsure of
‘what to expect, our strategy will change. First, we would not
pursue the strategy as wholeheartedly. Second, we would
devote more than the usual amount of attention to watching for
changing conditions which might require us to change our
strategy.

Our strategy will depend on the predicted conditions and
our confidence in that prediction. When we are able to predict
conditions accurately and confidently, our strategic planning is

Page 54 Performance Racing Tactics



### Page 2


> 7.3 Wind
Wind Strength

Find more wind. Sail in stronger wind more of the time
and you can’t lose. There are several things to look for to find
more wind.

Look for wind on the water. Stand up in your boat and
look upwind. Puffs create dark patches on the water. Itis
tricky to distinguish shadows, changes in bottom color, and
differences due to sunlight; but the wind is there if you can
pick it out.

The wind changes near shore. Most of our racing is done
close enough to shore that winds vary across the course. Often
there is better wind near shore, When the wind is blowing
onshore the thermals near shore create more wind. In an off-
shore wind the thermal mixing near shore sometimes pushes
the stronger winds from aloft down to the surface. At other
times the wind is lighter near shore. By paying attention and
keeping records, you will be able to anticipate the change in
wind as you get near shore.

Clouds often bring more wind. In partly cloudy condi-
tions, there is often more wind at the edges of the clouds, and
less wind directly under the clouds. In a clearing northwest
wind with rows of cumulus clouds, there are usually down
drafts of stronger wind around the clouds. If you see frontal
clouds or building cumulus go to them—there is wind at the
edges, but less wind beneath them.

The Favored Side

‘A windward leg will often have a favored side, Boats
sailing to one side will have an advantage due to favorable
wind, wind shifts, or current. Sometimes it is difficult to antici
pate which side is favored. After observing the first leg we will
have a better idea for the second time around. If conditions

Left Right

z

Fig. 3 — Often there is a
favored side. We sail to
the favored side of middle,
but avoid the corners

don’t change, then we would expect the same side to be fa-
vored again. Also, after seeing particular conditions in a local
area a number of times, we will be able to anticipate which side
will be favored (Fig. 3).

Time Out for Terminology

Before we go on about the favored side a few details of
terminology must be cleared up: The favored side of the course
carries some strategic advantage. The favored tack takes you to
the favored side. This should not be confused with the long
tack, which is the predominant tack on a skewed beat, (i.e. a
beat where we spend more time on one tack than the other.
Often itis strategically correct to sail the long tack first ~ that
the fong rack is often the favored tack. At other times the
favored tack might be the short tack (Fig. 4)

Page 56

Performance Racing Tactics



### Page 3


™ 7.4 Wind Shifts

‘The second strategic factor is wind shifts. Shifting winds
allow us to reach the windward mark more quickly than we can
in steady winds.

When the Wind Does Not Shift

When the wind is steady then the distance we must sail to
‘an upwind destination is fixed. We will sail X distance on
starboard tack, and ¥ distance on port tack to get to the mark.
If the mark is straight upwind, then X and Y will be equal. If
the leg is skewed, then they won’t be equal.

‘You can sail all port tack, and then tack to starboard, or all
the starboard tack first, or you can tack back and forth. In the
end, you will sail X distance on starboard, and ¥ distance on
port tack to get to the mark. (Fig. 5.)

When the Wind Shifts

The wind shifts, and it is good. Wind shifis allow us to
shorten the distance we sail to an upwind mark.

‘When the wind shifts, our closehauled compass courses
change. With each shift one tack is lified up above its earlier
course, and the other tack in headed below its previous course.
‘When one tack is lifted the other is headed, and vice versa.
(Fig. 6).

Our goal upwind is to sail each tack when it is lifted. By
sailing the lifted tack, we sail a more direct route to our upwind
destination (Fig. 7).

Sail to the Shift

‘The fundamental upwind strategy is to sail toward the new
wind or wind shift. As we will see, this strategy keeps us on the
lifted tack. The application of this principle changes with
different types of shifts; but the fundamental rule—sail to the
shift—never changes,

Fig. 5 — Sailing one mile
directly upwind in the absence
of wind shifis will require
sailing .71 miles on each tack.
(For a boat tacking through
90°)

Page 58 Performance Racing Tactics



### Page 4


Fig. 8a — In a persistent shift the wind
shifis continuously in one direction.

‘Types of Shifts
d shifts are generally categorized in two types: persis-
tent and oscillating. Persistent shifts swing gradually in one
direction, like the hands of a clock. A shift to the right is a
clocking shi a shift to the left is called a “back.”
Oscillating winds shift back and forth, like a pendulum.

(Fig. 8 a, b)

From experience we know the real world is more complex
than simple oscillating or persistent shifts. For starters we are
going to look at strategy in these two textbook types of shifts.
After that we will look at other variations,

Persistent Shifts

The basic strategy in a persistent shift is to sail to the new
wind. As the wind gradually shifts, one tack will gradually
deteriorate, while the other improves. If the wind is shifting to
the right, then port tack will be at its best, and deteriorate over
time, while starboard tack will get better and better. We would
sail port tack first, before it is too badly headed, and sail star-
board tack later, when it is most lifted. (Fig. 9)

Fig. 8b— In oscillating shifis the
wind swings back and forth

Oscillating Shifts

The basic strategy in an oscillating breeze is to tack with
the shifts. As the wind shifts one tack is lifted so we can point
closer to the mark (or average wind) while the other tack is
headed further away. When the wind shifts again the advantage
will be reversed; whenever one tack is lifted the other is
headed. Each time we come about we are sailing toward the
next expected shift — sail to the shift. When the wind is from

the right, we sail lifted on starboard tack, toward the next shift,
which is expected from the left. When the left shift arrives

starboard tack will be headed, and port lifted. We tack
and sail lifted on port, toward the next shift, from the right, and
soon. (Fig. 10)

By coming about when headed below the average course
and sailing on the lifted tack, we can take advantage of the
wind shifts to improve upwind performance. We use the term
staying in phase to describe the process of tacking on the
headers and sailing on the lifts.

Sometimes the wind shifts gradually back and forth. This
is seen most often when the winds are coming over open water.
We tack as we are headed below the average heading. At other
times the shifts hit all at once. We see this when the shifts are
coming off shore, or in the northwest winds after a cold front.

Page 60 Performance Racing Tactics



### Page 5


Persistent Shifts
The strategy in a persistent shift is to sail toward the new
wind. If the wind is shifting to the right, then go right. If the
s shifting left, go left,
Sail Headed

continuously getting

the other is getting lifted. Our strategy is to first
sail the tack which is getting headed, then sail the tack which is
getting lifted. Why? The tack which is getting headed is getting
worse all the time. It is headed now, but will be headed more
later. Sail it now before it gets worse. The tack which is getting
lifted is improving all the time. If we sail it now we will be
missing a better lift later.

Are you Sure it’s a Persistent Shift?

How hard is it to split with the fleet and sail into a header?
Without our pre-race info, weather forecast, and/or observation
of other boats on which to build our strategy, it would be crazy.
Even with good information and a well thought out plan, it is
hard to stick to your guns as the fleet tacks away. If you know
what is coming, then go to it, Position yourself to the favored
side of the fleet.

The Rewards

How much do you gain by sailing into a persistent shift? It
depends how far the wind shifts and how far you are separated
from your competition; but in a word — plenty.

Persistent EXAMPLE

We know from our Wind Graph that the wind is gradually
backing. Our starboard tack readings for the hour before the
start show a trend: 30° > 25° > 20° > 15°. The port tack com-
pass readings are similar: 120° > 115° > 110° > 105°. Starboard
is getting progressively headed, while port is getting lifted. The

Sail to the Shift

‘Coming off the starting line on starboard tack our com-
pass reads 10°. A few minute later it reads 5°, and soon after
that, 0°. With each little header some of our competition tacks
away. Some tacked to port on the first header off the line.
Others have gradually bailed out as the header continues.

Eventually, with the compass reading 0°, we tack over.
Our course on port tack is 90°. We are short of the layline to
the mark. Gradually we are lifted, first to 85°, then 80°, 75°,
and finally 70°. We are lifted to the mark, far ahead of those
who tacked out early.

When should We Tack?

The choice of where to tack is a little tricky. Theoretically
We want to tack so we will be lifted exactly to the mark. This
curved lified layline would give us the full advantage of the
shift without sailing any extra distance. This is a tough call, to
say the least, A more realistic approach isto tack short of the
layline. Then, as you approach the mark, tack out again, and
take another guess. Don’t overstand or you'll be sailing extra
distance. As you get closer to the mark, you should be able to
make a more accurate layline call.

Another (tactical) perspective on where to tack is to
maintain position between the fleet and the shift. Don’t sail to
the comer—just get a controlling position.

So Much for the Competition

Coming off the starting line on starboard, we gradua
got headed. Some of the fleet played the header as an o:
ing shift, and tacked out. They expected to be headed again (on
port tack) before tacking back to starboard. This was a big
mistake, We knew from our Wind Graph that we were in a
persistent shift. We used persistent shift strategy by sailing into
the header, towards the new wind,

Page 62 Performance Racing Tactics



### Page 6


Osciiatine EXAMPLE

Pre-Race Data

In preparation for our 12:15 start we periodically record
and plot our wind information. Using the closehauled compass
course on each tack, we are able to calculate the wind direc-
tion. The Wind Graph from our Race Planner shows the follow-
ing (Fig. 12)

+ An oscillating breeze, shifting back and forth.

+ Starboard tack headings ranged from 170° to 185°.

+ Port tack headings ranged from 260° to 275°.

+ We tack through 90°; from 170° on starboard to 260° on
port, or from 185° to 275°.

* The wind speed is a steady 8 to 9 knots.

Stay in Phase—Tack on the Headers

Coming off the starting line, we are sailing on starboard
with a compass course of 180° to 185°. These are high numbers
for starboard tack, which means we are lifted. Gradually our
course drops to between 175° and 180°. This is an average
course, neither headed or lifted, and we can sail on either tack.

Soon the crew reports that our course has dropped below
175°. Other boats are showing similar angles. We are headed.
We tack. As we settle on port tack the compass reads 260°—
265°, low numbers which mean we are lifted on port tack
the numbers rise, we are getting headed. Remember: Port,
Higher, Header. When our course falls below our average, we
tack again and sail lifted on starboard.

As the plot shows, we continue tacking on the headers in
the oscillating shifts. Gradually we find ourselves to the left of
the middle of the course. We use the time when the wind is at
the average direction to sail on port tack, which returns us to
the middle. We sail on starboard only when lifted above 180°;
we sail on port for any heading between 260° and 270°.

A New High!

Further up the leg, we are sailing lifted on starboard.
Compass readings show a course between 180° and 185°.
Gradually we are lifted to 190°. At this point lights should
flash, bells should ring, and sirens should sound. 190° is
beyond our range of oscillations. We are lifted higher than ever
before.

‘We may have to reevaluate the conditions and modify our
strategy. What is causing this new reading? Helmsman error?
Changing weather? Are we closer to shore? Are there any new
clouds? What is going on with the rest of the fleet?

Is this a momentary aberration, after which we will return
to earlier conditions? Or is this the beginning of a persistent
shift? Perhaps the wind will continue to oscillate, but over a
new range or wider range.

The key is to first recognize that something new is hap-
pening. The next step is to evaluate the change and make plans
accordingly. Ideally we would have seen it coming—either
from wind on the water, an expected shift near shore, or by
observing other boats (in an earlier class—we are leading our
fleet, remember).

‘The Impact of Shifts—Don’t Miss Em

Meanwhile, one of our competitors has sailed off the line
on starboard tack and continued one third of the way up the leg
before tacking. From there he sailed across the course on port
tack, to the starboard tack layline. Ignoring the shifts has left
our rival out of phase and sailing headed half the time. On the
other hand, he has only had to tack twice! On a two mile beat
with 10° oscillations, a boat which sails in phase will be min-
utes ahead of a boat which ignores the shifts. That's even after
we throw in the cost of a couple of extra tacks!

A little later, we'll pull out our slide rules and find out just
how big a deal wind shifts are, but for now, just remember:
Track the shifts, and hit ’em!

Page 64 ~ Performance Racing Tactics



### Page 7


Other Types of SI

As we said above, pure persistent and pure oscillating
wind shifts are quite rare. There are infinite variations.

One variation is a mix of persistent and oscillating shifts.
This mixed condition is characterized by oscillating shifts
gradually shifting one way or the other—veering or backing —
over time.

Several other types of wind shifts occur. One is a major
shift where a new wind completely replaces the existing wind.
This can happen suddenly, or after a period of calm. Winds
vary in other ways. There are geographic shifts caused by the
configuration of land, and thermal wind shifts created by the
heating of land. There are also differences in the wind due to
differences in current (as we will see below), and there are
shifts caused by the movement of weather systems.

Mixed Conditions

In mixed conditions, combining both oscillations and
persistent characteristics, the strategy is to sail toward the
persistent shift while still playing the embedded oscillations.

Part of the trick in coping with these mixed conditions
to realize that the range of oscillations is gradually changing.
The high and low numbers on each tack will be increasing or
decreasing. What was once a header may now be the median,
with a new lower header on the way.

When conditions are too confusing to diagnose, the fall
back strategy is to sail to the mark. Which ever tack takes you
closer to the mark is preferred until there is reason to do other-
wise.

Mixep Conprmions Exampur

Here is an example of strategy in mixed conditions (Fig. 13).

Pre-Race Data

‘Our pre-race data is listed in the Wind Graph. It shows
mixed conditions. The trend is veering, but we have oscilla-
tions as well. Our strategy will have to consider both, we will
also have to keep a keen eye out for changes in conditions. One
thing to look for is stronger breeze to one side. Is the trend
shifting and building (as in this example) or shifti
fading.

And They’re Off

Itis interesting to see the different strategies which
emerge from these difficult conditions. Some of the fleet will
treat the beat as though they were sailing a persistent shift.
Others will tack on the headers. Some will try to balance the
‘mix. And still others will be confused and uncertain of how to
handle the conditions.

As the fleet moves up the beat in mixed conditions, the
apparent leaders will change with each shift. Often it is unclear
until the last shift of the leg who will come out ahead.

Keep Fighting

In mixed conditions you are never out of it. Keep work-
ing, keep trying to decipher the next shift. There are plenty of
opportunities to catch up (and more than enough chances to get
confused). If you find yourself baffled, try to regroup. Every-
one will have their moments—if you can keep from going to
pieces during your bad moments, you'll have another chance
for good times.

Page 66 Performance Racing Tactics



### Page 8


Fig. 14— Offshore winds tend to shift
‘more perpendicular to the shoreline.

Fig. 15 —A city or hill can
create oscillating shifts, with

Fig. 16 —As the land heats up, you
get a persistent shift as the prevailing
wind shifts to the sea breeze

bigger shift near shore. direction

Geographic Shifts

We do most of our racing near shore, where the interaction
of the land and water affects our sailing wind, Further offshore
conditions are more stable and predictable; but along the coast
wind conditions are dif

‘There are many ways the shoreline changes the wind.
First, the shoreline funnels the wind. The wind shifts to follow
the shoreline. Second, offshore winds tend to s
pendicular to the shoreline (Fig. 14). Third, winds shift around
obstacles such as hills, buildings, and thermal domes in areas
with lots of pavement (Fig. 15).

Fourth, the heating of the land creates thermal winds—sea
breezes—which blow towards shore during the day.

Fifth, the thermals create turbulence and mixing which
can pull the upper winds down to the surface. These upper

winds are generally shifted to the right of the surface winds (at
least in the northern hemisphere).

The effect of these geographic changes can be either
persistent or oscillating. In offshore winds, there will com-
monly be a mixed effect—with puffs coming from shore lifting
the tack which is parallel to shore, and with those lifts being
stronger the closer you get to shore.

‘The thermal effects on an onshore wind usually create a
persistent shift from the prevailing wind direction to the normal
sea breeze direction (Fig 16).

These shore effects are described in more detail in Chap-
ter 13: Weather later in this book.

Page 68 Performance Racing Tactics



### Page 9


7.5 The Impact of Wind Shifts

Itis often difficult to predict the wind. Is it worth it to try
to figure out what the wind is going to do next? How much
difference does it make?

‘The Impact of Persistent Shifts

We'll assume here a course set to the wind at the start,
with incremental shifts to the right. For the initial segments
boats make equal progress upwind. Then the wind shifts 5° to
the right.

The boat on port tack, going right, is headed. The tacti-
cian struggles with his own convictions, and resists the tide of
sentiment to tack on the header. Meanwhile the boats on
starboard are lifted up toward the mark ~ well OK — wouldn't
tack now! They sail on

Another shift, further right. Finally, the tactician going
right calls for a tack. Now they are lifted on starboard ~ higher
than any lift they'd seen before the start.

The boats going left are in a quandary. They are lifted,
but the wind is going right. The black boat bites the bullet, and

. It is very hard to tack when you are lifted ~ if you don’t
me, you've never tried it. But it is the right thing to do.
If the wind continues right, then there is nothing to be gained
by continuing to the left. Cut your loses, and sail to the shift.

The grey boat carries on, hoping for an oscillation. Its a
gamble ~ if the persistent shift continues, his position will g0
from bad to worse. He’s sailing the great circle route and will
never get a good angle to sail to the mark. But, BUT, if the
wind oscillates back, (oh please, oh please) even for just a
short time, he can recover nicely. (Fig. 18)

Ye

Sea

Fig 18 — Persistent shifts — sail to the new wind!

Here are some numbers, assuming a 5° shift every 5 minutes, with the
boats sailing at 6 knots: After 20 minutes the checkered boat will be
1.5 miles upwind of the starting line, and over 1/4 mile ahead of the
black boat. The checkered boat will be on just 1/8 mile ahead of the
grey boat, but that lead will be growing quickly.

The black boat would be expected to cross the grey boat when he tacks.

Page 70 Performance Racing Tactics



### Page 10


Fig. 20 Currents are created by tides and rivers. They run
stronger in channels than in shallows, and can be a major
strategic factor.

7.6 Current

Current adds complexity to strategic planning. The
obvious, and primary, strategic concern is to seek out better
(more favorable or less adverse) current. When the current is
not uniform across the course, it can be an overriding strategic
factor. Currents run stronger in deep water than in shallow, and
faster in narrows than in open water. Below points and around
bends, eddies can develop. They can race across flats. Adding
further complexity is the fact that currents change. Correct
strategy can change dramatically over a period of hours,

Storms and strong winds can distort surface currents and delay
tides, sometimes making tide tables useless (Fig. 20).

Fig. 21— Wind can create current. Wind driven current can
exaggerate or reverse tidal currents in shallow bays. And it
can create currents where there otherwise would be none.
After the wind has pushed water to one end of a basin, the
current will reverse when the wind subsides.

Wind Driven Current

Currents are not limited to rivers and tidal basins. In the
Great Lakes, for example, currents of one full knot are pos-
sible. Currents build when strong winds drive the surface
water. After the winds abate, the currents reverse as the water,
‘which has been stacked up at one end of the lake, returns to
level (Fig. 21).

Uniform Across the Course

‘When the current is uniform throughout the course, it
affects the laylines and sailing angles to the mark. If itis
running across the course, then it can also change the balance
of time spent on each tack (Fig. 22),

Page 72 Performance Racing Tactics



### Page 11


Fig, 24 — When current is not uniform, take advantage of the
shift in sailing wind. In this example we have 10 knots of wind,
1 knot of current, and boats tacking through 90°. The current
gives one boat a 6° lift, the other a 6° header. The lifted boat's
VMG is 20% better than the headed boat's. (VMG is normally
71 of boat speed. The shift is 6° because arc-tan 6°= 1/10.
A 6° lift creates a VMG of .78, a 6° header creates a VMG of
163. .63/.78=.80. I'm glad you asked.)

In tidal areas the advantage can be fleeting—or reverse—
‘over the course of a race. Obviously we need to pay attention
to changes in the tide.

Changes with Wind Conditions

‘The wind can upset current predictions, particularly in
shallow water. A strong wind blowing over a long period can
overwhelm tidal effects, pushing surface water and delaying or
reversing tides. When the winds abate, the current distortions
will remain until the water has had a chance to return to level
by flowing in the direction opposite the earlier wind. Winds
can also create currents where there otherwise are none, as
‘mentioned above.

rue True | Sailing
yind Wind | \Wina

tue } Sailing Wind
Wind

Current

wf

Fig. 25 ~The vector of the current is added to the true wind to
create our sailing wind.

Effects on Sailing Wind

Current changes the sailing wind for a boat. The saili
wind is the sum of the true wind over the bottom and the
current. When sailing upwind, the net effect of current on the
wind reinforces the effect or the current. A favorable current
creates a favorable change in the sailing wind, and an adverse
current makes for an unfavorable change in the sailing wind
(Fig. 25). Details are explained in Chapter 13: Weather.

Develop Local Knowledge

One key to success in current is to develop local knowl
edge. Keep records of how the current runs in various wind
and tide combinations. Our strategic plan is only as good as
the information itis based on. Accurate current information is,
critical to good strategic planning.

1s

Page 74 z Performance Racing Tactics



### Page 12


How Many Can we Pass?

When you find yourself at the wrong end of the fleet,
don’t get depressed. You are in The Land of Opportunity—
there is a whole fleet of boats waiting to be passed. Don't wait
for a miracle to save you. Get to work and grind ’em down,
one at a time, You're not going to win this race; that is no
longer the goal. Actually. winning is redefined for this race.
Winning is passing as many boats as you can.

Sail Fast & Go the Right Way

Don’t panic. Settle down and work on boat speed. You
will not pass anyone without good speed, Concentrate on
speed, and you should be able to knock off a few tail-enders
easily.

Go the right way. In The Land of Opportunity you must
concentrate more on your overall strategy than on immediate
tactics with those nearby. Upwind, figure out which side of the
course is favored and head that way, Back here itis hard to sail
the middle; all that gets you is traffic and bad air. You must
pick a side. Do it carefully—you can’t afford another mistake.
If you are not sure which way to go (maybe that’s how you
landed in the Land of Opportunity), look to the leaders for
guidance. The leaders are probably doing what is right — hint:
they're in the lead. Others will gamble against the odds in
hopes of passing the leaders. Our goal is pass the gamblers.

Sail Clean, Fast, Smart

On the reaches, you can save distance by sailing the
thumb line while letting others waste distance sailing high and
then low. Avoid luffing duels, plan well ahead for the inside
Position at roundings and, above all, keep sailing fast.

Running legs offer an opportunity to attack those ahead.
For all you need to know about Running Strategy and Tactics,
skip ahead a few chapters. There are real opportunities here.

e

@

@ N
Sf)

AN oo
VN @G

Fig. 28 — When you fall behind (as on the previous page) get to
work, With grit, determination, and a little luck, you can reach
The Promised Land.

The Promised Land

Hopefully you've fallen behind early, so you have plenty
of time to catch up. Play the shifts and work the favored side:
and keep sailing fast. Position yourself carefully to pick up a
few boats at each mark rounding. Look ahead for changing
conditions and be ready to respond.

Every boat you pass is worth a point, and it is easier to
move from 15th to Sth than it is from Sth to first. When you
find yourself in The Land of Opportunity, keep cool, sail fast,
g0 the right way, and avoid confrontations, You can reach The
Promised Land. The End (Fig. 28).

Page 76 Performance Racing Tactics



### Page 13


Chesapeake
Bay

Page 78 Performance Racing Tactics



---

## Chapter 8 1_4.pdf


### Page 1


SdL, ONITUNATUAG ANY ZINO 68
SOMOV I, TIOW ON §'8
AYVWLHDIN S.NVIOUIVE VW LS
ANIMA QQ STINN 9°S

SNOdVAM TVIMIVEE 68

LWA FHL dQ SNE £8
SHTAIONIAd TWOLLIVE, €°8

SLAIHS ANIM 4O LOVAW] FHL TS
NOLLINGOALNT [8

Y Y
SOILOV, UNIMdA(Q) “9 YALAVHD



### Page 2


£9 8nd sonony pundy :g s01dou9

sapSup Supyoo1 saqouivu 40f 2p]
aSunyo staquinu ayy ySnoW °,06 YP! S104 SPUMSSY :2ION ex

-sapysuoo nq YO] @ OYE

‘uroas eat uoreredas Jo 129} BFS 9} ZIT 99 PINON sso|fULES
‘up 3994 gps £q parnaedas axe s1B0q ON JF ‘2|CUIEXO 304]

(¢-Big) getoteaud ame SossoysutEs amp 2OURISIP

‘pjwars v £q poremmdas s1v0q Jog “Spud Cz St UTES xp SPIEA QOL

{kq paneaedas pure ‘aT ures amp UO steoq JO-f «"steoq amp Sune.

"das OoUstp [e19TR] OY) JO YSZ SUES IIYS yp 01 F9S0]9 1809
‘yp OF StS PULA. Mp HoyAA "BUUaTaeIS axe SaOURIS!P OL

{MMS B UT (@S07] 40) UTED NOX Op YONA MOH,

atoms “s100q ayt ua2sG—q aoUDISIP
ays fo p62 81 (s80}) v8 ays 4s OL ? UI “suND8 ys 241
oy aasoja nog ayy ‘Yfiys 24) a40faq Wasa 249 siv0g Way A £ BL

YOO! WSF GLE BST BE %0 MIPD%
Sh 00% ST oD! Soo UNS

poaw-ppoc = SUBIS%T UD UY BUNT 8442
aang ut pasvaddn isayfsifiys fo stsSpoun 2ugaMouostAL =

(qq “Btg) ¢240foq soy punay | 2004

auoyay “Yfiys 1x9U ayy 07 [1S “seUt YP 01 198 OF [HPS OL OARY NOK

goueysip ssa] atp pur Jappey amp dn axe nox soyny axp ‘axe NOK

{giys tp 0} 29so[o ayy, “Buns Jomo] v uo dn puo yLYs a4 WHOS}

aoqpany steog pur “Buns 1oy31y & UO St oy—SUIES pula MoU ae
(1 19s0]9 1804. “SareI04 JOPHE] ayy “SIHYS PULA amp UAL
{US 9p WAN ag FLAG UT ABIES

_prayo st pun ‘Suns dot oys wo dn spua ifiys 92 01 128019
ywog ayy, ‘sarv104 Jappn] ays ‘sifiys pur ays UayAN - AC BL
“Suna aus ays wo a4p pusaidn anf Syyonba aap yoryss

synog appo} apis v Surguany> 2421 8} pugewdn Sums - PZ Fey



### Page 3


69 280¢ souany pussy 8 tardy

“BuyoBBers axe sOssoy

sured yenusrod axp “210joq pies 1 SY ‘1Dap 81q D 24D sufiys pusse
‘no spurs 1urod auo ‘saydusexe pu stoquunu |e Yanosy,
iMOM

“(9 Bia) spunyaq anf sv aor

of 01 30 “dn yore 01 papaas st aBes0Ad] sso] yHYS 1983q E

Lup -syoe myds nos uoyAs Uy Spling aFesOAg] ‘a4|sP WLS 9M SO

ang ‘uoexedas Jo yO] v ayy] WADS ABU WHL “(OPIS SHY OF SETS

‘up Jt pur) (p 180g) PUIYAg souUEIsIP OM SUIT {°C St BBLIOAD| SI

THMYS .O1 B UE Ope ax EN UOAA [[Nd ]TEA6 PUIG SE YH

w0q Y “UtYs v Ut aso] 40 UIE oy purys Koup ax0Ur aM pute “OAeH,

sondun 12881q v aavy pynos ys 42881q y “pusyaq sof sv
aon nok ind pros ko sayo ay Ifiys gO] P #ys BuyoyUsuE
sausasop If ‘uouoaup nok tH Ifiys Of 9 HO Wada Dap PINOM
nok ‘punyaq 2ouvisip anos sous 2°68} aBd494a] anos ff - 49 ‘By

p 1904, 1 190q

‘$oup aBe19A9} auout aup ‘are steoq ede soUpY au, “OH
Tesane] Sty aqUDsap 01 aSrzada} WI} d4p ASH IAA “OSEOOUT
asso] pure sure ayy “parexedas 1aypany axe syeoq at UOKLAN
(29 31g) 962 Inoqr—KpyaHs SUIS puLNUMOP
aysrens 1wog 4p ‘4iSulstudins pue *9,91 So] YS 94p Woy
Koave weoq auf *4%GT SUIT LYS Mp 01 39809 120g ef “OT SUIUS
ULM yp uayAd “(E 1eoq) aBeIOAST OW YA “PUuEMUMOP 1YsTENS
2q [fla 10 2(Z 1eog) ys up wo Keane Jo “(| TeOg) ayEYS
‘otf preAson Jou19 puryag IouRISIp oyp OF fenba asesoAoy avy,
1114 puryog 10g aup :s9se9 aantp JOpIsUOD [TA AAV ATT OF dT
‘wou ‘purlyoq aoueystp Jo added w sv Sasso] pue SUES JOPISUOD
“roytuus ame syjnsau ‘soxour Jo praye st 1eoq au0 HOA,

Peay SI Og OUD USUAL

“ys .01 M2 %9I 280] 40
ay6f m8 NOS uays ‘pusyaq aouDIsIp NOK sponba a8v4942} ANOS
“jj -280) ufo} 24) 01 s1004 :up8 4apvay ays fo 1y814 943 01 $1004
1811 syfiys puss ays pun poayp st wv0q au0 UayAy ~ PO "Stef

€ 104 Z w0q



### Page 4


162% souomy puswda

sg sandy,

[ ‘sy]nsou 1ua}SIsuOD rSoUr ap PapLAcad
Aqgeorioysty seq soo aannaduos Jo o1jopuod pax y
“roywam ou Jo Saumiea auf 01 afqns axe YY “SITUS
pur oyqjun ‘Jonuo snoX unypim KjounUa sureutas poadsieog
“str Ss9p tpt anor 2[qel|a4 pur yUaIstsoD a1oUI v aprAosd
uno ‘spmmaai arexpauruut ssoq Suuayo opty ‘paodsiwog
“saAfOssip
{ytys ou se pesioaad e sayyns pue zy 001 ysnd uedp Joye
<aouleistp au) Tey 49eq UIED) 49s0]9 198 asnf 01 JOTIOg SEE
soumtuos *29u0 18 [fe dn yoreo or Any wey JouIeY_“poaus 199
3,uop “gtYs B o1 pea] 40 Yds 01 aouYD v 19 OP NOK LOYAL
-Anrumsoddo sno soy Yoo] pue “waned aq “Isey [:es
‘asojp Ais 08 *(puryaq ey 00) Jou aze nod J1) Auny ve UE ade
-1anay Jo Auajd 198 ued nos ‘roqurouioy “dn yore 01 YsnoUD
aS0[9 04 [INS [11a ueLoHoe Waprud axp ‘ssiur ssapeay ou
ayiys ® yoieo 0) ssi Aunpoddo ue Woy “UaXLL, “2OuEIsIP
Sunyins urppia Avys 01 J9pso ut ‘stope9] ayp sv Kem ues
up of pur “sry 1fes peaysut [fas Ing Axon] SuMee Jo adoy
ur sunyas @ uo Sora ads 10u |[1M UeIONIe WAprud ay,
-pray aup ur pe soy ‘ane Kay, “Cem wyses om Tur08 (ou weEp
uuayjo azouu) axe ssapeay aup se ‘9801 01 Ajoxyy St v9] 1B a1” NOK
‘syjiys pura v uo ured Aru nog opLyAA “ABarENS punos sKeaype
Jou st si9pe9] au Ea Sys" Sumy ds ‘puryoq voy AL
-98es9YOIG NOdSIP Jo WLIOY B Se Y9"I POOS v JO YU — 3809
uonoesuen &
-parvadde 11 se Kpyoinb se ystuea ueo w ‘paziqead st ures om
[HUA “s[PALL NOx pur PULA a7 UdDHIAG SSOI9 PUR YEYS Oy UO
‘your nox Hun poztpeas OU SE ULES oyp “YrYS oyp UO UTES KUT
nog aM “TuNadY aq ued SIyIYS Uo apeLL SUITS OY,
“Sursesoagy au0yoq [[ny UL smyoadsoud amp peoy “SytyS
amyry jo aaquezend v you st 2oueuLO}Ied yyiys ysed yeKp area
‘9€{ “POAfOAut SSL xp Jo YAS aso] you Pinoys auO ‘poured
‘aq und Yoru o[LyAy “SYS WosdyUT eo sytys SuLAU|g,
smysadsord YIUS PUAN

pea] anf uayeaitp 0} aFes9A9] YsNoUD
198 sqeog Sues) 291 3,U0p pur (a10I9q s|tEIep) 49409 asco]
vas) “Yat mo yooroud o1 JJossnok wontsod Uoxp “Y}9] at OF
sy eur amp 40 yiys 1x9U Mp JT IH 9ar0Id djay ued ZuIUORISod
‘tadoud “proj ajqowoswwod v ypte Surptes 24,nOK UAL
“3ur88njd deoy pur “yreaig daop v aye, ‘peaye Jo peowsuy
yorg 400} nok pur ‘swanb [aaj nok ‘oyyeys o1 us NOK *a1o4p
a8 nok 2oUQ “PLD| axp O1 ea NOK YB} pue YorRIOS PuE YON
nog, “si paouariodya on,nok aqXepy “aAnentut axp asoy pure
“pray aun ut 2ou0 sonoe) stOU aueYD SIO} “LOYYO 002 ITY
"(6 Bt) “(An vay oats OF Apeas wi] Inq “Josdut Step S91 01 19K
94,1) ‘peaye Suryoo} daoy ‘syyiys oun Zunny daoy “Burysom daoy
‘Coys inq :woIp puyjaq 1994) ay} 01 UONUOHE ed suordureyo ons
SUL, YOA0d pur 49"q YOO] WEY AAU! OP 1 aAzY NOK Ing “Tay
‘up nia atjds 01 URAL 1,uOp K[UTELID NO, "108 94,N0K pray amp
‘uo Sums pur fous aaisuajop v ou! SuIO3 Ajdunis wey soyre
‘uorysno v ZuIppe pur pray ay) Surymians Jo sua Ut YUN
ang !saX ‘nox puryog asoup oF uOUANE Keq “Praf ay) 198 01 PIP
‘no sump ou op pur “SIpIYs oy ny “sey [HES “aANeRUT ayy dooy
ysnut nox *peaj ayn daoy oy, ‘peat 01 enunUOD ssOpea| [POY
aarrentuy omy dooyy

-yoo) s,z00q Suyjpnas ays 01 asuodsa4

yous &pduns 1uop :sifiys ays oF
po] ‘aays nos 108 soy sBunys ou
Susop daay o1 avy nox 42409 ssnf
juno mos ‘su0uf uy &o1s. OL = 6

puso
——— | juauino



### Page 5


£6230

sonany pusndy :g sasdoyy

“(pL Bt) pul ues NOs JE — YIYS POU OM OF
20g atp peat ‘mo[jog pure Yor weAp JoyPE, “Ea Tuo ay OF
nog jt paxowurey 198 {],NOX pur ‘asopa Avis nos Jt YEG aysy or
ouRYD v 198 [[,NOA JOASUE 94 10U S}_YIYS WuaYstsIed & JO opIs
poioavy ayy wos) Stave SuNyDR, “ASOD Aes pue “SHINY JE UOAD
tuo Suvpy “wa, yore yom nog “oxfeISHUN w ayEULE STOP AY THU,
-gsiom SHaeUL ACU KyUO [IIA AeMe SupA2eI Inq “urMoypoy
quis yureo no yeqp ana St af “PuUlyag axe NOK UoYA apis PAYOR
ny v 01 Suypwes St apdioutsd sip soy uoneordde [eas au
jaaiy ou Jo apis pasoavy axp uo Kes asng IHIAS OF
pou ou st a1oup ‘apis pasoaty 4) UO ase NOK wayAy HAG TE [eS
ysnf nox punore asoup sv 979axq aures 341 [Hes “2104 asa
‘ONL NOS puryog soup UA KeIs “Peaye ase NOK UOU|AY
oor au WIA Aes

“punyaq sayuiny
nok sanvay §uo Sunsyds ways
oa 1y8ta ays Suyo8 st waayf ayn SL
ssaogf ays ysis mds 1,uod = PL Fed

ayy pun

.
“ Sx

-nok day 4a8uoy ou sifiys
‘yopun o1 ayqnuaujna 240
nog ‘suonido fo mo uns nok ‘ouyjcoy
ays yodas nok aug ~ €] “BL

S Ge a

.9q uv9 110 prog peg MOY MOL
1,lop nos *¢9 Jo 199] B Ul ZS HUE preMpuIM ayn poyoeosdde
3xby NOX [UA] ste ABajo 198 O1 ULE] ax PuOKA sIpBUa| 1209,

nay v Buytes Kq uayo !paplone 9q rsnut saute] a4p UIOANIAG ITE
poqinisip pur aougnqan oy “sew axp Yyovosdde nos se “UY,

-ougen Aq a[pprut ay JO No padyoy aq [LLM NOK “SHE “1
amy & Jo {piu axp Ur St uondaoxa 9]qeIOU Wow SUL, “sUOR
-daoxa may ym ‘a[dioutid poo’ v st sourjAey oy) Surproay
(EL “Bug) ytys Aue q uny are nok pur “ene OF ypafqns
aun nox *suondo jo yno axe NOX ‘our[Aey ayy HY NOK 29UQ
sourseT] aq PloAy
“pays ay) YA
Jo] Soo8 appr yp “Ya} $903 Joop ouTUD oy HOY AY “APPAL 931
‘uh Jo a|ppiu oxp st IPH aH, OYJ 941 YPTA SaAoUL OpPPI
up ayy ‘paz0avy Ajiawaq St 9SINOD dtp JO PIS 240 LOYAL

‘apis v yord 01 aany 1y8 jw nos ways, “suouf
ays avau j,uasn nos fi &ssau Saad aq uno ayppH
ays ing ‘s0ayf ys 19809 pun syfiys ay &ojd

uv9 nok saioyyD ajppru ays dn Suupog — Z1 “Bt



### Page 6


56 280d

souony punda :g 40nd

(Oz “Bay imo1r

oxy uappry Atsnoraaud 10y901 psBoqueys JoyyoUL $998 24 YOY

-mauddans s,yboq yora od aup surge ,prAYE OD,, “Aq 3049

jiod aup Saxvas oq pmogues premaay SUL “180g yaeI-HOd e
Sunyproudde are syeog Your-PAwogsels OAL ‘SIN 40} UPIEA
YOUN 1wOg UAPPIH

“29uaHa}sO1UL IMOUPLAL

uo [Hes Nog “IS1yj 10Y90]q aM OTU UN NOK JO} twojqoud v areaio

yfousiou IYI Yor seo "NOK ss0ID WED J9490Iq aM S$0I9

Miva ors auocUrY “YBHOsTA NOX Pdf ITEM 1949019 NOK MON,

jon pa stp] Om [85 ‘S809 NOK JOY 4290}q 19289

ue soyeur ssouo sn ued nog Tog VY ‘PMOID aU O1UE FES nos se

Caio smvog 29) ay OU TT ann [TE 299901 V “(GT ‘Bty) PMID

tn WON} NOK PlA!YS OF (pUeAoaq O1 PUE PAE 10g F) 199014

pau NO, “di Ino uo prRo19 w 39s pure JApInNOYs INOK ONO
‘yoo nox yor 01 Apeax Suma8 a1,N0 pur yod WO a4 NOK
NOX LOI OF, $19} 19D

*(g] Bug) asuodsas mno€ apisap
(01 Yor1 01 7e0g JayO Oyp JOY MEAN 3,uOC] “SHOIDES OFAN pur
Jeans") Jo soquinu v uo spusdap asuodsax nog, {3490 10 YOU
NOK [HIAA, “S901 94 J1 19801 [TIA NOK OY We|A “IC0g [9e1-HOd
sayjour Jo diy axp uo Surpres “you Hod wo ay,nos UAL
amedionry
Stap] [H9EL 21.
*(L1 tg) suondo may ype 1909 ayn ULJJosINok
uty Apyoinb jI1a4 nox way say Zo] WOYS oy) [ES NCA JT
diy snoX uo asoyp ‘Sod pur
“yor 01 a]qe 9q {114 NOX spapeay art NOK JE pur :ysIa}AwUE NOK
pay axe noX J] ‘Sy!yS purm ut sanfuoddo snag pUz oO
Toqkaid aary nox “uonIsod preaoay 0} pure peoye amp] COL
“yur otf we Aforeypauuuy Yor 0162 *YOrR}
progieis v uO {RUE preaaay xp punos NOK UOyA DILOgTTAS
(01 Yor Surzea[9 v ploak oF Kn ‘yDy Wod e st Ba] ay J] “PICA

jatar wouf uappry &snoyaaed 1904 ‘aaaf nox Susavay ‘Isayf wary YysIO [Dap 01 2ADY gypnp 40 'st019
puvoquis puosas v 40f mo ysrDa q nos ist Stays "YoO! Pup “uy Ss04 1292014 nos yay Yoo! S1y ayndyausen ‘10201
‘sauna 1004 PADOGUDIS D UDA — OZ "BL 108 ‘paous » pavsios Suryoo1 way, — 61 “Std od v fo dry ays wo woyy— 81 “8k

fe

&
xX >



### Page 7


£6, 280d souony pundy 9 tardoyg

“you s} uatBas Burpunos oy
(cz “Big) aur] a1 uo Ino Uazo4y BUIOq
uo su op re — a1@ 4099 Sapraoid pod uo ut Sumo “Aq wo
(0) sapiey St a1e wo ]9 yseUr yf} UO SaB19AuOD 19]J 24 SW
“(ye Bp) apisino
aq 0} paysnd 193 0) wou — JURA NOK Jt AONE] UrESE no YoeI
uvo nog — Atuva Yo" 01 JNA, “PAOLO ay} Jo apisino ayy or KEM
‘at [I p2os0] azv nog azojag yous Ing “ued NOK se prey SP APIs
pa1OAuy auf OM ‘peaye SULYOO"] “YALU IUp 01 apIs Pasorn;
‘uy wuo4y au] Aw9fo v PUL) UFEH 2ouO ISMUN ue “apIS Pa1oAry
‘up 01 108 nox se Avjd 0) ur SalwoD woWOTeUELE asINOD
-poods pood pia apts pasoaty oup 0} 103 uv NOK OS JHE IID
jo auvy v Suipuy suraur juouIeZeUEUI os3N0 Pood “ParOAry
st apis ouo swans ABaens snok way “siuourdojaaop arvd

-jonue pue ‘peaye yoo] 01 St aBuayeys oy “1w9q ay) dn sHONo
ano az\seULUNS 0} Pash WL} axp S| JWaKasoUDyY asined
1wo8 rey DAaTyDE
1no€ dyay 01 sonoer asp) “AauoLd oxp urewos pinoys—ABorens
purmdn snos<—oansafgo [e49x0 ou, "waUBas sup Sutsnp
Kvjd our ato oxoge passnasip saydioutid yeonoei YL
-ABoqwans no ansand o} wopaaty 94 UO SMI} WOLURIS
sty) uo sonsey, "yeu prempurA axp re HORISOd Joy SuPpOM URIS
‘no€ un Sonuuod pue PAU ued] 10 YEAS a4 Te SPAOID
ath Jo sv9f9 axe NOK 99u0 SUES TOUTS opp! IHL,

sudioy Bayeang ses OU,

“(€2“3ig) prozey we sv9po we
nog jun You v Avjap 07 uoswar aq |INs Kew a1ouy ‘puvOgres

smorffip a1ow sy28 130 40949
40f 8umuoysod “y1nut ays uo sae1asu0
aif ays so 9] ays ut 40107] ~ SZ “Shot

“puosaq
40 - sauypdo} ays o1 paysnd
Suma® proay “yeu ays oF ways

pun ‘apts pasoanf ays 01 410 40a}
fo sauny 40f pray yoo} 01 paau 11s
nok Sypouony, Barus anos ansand
ea ‘quau8as woq ays Sung - 2 “Sk



### Page 8


66 280d sonony, pund

gsandoyg,

(1¢ 31g) Ava ino [eq warp ATE NOK UO sIwog JOY. aue

axaup slang £11 ayeur pur dn yourd oy a1qe aq 1yBtU NOK “OUD
-nqan} ou pur ste sway UF YoU! amp BuIyovoadde axe NOK J]

“ouiyxey ayy uo aoeds v puyy

nos azojoq 199] axNUa ay ZuPVoNp dn pus |f1M Nog “2He] 001 24

‘our yy “140d 0) doy 01 s0neT [HUN HEAL NOK J] “AUE| UL 4>Bq 193 OF
auyjde] ay Uo woos 9q |INs Kew axaMp ‘Aye Ino [eq NOK FL

“Mou ino [req pur sjasinog Surppry

dorg ‘aqAepy “11 ayeu pure dn youtd ue nok yng ‘aqceus oUN|AE|
up Jo Ays apn B sng “Isowy “AUTLAE] ay) WO 24,0,
Ayre nO Hee

(og “Bta) SHY aU Ae axp Jt SHOMPO FuIso] Jo YSH Oy

je—aouvyo aol aU0 J]asiNOk aAIB NOK “Ino Zuryorr Ke “BOLE

{40}) apsout09 Nok ‘pavoud ayy Yonp puke AUL|AB] a4 01 08 NOK 994

“auyjdv] auf 18 ate peg UI 40 JOUeISIP eA [FES WEI YT “FOIP|
syorg atuioo pur Krave Yor) “OUr|Av] a4f1 UO Pavoud v St U9" JT

“6 Big) sore] oUNAe
ap ous Zunos asoup sues 194901 v Se JOYORI PIBOGTENS OU
Sursn “royeam 01 YOR PUL SSO19 01 1S9q St AE "YOHR§ [a6 FOYE
[pmoqueas yp 10U 40 soYTOYA Moge Iqnop St 2194p JT FYE
pmoqress xp Jo peaye puns o1 ‘moq 2a a4} Wo 40 “praye 481
‘wea aayorn Lod & ‘outfAey ayp Uo st x9x9") pAeOgErS Om JT
fart 9) YOI2} OF [PF
paniajaid st uontsod mog 99} @ ‘ourAv] at) UO,
sauysery ay) UO
(0ZS 199[]09 10U Og “YEU ax unos Jou oq “ydrsseIed UO
yong oF “tonTeMS Jor|sRD smo Jo [esiOAed B axvY ax UaKp “UEC
au Jo Toys syory Jaye Hod oy) JT HEU a4 o1 Pra] Pu Mog
2a] 01 a]qe aq Kew (140d Uo UI FUNLOD MoU) JOON) purOgrES a4
uot ‘auir| ey Your pvoquers ay 0} sites yeog yaeI-HOd aM IT
(gz Bia) fossoaay e quoaaud 01 21g 94 10U
1104 94 uotp “Kysodoud ayno0x9 01 sjrej 30 pasedaud rou st 3049"

3,Uop 1s!

‘poayp nos ind pynos
dfiys rows v pun iv ava ‘paparoad 8} 9uyj6}
ayy fi aud) ays fo uoys you} ~ OF Sty

“reyoq Ds 1D0q pavogunrs ay asm pur
‘ssau9 40 ‘9uyjdD} ays UO 1Doq pavoquDts
p aoq 2a] uo sayo01 uod Y~ 6z “Sty

=u pg ut youd sous
nog ‘Ino j1nq ‘auypsy ays ojaq isnt
apo pog uy fiasinos puaf nos ff ~ [¢ “Bt



### Page 9


101 280d sonony pusndn

-g sandy,

“(Lg “Big) 49A09 01 UWA NOK yor v PENI YorA TROg aUO

Suypioy Uoya [ayasn osye staf “op NOX [HUN REL ayp O1 BUPFor

‘wioxy juouoddo sno quoaaud ue nos azoyss ‘aurjAey ve TUL

-yoroxdde posn stay “Aeave Supyor wouy wouoddo ayp swuosaid
{yotyas diy s,.e0q soyjour uo uoMsod Our you) v St ULd
Ud

“mojaq paquosep

st yoryas ‘uid w yim st puosas ayy, “(9g “Bt YO" Po19A09

{yasoo] 2p [12s 01 uaUoddo xp saeanoou.a StU, 49") 1940

‘uf UO $19409 S00] ple 49H) BuO UO S19AOD IY Jo S:

1s14j SUL Og sOUPOU pay O} Kem o1seg OMNI axe OI9KLL

ist nok

azqunur 0) s19qj0 swaU Avs 01 1UEA NOK “OP ILM SYS Pl

ay) rey Jo UIEUDOUN axe NOK 4 “Keane 103 Koxp Jr uoddey eu
yey Jo [pay am NOK UayAR SuoPE stg JOUIO PDH] NOK

{a op NOK pjnom moy Puy {ey} OP

ov quem nok plnom KYAA “WULF “BUIO axe NOx Kem aus ayp OF
‘01 sieoq Joy}o soTvanooUD Yor anbruyar Kue st TUPI}

‘SupoH

syov1 1D0q
apisuy ays sun Suryoor wus 190q
apisino ays sruadaud wid y~ Le “Sty

“yoo} 4ayso ayy uo
D pun yov1 au0 wo

yas 190g 0 pray uv9 NOK — OF “Bt

“(ge fi) sound
pwanser Kojd nok sw Bayes anos Jo AYSs O80] 40,

‘uayong “o8 0} para no azayar

(03 01 [eats anoX poosoy anvy NOX pur ‘eA Suosm ay Buog

ae nog “seae|d pape axey nok MON “sdeyrad ays 2 SpueMor

‘Kean 1YSU au Sulod 919M nos *S} 9[NOUy, "Teal Nok Uo anf

01 Aumuoddo axp dn ssed yupjnoo ing “yor 01 pauueyd 3,upey
OK "HE sity UO YO} PUP PALL aSOpD v BUISSOUD axe NOX
9A] JOYINS IYI,

‘Kas Buouw au [tes

61 eats axp 20105 01 yunyoddo oup a¥e3 pue “suosea: 91ForENS
Jo} ‘Moy kue SuP{orI 9g pynow nos yeYp st oHduNsse ULL

“JOARY OU UAM}AX |]! BY asNS oq UND NOK ‘—URYD ay

uaatg ‘ame peq Ut [tes 40 eae yar1 MOU Inu a4 se TUauOddO

amp sarensnuy st, ‘pulyog asoj> auauoddo ue uo are peg duunp
tea nok “USWIOU v JOY AvJap Inq Yo"I OF ApLas ase NOK JT
40409 pure peayy OD

suiatioddo sno sou res nok sia] 19409 9809] v “PULA
‘ayy qn 1xXOU Joadxa OF Jey Jo aunsuN axe NOK LOYAL

kom Sua ayp Suyo3 av
Coup pun Gos 1ySt4 ays 808 a4v nok ways
‘auoauos 12409 pun 4901 1ON Og ~ SE SL

49409 as0o}
2409 1481 D



---

## Chapter 8 2_4.pdf


### Page 1


01 220d somony, pura

9 49104,

jn sayyo yp aze nok MOU ING “FORD JOYS 204 se

andi sosva 296 (Koa 3431s aun Su1os Ayqeunsasd) pouuetd

‘your nox apy (uonzaNP SuOHN OUP UE LO res Ajqeumnsaud pur)

ver uo at) on [Eats atp uy 0 Jom ouL, wed w Oru BUPFOND

‘pone 01 st aug “suostas Ont 10} YO" of Avjop or em Aeut
‘nok *BUurWOD [WAL v_d9s PUE YOR? OF Supedaid axe nox JT
N09 JOINS

“yor 01 904} 94

qxau qian no wOU}s apioop 01 Jomod amp 1G [PAL  pury 1,Uod

tren poad ath pInOUs YE APE 01 B04} 2q 1 wood LsHOUD
aqme 0s op ‘stv0q J0 804 B JO PutAsa9] OF BUTEA HOA
Ud B OFT YOU 1,UOC

suny amp

zxuurquyut 01 paads puny 2Avu TIES nok a[yas Yor Suajo nok
hig -sjarorpauuut os op wtp ‘Cease YOUR O} uvjd nos jr

(ep “Biel MOpeUS Pulm StH Jo WOH] UE ySnonp yeoIq

op ajqe 24 Kes nof “tuouioddo ayn €q yor Te ANUS PAT

ponds Bax ag ® QA 0 3ToK S9S8OH9 JPEN aH SF HOS

-pansaay 01 fo Sunatap &¢ snp 49p9 dary 21
Aas woo nok ‘payoou aap nos aya — EF BL

-pauunnd 2g ja 190q s10q 29] 241 “dn
azaanbs uno wog sayivam ay ff — ZF “81d

se Kpysiys yo yorar ust “yor wasaid anok wo Avs OF THEA

nok Jf puodsar 07 auedaid uea nog “youn au aredionue no

{JL-are zeaqo 0) preaoay 01 YBNostp DAU oF Kn 40 KjavespouUTU
‘Keave oe) soya ued NOK “aM NOK Wo SyDEI IO ¥ IT
paemaa’] 0} YsNOIYL PAL

*kjjoours odvaso

puv your o1 Auige anok sjoedut oe amp 230)24 “giqissod
se UOOS Sv INO Yor) ‘Buous st uOHIsod ss9yoeNe OY IT

“(Zp Bua) advoso ajqe 94 10U II} NOX pur JoyNS [1a UE

-auojaod “isneqxa s,s949eNe xp O1u |TeJ NOK BUD “Paysene

‘am nos sv WoOs sv Javay “HE an9I9 UT dn Suryourd £q advoso
oy alge aq Keut nos “avoq 29] anok uo sxe wwouoddo Ue J]
paeaputys 07 dp azaanbg

-wvajo vaug 01 aqqissoduur Ayswou St 1 spoads oy dn st JoyoeNe

‘au a0tig “paads [pny paysear sey soxoeve ax a40}2q 11P ea] OY

(ySnoatp Yeoxq Inu NOK “yore UE aALAIMS 1 19p30 UT -asods
a ypinb pur uonedionue st youn wody 29U2}9P SUL

yosano, Buypudjoq

-asuodsas v saqpuissa0u
nog 29] $,,Au1 9 Uo PIV = Th BL



### Page 2


S01 280d

sonany pudgy :g saxdoy

‘qonar 01 Apear aq put “Peay ¥OOT
{quadoxd yonp smu no “TesI9494 ¥ OXaHYPE 01 JOPLO UL
“(ogy Sta) $0K9 sony aze wo stow 2fou am weNN J08HIa SUNY

yuo at. tes 0d anoK Jo yno uno Bq w Sayer pul 'sPROITS
aan puiyoq sn “sdiysprtae no SI 9H HO JEG 2,UOH THOM,
‘up pue pasta w29q you Sey Ure OU “spuodsau Aypavy 180g ay
{nq “wry Sty spun dn wsjay uy st[Md OH “AONP SOK yor) “ou
‘yonp 03 Saploap 9H "7,U29 Oy “ON “$8039 ‘Kew! OH 2¢# 40
Qgy Bta) Awoys ut sout09 aut 94, “PAPAL
oy stpBuay 909 Z inoge asunoD o1 ZuywoD Apu ‘hua BuO 2
eat, Kou suno9 yesoxoa4 v UO wows Nok zopun Buysse “nok
‘1 jottesed Atmwou Suypres “yoeas peor & oF UAOP stoard 10g aq)
ut sqes8 zappnu ayp nuou0U Smoasou © JOWY U0 ERS nok
udnowp 1, Yo uason st 1204s qu HL, sPuodsas AIpsea oa KP
‘nq “Ury sty Jopun dn uspoy aun stind 3H “AONP “SA. “yori ‘ou
<onp 03 Sapi99p 9H ',t29 3 “ON “$8019 ‘Kewl OH 27H AO.
“(egh “Sta) AIpeq Sues pur ‘posnyuoo “Paasou
un ‘mopeys putas anos ut “PUIG £I9yes St 905 PLO OUP TI

sndyoog 5,100 YORE PADOGUDIS UL PUP "PMP POD SA
jHOn UL 001 ysO49 MUL ;pyoan oF SBUIYE au - "PRP BL

NN
s “aN

Gos

sqres arp sy “powmtuin st qif oup Ajjoury “Furuzem ou Sem AOULL

-Apvay som uo ON “YoR? ADU OUP UO Sy] I] ‘paseazas AITCUL,

St 11 a10J0q syorq qif au, ‘astidans Aq ys Aue MAID HLL,

-umop tjoy xp SMoxtp afy “Ye “OU “Yonp o1 SopIap OH 7,0
OU ‘ON “$8019 APU Off ZT4f HOM 1,UUS9OP IE MOY S,249H

(Lp “Big apioap 1,uiv9 ay“ yen “ou *** YONP

[aH “Ss029 1,uvo 9} “2ouNSIp 4p Jo wos dn apeus nox “Wars

‘iy Jopun passed noX se paads j1ny wemp sarsey Suyos a19% NO

1ng “exp ATO ION “[]e9 01 aso Oo, "Yonp anos Jo UEsACUE OMT

q nok sou ILM 94 AtjeanaioaUyy, “aAvA w WIIY aALs NO “PIO

-aP}S Uo 24,NOK aUNH SII ATWO 19401 BU1OD NOK *00} SIRT
juouoddo sno, "yor NOK AypemuoAd pue “sey [eS NOR

“Ov 3a)

antAs UIAIS STY UO IMO Jans O1 B1qe aq Waa |],NO “AON

a1,nok sf ZouyeaH o 40m pu Eu dn Yourd “SHES Sty Jo are

‘up two0ay i B 198 NOK “UzaIs s1y Lapun ssvd NOs sp PAL IY [1

pauuias pup paynoyasojo ury saysvf :rvadoy “umes dn win OY

passed aazy nox [NUM eA 1,Uop Inq ‘IJo 19g NOK Hays poods

jpoayp pur—pavoqunis
uo 9g ju nos aus rau ays x01 NOX uayyA ~ LP BLL



### Page 3


LoL 280d sonony puny

sg sandoy

-suomems o1seq aazyp az8 a19t,28sn0D atp Jo Bay dads ¥ HO Bs0TR
{wox) z9yjip seu pucaxput oxp ve sofnu Tuypunos wu 2M, uL
sSurpunoy Yae/A PLEMPULAA

-(spuom 10 uonoe Jaupta) asuodsad t s198 aq Se UOOS

‘se Yorn wsnUtt 180g puwmrad] DULL, Apo AUIS PU APTI HOA yey,

so syoer ast 180 PARANPULN 2H "67 2PM PuBspura od (S)10O4
th [et] NUL af “YOU 01 S9s004]9 TWO PAPA] A IT

(ZS “Stq) eI OF

gsoorfo Kew a 40 “I]9m Se Yop 0} WOH SI9HVO ‘ant pue Yonp or

seoot eu 190 HOA PAEANAA| HLL, Wa] Keys 01 19PH0 UH ACL

{0 Yonp Ae siwog Yo"I-WOd ax, "HONING UF SE ssyues 120q,

Soei-prbogues a, 399 Keys snus Soe HOM am WO AT
_pmogimys & yoroudde sivog oe! Hod (210! J0) O78 UH AN
(61 pur gt saqmy) suoINISIO

uonanasgo pavoqunss v Jo 40219
oys ssn syv0q wod on] ~ 7 Bt

Papen

\

+ PY
RETO

"i

+e"
w

(1g ig) Injameo ag “yf aAoad 01 91qe

9 osye asnu nox “KypeRaj 49" NOK ysnUU Kuo JOU UaKp “IsorOId

{8 0) Salo 11 J] ‘9S0}9 001 PaxPE SEY aYS 10 BANOUELL DAISEAI

‘ue soyentut og Avas-Jo-IYSLI yp a40Jaq (ASMoD HO 9g pur
Surum ystuyy) 9" 194 aajduioo nut wog Supe Oy.L
(EL a1MY) 98019 OOF BUPPEL

samajo Avs snut NOK “JeoG pALAad] v Se (Yay se IUIOd

4,usoop) paputar aso se JOU St oq INOK Jf Hang “[NJOe 99,

[Ins isn sog preaypurss ing spurmumop ase Kaxp sv pulmdn

‘|WIOA Se JOU ame Sa[Ny PAEMddY/pIEApULM aUp ‘poyney ISO]
Burpres ouods9no YA, “sea|o AeIS INU SILO PIEMPULAL
(LL amMa) PEMa'T/PACAPULM,

‘win amok ysiuuf no§ a1ofog suaanauru a}sD42 1018
Jone wwoq Suyyou ays fi asoyo 001 paysv} aavy nox ~ 1 BL



### Page 4


601 280d sonany pnd, 'g 101d

“(66 "31q) og Buipuayjo axp rsaroad ysnut ays IN
-posooud eu 248 20uH amp ore pagysnd KqmyBuOHA Sem IO AAP
{L-steoq Ja4po fe Jo seJO Avys ysnU PUL siyaia ou sey 1809 vB “UIM
Faeuod  Surop aqAs “Bumpsoooud a10}04 OO ® OP PuE steOM
sotpo jo s09jo 198 Aforexpoutuny sms rou vs YHA. LO V
(fe 1M) AA PULL, SUL
“(gg ‘Hta) Burpunor pivoqaeys papos>
te uymp &yraun sia8 worms 21, ‘peEwE Sassou WO4 421
prvogaeas 2up aye Keave 81 30 “Yon “THs SMU IOP od
au. ned s 20490) od & uF YEA pOpHUD UE Ng “2s
‘uo apa Keas Jo 1ysts Sey JOY" PrBogrers oup ‘Suypunos
pwoqueis # ry tuna se 40% 10U op Kay) Ing “P4BogzTIs
oy ame syprous woUss ouures o4p ane Sopra Suypunos eu AL
PxALOGIeIS OL SPN
*(ug “ig) 9]on1D WBUDT
ywoq om 4p SaYDBD! THO apEsIMO Up) UOUAR poddepono axe om
‘up Jt Jord pure punos 0) woos wo APIs! OH ‘SAI STU TOG

O9E P op smut ya ay
say yoryas 1004 ¥ ~ 6S “BL

VA

\

euondo

zuondo

{380]2 001 Yoo) 10U Isnu pUDOqUDIS
sassaug pavoqunss 2]fis [1018 Isnt 1004
od ay) ‘pavoqunss o1 Siow yiIah — 86 BLL

yuondg

‘auoz ays apisino Suryoo1 40
“Supyons ways pun “Bussso19
‘Sqaput ays puncan Suryoos
Aap, auoz ys3ual Z 248
apisuy Suryoo1 pioav pnoys
nok soy yons auv €°8I AP
fo suaping ay] — 96 ‘3ty

Je

yov1 01 woos Suapnyout

Se auoas sta8 sboq apis ayy, ~ £6 “Sth



### Page 5


LLL 280d sonony pundp :g sardoy
Ld ost zi sve
eet aivaac :
et Ae sizret A SyeUT oup 01 JaSO]9 NOK Saye Fe Yo" ay
a ee eee [res “ino sBunp UOs NOs oY !WDyL \oMoUY “8eIAA]
# ae Silecer Surzrmturu Xq sytys Jo edu axp oztumuTU uamp “Op
ee Zilozel {le put a¢p wey Jo aunsun are nos OYA :Suneadan s1e9q
ore Oty, eo Jellsszt ular a1Sorens v ing ‘axay samsuE Asvo OU SI 2Y9Y.L
a out eerci
ox ie rrel yarey “peaye sey
(ord sol Ertl ‘aut pI] [eUFTLO ay UO Ino OUT YoNIs OYA SIOqYsIU
Ea am a we ore Plo ano ing ‘fury ay UL aM ame S[UO ON “WIPED
ae yee on Fibs popeay [es pure Y9e1 07 aAey am Os YOHG IIIS
oz Of sol naan (Aqeuy) pum ox Survey utp pue ‘papeay Turres
se food ssi so |_ |eezt “Suryoen st ytys qwuarsisiod v Jo apisino oup uo ys
pat Lee ai a4 dy Buroq unyp nyured asow Buy A[Uo oy, “Yoeq aMIOD
sel ost | 72 oz 11! purm ayy “o1ued 1,u0q “uo Suey] “Y9"11,U0q +
ove re |zi/sort -gs10m 193 Ajuo |]LA0 IE“ si
ae ze ee at est z a uo [981 OU twos sBunyp se peq
Ot as os: | cg |zcoz v jno [reg “Is qwaysisiod v st sp pure
ea 2 ee \ei\eattt spoBueyo axvy suonspuos — 11 29% JOAO ARE +
sai 2 591 ecan -ysuy jes pure “oy axp Yate TuNIepHOsUOD
a Bd ibaa '9q YSU donpay. “sanoE) pur paads UO snd0,] +
or 91 evil ‘ABoqens
ee oe ra |_ jor usa) Buoy ssasse NOK apy S}9Qy 4
ox od om cise oIPO oy Mot ip Ue JA Ladi
zt i eae 1 998 pure s9x0 39e1 ‘onUITIUOS
wee 0 Bs eet tue) z0uey “Yer pure ¥>e 01 St uONdo Bu +
eS [ood ssi e9| |ecu
EN zo jeje
oz oe ont va, |e -poay anos Sunpowsas 1fa] 9q v9 nos (;sMOUY
ae os |z2| jeou oyat — suouy]p1980 sa8uoy  ssnf 11 $1 40) sifiys quarsyssod
oc es £2 |e! sou | oman sifiys Suypjjjoso way, <Barmus astia4 01 ajquiD49s O1
- ea Pee \oileecin ‘Avy SUDIOYIDI “B9L-pHU aBuDYy9 SuoLIPUCD UY, —O9 “St



### Page 6


E11 280d

sonony, puada 9 421d049,

gqiom posuaaas panoqunispiod  S20p MOH “8

gafiys 01» ssnue nos fi 280] NOS op YMU NOH
{ Sunyo0 Sq 80] NOS op aDUDIstp Yom MOH “L

{A8omnus nos 120ffo sys p81 MOH 2psy S496
1 says Kopo1 Sjasounuofun—W204g D Uy Is0f $1 ¥Oq AMOK “9

op nos pynoys wyay “auy.So]
poi pevoquoss ay: woufsp1mk gor pup “you ayy woul spunk
Gop 240 nox 3204 Jo4 0 PuD oxy uD says oF syBUa] ot
diz anos wo s} 4ay901 wod 424y0uD pup or! Hod UO AAD NOK 'S

{08 nok pmoys Koa yoy, “ifo] 240
01 Sunsfiys si purse ays mq “1y8t4 ays 01 s211aq 81 tuauino ayy

op nok pynoys sy, “ouyy ystuf oy
oul spark ogg puss anos uo payor isnt swoq sotsof 42881q YE

gpusmdn 8uo8 aq &Sarouss nok pynoys swyay ‘axoys wou Koso
108 nok sp papvay 108 Kjponpo4s nog ‘pavoqanss uo Sumyavas
pooug 24v nos ‘2004 ayy atofaq vaxp uDIs ays o1 no Suypns Z

op nos pmoys
Dyas wouf Sumos s1 Yys HOU ay) axaysX aansun xv puD 1704
PAvOqUDIs D YsLM Buysso19 a80]9 0 Ut YoDI LUO UO AAV NOK “|

suoysand Zing :sonovy, pur Asa7eV.4 purmdy 68



### Page 7


SLL 230d

souony panda :g s0ndDy

ssauo Kyrea
an you — sou sioreu yoEy Wag ath dn oe prwoges Ise] oP
Seip essoxo 01 af 29 100 ITH Tats om "49H [UAH AMOK pul NOK

tous “pods pood yi 19% Yonp pu “od wo 91,NOK JT
[quam posiaa1 papoqunis/uod D S20 MOH 8

wo 1904S v YIM proye
no auoo pure Buoy 192} 06 SPA TO NO JL WOAD YEOHA P.NO
“yo9} O81 ~ 20uRIsIP SUIS Jo spHA OH OAvS TL.nos sioypeaN
oy spark op [tes pu ya" NOK JE°OS “IHS Ioge ‘Kq sourystp
uyjyes soonpas wil OL W “dous wEa:ou omntT B ‘JaeM YOOWS:

say ante sdqsod — st8UaI 104 Z mMOgE S00 SYP

Jafiys 01 7 ssi nos fi asoy nos op yon MOH

(:Suryoo1 &q 280] nok op a9UDISIP YoU NOH “L

-soy pages st ABayenns aatssoude azous “joodsns

x poods sno way “Su0r0ry oFovens jo udu ou ozs
con mtv nok totp 7paads 1e0q INO UO NOD UD NOK UOAL

| éSamnus anos wafie si 1yStu sop] “2p S198

«1 azayy &vpor Sarrumacfunn—929244 D M10 $1004 NOK “9

-uonssod apisur nok
ud ‘ured aouo “yonp 40 “yonuos uy nok Fund Yor) JOM
fo wrath 2910} nos “Joye SUPP AL EU! yp 01 NOK Peat
pur “nok sopun 4oe 1 ajar 94 4 eats a wou SUH} HO
tos no J “U4 24107198 NOK aH0}9q YE PLE Ise) LHS
; op mod prnoys yyy ‘2uypsoy
por pupoqunis ay) wouf spans por Pup 4D ay wef spans
Gp 210 nox “yong fio4 0 pun Oa pun saysvax ot syU2] Om
sdninos uo s1 499901 0d JaysouD pup yoo! wod uO 21D MOK 'S

{aagtys aup so quand sanI8q oxvy 01 I99dxa NOK

inom Suo] Moy JO} PUP YoU MOF] “Y!YS OF B Se YonUE se

jnoge HWA soroadurt uaxina puyradn Jo Uy y “2o!oyo ISFOM
‘up 2q aysiu appr a1 dn astuosduros y “eo YsNOY,

08 nos pmoys Koa yorum, Yo] ay

(01 Stuafiys spurs ays mq “1y8}4 94 OF 4a1s9q 8} muauino ay f

suny 3ur9q 24,n0K <jpeq moy uo spuadaq

“ae pq ut Surpies unyy azour ysoo 1ysHtU oyu Ise YP UE STE
‘BAXD OM YHOU ‘ITE NOK away> Or TULA YT NOK “TS.

-adeys pod Anaad ut a1,nof uoup “ystuyy oup azojoq aynUIUE @ Are
{noK Wo Buryou axv auuN NOK AMO YoIYA sIvOG J 94D

Gop nos pynoys soya “ous ysHUf ay

auf sparc gg puss anos uo paysv1 isnt 1v0q Aa1sof 128814 VE

-pazoay 0q pinom apis ausoddo
aun purmumop warp ‘asinoo axp Ssoue UDA St yBSUaNS PULA
au sf ‘purmdn 3u08 opis yeep 07 [Fes wap “2x04S zwOU (19q
440) pod se st ypSuans pura axp sv Zuo] Sy “"YYS TarstsIEd
1b — you) atisoddo a4p uo azoys pxeasor Yoeq SuI0s papeay

108 Ajjonpess pjnom nox uatp ‘spjoy oRIpUuOD 2tp AT
gpiaudn Supo8 ag &Sarus anok pynoys soya ‘axoys uous komo
108 nok sp papoay 108 &jponpo1s nog ‘pavogavss wo Suyyova4
pooag aun nox ‘2004 ay) aofoq va4D ADIs ay} 0} Ino Buys Z

aSsona| azsuuutus 0} seat nos Jo >INq axp seaU AeIS pu

‘sopis aup ploae pu eur oy) preor [es “YS IX9U OUP JO aus

“un ame NOK uayAA {109]J BU Jo DOURTEG ayp St aIDy A ZSOPIS AUN.
61 mo 40 *9s1n09 94 Jo a[pPHU a4 Pr¥Aor poproy Nok as

{op nox prnoys

soy ‘tous Sunuos s1 yfiys 1xau ays 2404. aunsun aay pun 10q

(PADOGUDIS D ystM SuIsso19 asO]9 D UW YoDI Od UO 24D NOK “|

SIOMSUY ZINA :soyaET, pue A3ayv.4g purady,



---

## Chapter 8 3_4.pdf


### Page 1


Cuapter 8: Upwinp Tactics

8.1 Introduction

Tactics to Win

We work for years to develop competitive boat handling
and boat speed skills. Why? So we can enter the tactical game
in a position to win. With the foundation of our performance
pyramid taken care of, we can pick our head up out of the boat
and enter the world of tactics

Upwind tactics involve positioning against individuals or
groups of boats (Fig. 1) to take advantage of strategic conditions
(ie. wind, shifts, and current), or to control tactical situations
(crossings and mark roundings). Over the course of a leg or race,
tactics become increasingly important. Early in a leg or race, itis
best to avoid confrontations and concentrate on a strategy that
‘will put you near the top. At the end of a leg, you battle tactically
to round ahead of those in nearby. Toward the later stages of a
race, your general position is relatively fixed, and your efforts
focus on boats just ahead and just behind.

“Tactics are relatively unimportant in mixed fleet races,
where you are racing the clock. In one-design or level rated
racing tactics predominate—as your closest rivals are the boats
nearby.

This chapter covers Upwind Tactics in nine sections. Fol-
Jowing this introduction, Section Two looks at the impact of wind
shifts. Next, we consider tactical principles used for positioning
‘and control, followed by an explanation of how tactics change
over the course of a windward leg. Section Five looks at the tac-
tical weapons, and Section Six covers rules and their tactical ap-
plication, Section Seven describes one tacticians nightmare while
Section Eight tells why and how to eliminate tactics from your

and Strategy

Skillbuilding ideas.

Fig. 1 - Upwind tactics involves positioning against other boats
10 take advantage of conditions and control situations.

8.2 The Impact of Wind Shifts

Our strategy forms the framework for our tactics. We use
tactics to fulfill our strategic goals. One key element of strategy
is wind shifts, which we discussed in the previous chapter. As
wwe work to take advantage of shifts, we need to know their
tactical impact: How should we position ourselves against our
rivals in order to take advantage of the shifts, and what impact
do the shifts have?

LEP: Climb the Ladder

Sailing upwind is like climbing a ladder. The rungs of the
ladder hang perpendicular to the wind, and boats on the same
rung are equally far upwind. Each rung is called a line of equal
position—an LEP (Fig. 2a).

Page 86 Performance Racing Tactics i 7a



### Page 2


Fig. 4 - Afier one minute of sailing time at six knots, boats are
separated by 848 feet. 212 feet will be gained or lost in a 10°
shift. It takes 21 seconds to sail 212 feet at six knots.

How Quickly it Happens

Imagine two boats sailing close hauled at a boat speed of
6 knots and tacking through 90°. ‘They cross tacks, with the
port boat ducking. Each boat sails for one minute—you know,
sixty seconds. After one minute of sailing time, they will be
848 feet apart. A 10° shift will put one boat 212 feet ahead. At
six knots, that distance represents 21 seconds of sailing time.
Separating for 60 seconds creates a 20+ second gain/loss. Your
risk/reward on a 10° shift is one-third the time you spend
splitting tacks with another boat (Fig. 4).

So, we were caught to the right when the wind shifted 10°
left. What should we do? And what about the boat that went
left, what should they do?

Fig. 5 - Being unsure of what will happen next, the boat on the
right would most likely keep going, rather than tack on the lift,
and hope the wind would shift right, and erase the loss. The

boat on the left would likely tack to try to consolidate the gain.

Well, we've missed that shift. ‘The question is: What will
happen next? Strategically, we want to sail to the next shift, so
if the wind is going to go further left, we'd tack and go to it. If
going to return to the right, then we'd keep
going. That's what strategy tells us. (Fig. 5)

‘Tactically, if we tack, we have given up these 212°. If we
hang on, and keep our 848’ of separation, then we can gain it
all back just as quickly as we lost it... just as quickly as the
wind returns where it was. We could even pull ahead if the
wind goes further right. What will the wind do?

If we tack we will be 212° plus 2 boat lengths behind. If
we are one tenth of a knot faster, we'll gain 10 feet per minute.
We could catch up in about 25 minutes, or gain back half the
loss in 12, and be close enough to get the rest on a small shift.

Assuming our rival tacks on the shift, continuing parallel
puts us no further behind — as long as the breeze doesn’t shift
further left. Let’s hang here, and look for a little righty to tack
on, or maybe a big righty. That would help.

Looking back, maybe we shouldn’t have separated so far.
But tacking would have cost us too, about two boat lengths,
and no way to recover those ~ they are spent.

Page 88 Performance Racing Tactics



### Page 3


Leverage Low Risk Leverage

Fig. 7 — The greater your leverage, the more you stand to gain
(or lose) on a wind shift. If you can predict the next shift, sail
10 it. When in doubt, minimize leverage.

‘The Message

Wind shifts are a big deal. We got that message.

‘Two corollaries follow:

First, if you can predict the next shift, sail to it.

Second, if you don't know what to expect, then minimize
leverage to minimize the impact of shifts. (Have you ever been
unable to anticipate the next shift? Me neither, and the check is
inthe mail.) (Fig. 7).

We'll look at these two corollaries from two perspectives:
catching up when you are behind, and protecting a lead when
you are ahead.

Catching Up

When you're unsure of the next shift, minimize leverage
by staying in the ow risk zone. Try to nibble away at the
leaders with speed while eliminating the risk due to shifts. By
minimizing leverage, you deny the leaders the chance to stretch
the lead, and you stay within striking distance. Then, when
‘you can predict an upcoming shift, go to it. Remember how

current

next

shift

Fig. 8— When you are behind, spring
tacks with the leaders is usually NOT a

good way to catch up. If the leaders

are going the right way, then splitting

and going the wrong way just leaves

you further behind.

quickly leverage grows; you don’t need to split for long if
you've stayed within striking distance.

Splitting with the leaders just for the sake of splitting is a
bad risk. Since the leaders are usually going the right way
(Hint: they are in the lead), you are more likely to fall further
behind than to catch up. Stay close and wait for an opportu-
nity. Split only when the odds are in your favor. (Fig. 8).

Staying Ahead

You hear this said about champions: He gets ahead, and
he is gone. How do they do it?

About other racers you may hear: Don’t worry about him,
eventually he'll go to pieces. Why?

Tactical dogma when in the lead is stay between the
competition and the next mark. Cover ‘em and you can't lose.

When you’re in the lead, it is not enough to simply stay
between the competition and the mark. If you are looking
back, and just reacting, then those behind can get leverage and
eat away at your lead.

Page 90 Performance Racing Tactics



### Page 4


og

Fig. 10— Cross when you can. If you don't, the wind may shift
and you may lose the opportunity.

8.3 Tactical Principles

There are a number of general tactical principles to keep
in mind as you sail upwind. The overall objective—your
upwind strategy—should remain the priority. Use tactics to
help you achieve that goal.

Keep Clear Air & Freedom

Keep control of your own destiny. Avoid situations where
other boats can control you. You need to look ahead and posi-
tion yourself clear of crowds.

Cross When You Can

This is also called consolidating your lead. If you wait,
conditions may change, and you may lose your opportunity
(Fig. 10).

Don't Let Others Cross You

When the wind shifts, don't let those who gain consoli-
date. Go to the next shift and recoup. By staying off to the side,
ahead and to leeward, a favorable shift will help you (Fig. 1.
The catch is that you have to be going the right way. If the

Fig. 11 — Don't let others cross you. Once you let others cross,
you have conceded your position. Stay to the (favored) side,
and catch up on the next shift.

S are large and difficult to anticipate, you run the risk of
being buried if the shift works against you. When things get
weird, it may be best to position yourself with the leaders until
you can sort things out; then use the Catching Up ideas from
the previous section.

Stay Toward the Middle

A championship tactic, which sometimes doesn’t work for
the rest of us who spend most of our time in the middle of the
fleet. When you are in the lead, or near it, adhere to this rule, as
it minimizes leverage for those behind and gives you the ability
to go either way to protect your position, to clear your air when
attacked, and to pursue shifts. (Fig. 12).

Back where most of the fleet does most of their sailing,
the traffic and disturbed air of the middle can be devastating.
Yes, sail the middle when you can; but balance this with con-
cerns for clear air and the search for favorable shifts.

Page 92 Performance Racing Tactics



### Page 5


&
XN N
» >

Fig. 15 — Lead the crowd by tacking
ahead and to leeward.

Lead the Crowd.

‘As you approach a crowd of boats, tack ahead and to
leeward, rather than sail through the crowd to their hip. There
are a number of reasons why this works. First, itis best to stay
with the fleet, as mentioned above. Second, if the crowd is
sailing toward the next shift, then you will be the first to get
Third, once you sail into a crowd you may have trouble finding
clear air or a tacking lane. Fourth, if you decide you want to get
across to the outside, you can tack again and exercise that
‘option later. Once you cross the crowd, you can’t reconsider
and return to the ahead and to leeward position.

‘This principle is particularly powerful if you can lead the
crowd toward the middle of the course. On the other hand, you
‘may want to abandon this principle if crossing the crowd will
{get you to the inside of the group, closer to the middle. From a
position on the inside hip, you are ready to lead the fleet to the
middle as they tack that way (Fig. 15).

Fig. 16 — When in front, cover by staying
between the fleet and the next shift.

Fig. 17 — On a one-legged beat
sail the long leg first.

Cover When Ahead

Stay between the fleet and the next shift. If you are ahead
and can anticipate the next shift, sail to it. If you are ahead, you
have to hit the shifts to stay ahead. Your lead won't last long if
you follow the fleet into the shifts (Fig. 16).

Stay between the fleet and the next mark. If you can’t find
the next shift, find the mark and protect your position that way.
Lead the fleet toward the mark or shift.

Sometimes you can't cover. There are times when it simply
does not pay to cover. When conditions become dramatically
shifty, the impulse is to cover tightly. But in these conditions it
can prove impossible to cover an opponent. Concentrate on
sailing your own race. Try to keep your cool when things get
weird.

One-Legged Beats

When the course is skewed by a major wind shift so you
can nearly fetch the windward mark, you are sailing a one-
legged beat. Tactically, the best position is ahead and to lee-

Page 94 zi Performance Racing Tactics



### Page 6


Rounding,

Beat

“
Fig. 21 ~ The windward leg can be divided into three
tactical segments: the initial segment, the beat, and
the rounding.

8.4 Up the Beat in 3 Stages

Tactics upwind is a matter of positioning for wind shifts
and positioning for control. We can divide the beat into three
segments, The initial segment is the period after the start or
leeward mark rounding when we are sailing in a crowd and
fighting for clear air. The middle segment starts when we break
out of the crowd and are free to pursue strategy. The final
segment is the battle for position approaching the windward
mark. Boat-to-boat battles predominate at the beginning and
end of the leg, while wind shifts are the focus in the middle
segment (Fig. 21).

Fig. 22—A short tack to the left may be
needed to find a lane going right. You
‘may be able to foot around a crowd.

cy

be

ve

Fig. 23 ~To go left, tack into
an open lane, clear o traffic.

The Initial Segment: Positioning for Freedom

‘The priorities during the first part of any beat are t» keep
clear air and to have the freedom to pursue your strategr. The
first few minutes after a start, as discussed earlier, are cxitical;
any advantage gained there will be magnified,

At the beginning of subsequent beats, the goal is te catch
the first shift and get to work on strategy. If the goal is > work
to the right, it may be necessary to tack shortly after rounding
and then tack back when a clear lane to the right is available. If
you are outside at the rounding, you may be able to reach
through for clear air and save two tacks (Fig. 22).

Ifthe strategy is to go left, then you must work to te free
to tack after the rounding. Beware the wind shadow and turbu-
lence of boats which have yet to round and are still on the
previous leg. While you will have right of way close hat led on

Page 9 2 Z Performance Racing Tactics



### Page 7


Last Shift ieee Previous Oscillation ‘

Fig. 26 — Sail into the last
oscillation going into the mark as
though it were a persistent shi

The Rounding: Positioning for Control

Approaching the weather mark, work for control of those
nearby. Keep clear air, and try to keep from being pinned by
others. With marks to port, the left side is inside at the round-
ing, but a boat on the right controls the last starboard crossing.
‘Starboard roundings put a premium on controlling the right, as
the right owns both the inside position and the last starboard
crossing.

The Last Oscillation Is A Persistent Shift

Q an oscillating breeze, treat the last shift before the mark
as stent shift. That is, sail the header to the layline, then
fae Pt Arley rho ela one
sailed as you would in a persistent shift. Think of the last part
of the leg as a very short leg with just one shift (Fig. 26).

Fig. 27—If a port tacker can cross, he can then tack cross
and pin a starboard boat or sail on to the layline.

Fig. 28 — If the port tacker can’t
hhe can tack (into a pin) or
duck—and get pinned to the right.

Inside the Laylines

Inside the laylines, a weather quarter position gives
control, as a boat on the lee bow is pinned and not free to tack.
‘This position must be carried all the way to the layline or it will
be reversed if both boats tack.

A port-starboard crossing near the layline is a common
situation which offers many options and counter options

If the port-tack boat can cross, he has several choices. He
can cross and continue on port tack toward the starboard layline;
he can tack to lee bow or cover the starboard tacker, giving the
starboard tacker incentive to tack away; or he can tack to pin the
starboard tacker and carry out to the port layline (Fig. 27).

If the port tacker cannot cross, then he can tack or duck. If
he chooses to tack, he may be pinned out until the starboard
boat tacks. A well-executed duck creates an opportunity for a
reversal at the next crossing. To prevent a reversal, the star-
board tack boat can tack and pin the port boat. If the starboard

Page 98 Performance Racing Tactics



---

## Chapter 8 4_4.pdf


### Page 1


5

A
g

Fig. 32 —A tight cover puts your rival in
your wind shadow and forces a response.

8.5 Tactical Weapons

Our upwind strategy gives us the big picture, and our
tactical principles guide us as we confront groups of boats.
‘Tactical weapons are the tools we use to put the principles into
practice and achieve our strategic goals. Broadly speaking,
there are two general categories: Those that allow us to control
and influence others, and those which allow us to prevent
others from doing the same to us.

As we look at tactical weapons, we will discuss what each
does and how it is used.

Controlling other Boats

Tight Cover

‘A tight cover is a an aggressive move which slows an
adversary by putting the him in your wind shadow. A tight
‘cover necessitates a response. Use a tight cover when you want
to force another boat away (Fig. 32).

To put it another way: You should tack and cover only if
it would be time to tack anyhow, even if the other boat weren't

Fig. 33 ~ Tack so you
end up upwind; don’t tack
when you are upwind.

Fig. 34—A loose cover does not impede the
progress of your opponent. It keeps you sailing
in the same conditions as your rival.

there. You use a tight cover when you want to go the way they
were going, and want to force them to go the way you were
going, which suggests that maybe you were going the wrong
way to begin with...

‘Tack so you are directly upwind after accelerating or the
al may escape your shadow (Fig. 33).

Loose Cover

A loose cover is a course parallel to the opponent(s) which
does not put the other boat(s) in our wind shadow. A loose
cover is more defensive than a tight cover. A loose cover does
not impede the progress of the other boat(s). It puts you in a
position where you can protect your lead (Fig. 34).

Your intent with a loose cover is to deny your opponent
the opportunity to sail different conditions than you are sailing.
A tight cover, on the other hand, often forces your opponent to
tack away. The danger with a tight cover is that your opponent

then separates from you, and may find more favorable condi-
ms.

Page 100 Performance Racing Tactics Pal



### Page 2


Fig, 38—A Slam Dunk is used by a

It doesn't always work. shadow.

Slam Dunk

‘The Slam Dunk is a technique for pinning a port-tack boat
after he ducks a starboard-tack boat. Immediately after the port
tacker ducks, the starboard boat tacks.

‘The Slam Duck often does not work. The Slam Dunk is a
good way to pin a rival out to the starboard tack layline if itis
not too far away, but over time the leeward boat can often gas
off the windward boat (Fig. 38),

Using Your Wind Shadow

‘You can slow another boat by positioning your wind
shadow on him. Once in your wind shadow, the opponent can
either sail slowly or tack away.

From Directly Upwind

‘The simplest way to attack another boat is to position
yourself directly upwind. This is the epitome of a tight cover.
‘When tacking into this position, remember that you want to be
directly upwind after you finish your tack and regain speed. It

Fig. 39 — Tack into a position on top of
starboard-tack boat to pin a port tacker. another boat to put them in your wind

Fig. 40 —A tack directly in front of
another boat will push the rival back.

is common for attacking boats to tack too late and let the target
boat break through (Fig. 39).

From Ahead

Another effective position for attack is directly in line
with the opponent. The turbulence off your sails will foul the
air for a several boat lengths off your stern. To assure that your
‘opponent cannot escape your wind shadow without tacking,
aim for a position between directly upwind and ahead (Fig. 40).

From the Lee Bow

As the name suggests, a lee bow position is on the leeward
bow of an opponent. Boats create a surprising amount of
turbulence fo windward. Tacking ahead and to leeward can
have a devastating effect (Fig. 41).

When you tack on a lee bow, be sure you have proper
position. You must be nearly a full boat length ahead in order to
ee bow properly; otherwise the opponent will squeeze up and
put you in a pin; or worse, he may even roll you and force you
to tack again (Fig. 42).

Page 102 E Performance Racing Tactics



### Page 3


Fig. 44 — If you are going the right way, wave a
port tacker by, even if you have to duck a little.

Wave 'em By

‘A port tacker who may or may not cross you can become a
real nuisance if he throws in a last second lee bow tack. If you
‘want to continue on starboard, wave 'em by, even if you have to
duck a little bit. Anything to encourage him to keep going the
wrong way and stay out of your way (Fig. 44).

Ducking and Reversal

‘You're on port tack, and you are approaching a starboard-
tack boat. You have five option: lee bow, cross and
tack, tack, or duck (Fig. 45). Your selection depends on
whether of not you can eross, and which way you want to go. If
you can cross, go ahead. Or lee bow, as detailed in Figure 41. If
you can cross, and you are unsure which way to go, then cross
‘and tack to put your opponent in a loose cover. If you can’t
cross, then tack or duck-what would you do in the absence of
the other boat? If you decide to tack, try not to tack into a pin.
Otherwise, duck

Fig. 45 — When in doubt, duck.

Fig. 46 ~ Make a smooth turn and
carry speed as you trim up.

Take a Bearing

You can tell if you will cross by taking a bearing from
your stern to the starboard boat's bow. If the bearing is increas-
ing, you will cross.

If there is doubt about crossing, then duck. Don’t forfeit
the race with a protest. And don’t wait for the last instant to
decide. A good smooth duck costs little. A poor duck or a crash
tack can be a disaster.

Here’s How it Works: As you approach it looks close.
“Let's duck.” Wave to the starboard tack boat so they know
you see them. No need to yell. From a few lengths, ease your
‘main and jib slightly and bear off. Aim for the spot where the
starboard boat will be as you pass. A boat length away, your
bow will be pointed at his. He'll sail a boat length, and you'll
pass smartly under his stern. Well, maybe don’t aim exactly at
his bow, but you get my drift.

As you pass under his stern you want to be going faster
than your closehauled speed (after reaching off), but you want
to be trimmed up to close hauled again. You must ease to build

Page 104 Performance Racing Tactics

~



### Page 4


Fig. 49 — When on port, don’t expect a
starboard tacker to risk crashing his boat!

8.6 Rules Upwind

‘The main rules upwind are On Opposite Tacks - Rule 10,
Same Tack, Overlapped (Rule 11), and While Tacking — Rule
13. The Mark and Obstruction rules of Section C also come
into play upwind, We generally refer to these as Starboard/
Port, Windward/Leeward, Tacking too Close, and Buoy Room.

It is a miracle to survive a protest. If you scare someone and
raise their blood pressure when tacking or crossing, they can pro-
test you and throw you out. The same applies if you get someone
angry. Never mind the fine print, that is how the rules work.

‘There are two common ways to get in trouble: Greed and
surprise, both of which can cloud good judgment. Don't be
greedy, and look ahead to avoid surprises.

Fig. 50 ~ Rule 16.2 explains that, if a port tack boat is crossing
and is “keeping clear” the starboard tack boat “shall not
change course if as a result the port tack boat would
immediately need to change course to continue keeping clear.”
The starboard boat is not longer allowed to “hunt” the port
tack boat.

Starboard/Port (Rule 10)

The next time you are on port tack in a close crossing
consider this: Racing sailors would rather have their house
burn down than crash their boat. After all, the family can
always sleep on the boat; but if they crash their boat, they can’t
race the house. The guy on starboard is not going to risk crash-
ing his boat to prove that you could cross. If itis close, he will
bear off, and protest. Don’t risk it. Duck instead (Fig. 49).

Rule 10 has been essentially amended by Rule 16.2. A
starboard-tack boat may not alter course toward a port tack
keeping clear. For example, it would now be
illegal for starboard to pinch up to prevent port from crossing.
‘The freedom of the starboard boat to hunt the port tacker has
been rescinded. Still, in a close crossing the only sure way for
the port-tack boat to go right is to duck (Fig. 50).

Page 106 Performance Racing Tactics



### Page 5


Fig, 53 ~ The inside, leeward
boat has right of way.

1) Both boats on starboard tack, leaving the mark to
port, (or both on port, mark to starboard).

This is a windward/leeward or clear ahead/clear astern
situation, The boat to leeward or ahead has right of way, and
may luff to round the mark (this is proper course). The other
boat must keep clear (Fig. 53). A boat clear ahead which must
tack to round the mark must obey Rule 13: While Tacking.

2) One boat on starboard, one on port. Starboard/Port
and Tacking-too-close rules apply. There is no buoy room for
boats on opposite tacks at the windward mark Rule 18.1 b. Ata
port rounding, the port tacker must stay clear (Fig. 54).

If a port-tack boat tacks to starboard inside the two boat
length circle, then Rule /8.3 applies. If the starboard boat must
head up above close hauled to avoid the tacking boat, the

Fig. 54 — The starboard boat has right of
way. There is no buoy room.

Fig. 55 — Under Rule 18.3, a boat
tacking inside the two boat length
zone has no rights.

tacking boat has violated the rule. Furthermore, if the starboard
boat overlaps the tacking boat to the inside, the tacking boat
must give room. (Fig. 55).

‘The burdens on the boat tacking inside the two boat length
circle are so onerous that I suggest you don’t do it, and con-
sider one of three options instead:

+ Come in right on the layline, and tack around the mark,

minimizing your exposure. (Fig. 56 — option 1).

+ Don’t tack ~ go on across the starboard boat and then

tack. (Fig. 56 ~ option 2).

+ Come in three lengths from the mark, and tack outside

the circle. (Fig. 56 - option 3).

3) Two boats on port tack. When two port tackers ap-
proach a mark to be left to port, (or two starboard tackers for a
starboard rounding), the buoy room rules apply. The outside

Page 108 Performance Racing Tactics



### Page 6


Rules, Ethics, and Self Interest

‘The rules upwind are straightforward, much more so than
at starts or offwind marks. Protests are usually the result of
greed or surprise which cloud your judgment. Don’t get
greedy—be ready to duck if you can’t cross cleanly, and look
ahead to avoid surprises.

‘When you have the right of way, you need not protest
every offense. You can protest a close port/starboard; but you
‘can also hail the offender, “You owe me one.” In the long run,
your own interests will be better served if you don’t protest
unless your performance suffers. If you protest even when the
port boat might have made it, you will probably win the pro-
test. He will be thrown out, and he will doubtless look for a
chance to return the favor.

By the same token, you have an obligation to protest a
gross offense. If you badly fouled by a port tack boa, you owe
it to the rest of the fleet to protest. Otherwise you are condon-
ing cheating. Ideally the port boat will withdraw or take a
penalty without forcing you to follow through with a protest.

But if people don’t play by the rules, then they are not
playing the same game.

8.7 A Tactician’s Nightmare

There are a number of classic situations which make
tacticians toss and turn, Here's one example:

Persistent or Oscillating

We were out early before the start, and got great data. The
wind graph shows oscillations, and we've been playing them
like a fiddle. Up the first beat we hit every shift. We held the
ead downwind, and now we've turned upwind again.

Pretty much the same numbers as the first beat, so we're
hitting the shifts as before. On starboard now, and lifted.
Stretching out your advantage. A little more lift now, and we
are beaming. We've hit the big one. More big gains while
some out-of-phase rivals sail off headed.

More lift, and the first hints of paranoid fear infect our
glee. The big lift holds, and we start to wonder if it will ever
go back. A slight header, and we start to think about tacking,
even though we are still lifted compared to average for the day,
but before we can say anything the big lift returns.

Genuine concern now. Have conditions changed? Are we
now on the outside of a persistent shift — sailing away from the
shift on the Great Circle Route? Or will the oscillations return?

What should we do? Tack and take our medicine? Hang
on a look for at least a bit of a header to go back on? (Fig. 60).

I wish I had the answer for this one. ‘The best I can offer
are ideas:

* Look ahead, and look at the sky. Have things heated
up? Clouds moved in or out? Any clues from boats
further upwind, or to the sides?

+ Review your forecast. What did you expect?

‘+ Where’s the fleet? Your risk is measured in leverage. If
your rivals are going your way, then the risk is small. If
they've split, then the risk is great

Page 110 Performance Racing Tactics



### Page 7


8.8 No More Tactics!

‘Tactics provide the thrill of direct confrontation with our
rivals. The interaction of attack and response challenges our
skills to react as situations evolve, We must consider not only
the boats at hand, but also the rest of the fleet and our overall
race strategy as we make split second decisions. This is hard!

Not only that, but if the wind is shifty we can lose hun-
dreds of yards in a matter is minutes. This is scary.

Maybe we'd be better off eliminating tactics from our
racing, or at least minimizing their impact, but how?

No More Tactics

‘The trick is to rely on things you can control: boat han-
dling and boat speed. Then you can minimize the impact of
things you can't control: the wind and other boats. Do this by
staying near the fleet, while positioning yourself to take advan-
tage of known shifts. The more you can rely on things you can
control, the less you will have to rely on things you can’t
(Fig. 56).

@ oO

Fig. 56 - Tactics and Strategy require us to make the most of
the unknown. The more we can rely on our boat handling and
boat speed, the less we will have to rely on things we can’t
control.

Finally, we're around the windward mark and we can turn
downwind. What's for lunch?

Page 112 Performance Racing Tactics



### Page 8


Skill Building: Upwind Strategy and Tactics

1. Learning to see the wind:

Sure, good sunglasses help, but there's no magic beyond
paying attention. Here's what to look for:

See the wind on the water — dark patches are puffs.

But which way will it shift?

You may be able to see how it is moving — but that is tough.

Your experience with the previous puffs is your best guide.
Some days they are all right shifis, some days the puffs
‘oscillate, some times it seems random.

“Another guide is other boats. See what is going on there.

Finally, don’t let sun sparkle and cloud shadows trick you.
‘Ona clear day the sun sparkle makes the sunny side look
windy, and on partly cloudy days cloud shadows can look
like puffs.

2. Where are we?

Describing your position on the course and in relation to
“other boats is essential to tactical decision making. One
helpful description of position is the ratio of each tack
remaining. When you are exactly in the middle of the
course you will spend equal time on each tack. As you
‘move toward the laylines the ratios change. A position
described as having “twice as much port as starboard”
remaining helps the whole team understand the constraint
on sailing starboard, and the desire to find a good lane
and favorable shift for sailing on port.

3. What's going 01
‘Asa driver itis imperative that you focus your attention on
sailing fast. At the same time, you may want to know what

is going on with other boats. Rather than look yourself,
you need to ask specific questions to help your crew
know what kind of information you are afier. Over time
your crew will learn what sort of information you need,
but with new or inexperienced crew some information
training will be necessary.

Some of the questions you might ask:

How is (a nearby boat) doing compared to us: What is his
distance ahead/behind, to weather/leeward? How does
his speed/pointing compare to ours?

4, Using a hand bearing compass upwind:

Often it is hard to tell if you are ahead of or behind an-
other boat, or if you are gaining or losing versus an-
other boat. Your hand bearing compass can tell you.

To measure your position sight perpendicular to the wind
direction. This is your LEP. Any boat on this line is even
with you. Boats above are ahead, boats below are
behind.

If you are behind another boat you can compare your
bearing to the LEP bearing. This tells you how big a
wind shift you'll need to catch up (assuming speeds are
equal).

Your hand bearing compass is also great for calling
laylines. Practice to perfect your technique, and beware
deviation between the ships compass and your hand
bearing compass.

(NOTE: A hand bearing compass makes a great gift. Give
one to your skipper or tactician!)

Page 114 Performance Racing Tactics



---

## Chapter 13_Wind.pdf


### Page 1


CHAPTER 13

ipl
TS2,
i kehs}
13.4
13%;
13.6

INTRODUCTION

WIND AND WIND SHIFTS
CURRENT

CURRENT AND SAILING WIND
CONCLUSION

SAMPLE FORECASTS

WEATHER

COLD
AIR

COLD

AIR
eee S



### Page 2


CuapTeR 13: WEATHER
13.1 Introduction

Every sailboat race is several events rolled in one. To
succeed we must understand the weather, harness the wind, and
battle against our opponents. Our understanding of the weather
will dictate our strategy. Included in this discussion will be
wind, wind shifts, and current (Fig. 1).

13.2 Wind and Wind Shifts

Part of Race Preparation is having up-to-date weather
information with which to plan a winning strategy. Good
formation means more than having the latest forecast. One
trick is applying the broad forecast to the narrow geographic
area in which we sail. For this reason the most critical weather
information is the information we gather ourselves, during the
hour before the race. Our task is to integrate the information we
gather into the broader forecast, and then use it in predicting
local conditions. Our forecast will have two components: One
is our forecast of what will happen, the second is our degree of
confidence in that forecast. A high degree of uncertainty can be
as important as the forecast itself.

The winds we sail in are a combination of weather system
winds and local winds. Our discussion of weather will briefly
cover the various major forces of the weather before focusing
on wind on the race course.

Fig. 1 - Our understanding of wind, wind shifts, and current is
essential to developing our strategy.

Weather Systems: Highs & Lows

‘There are two general types of weather systems; highs and
Jows. Highs and lows can be further classified based on their
origins: maritime originate over the oceans, and are moist;
continental originate over land, and are relatively dry. The
location of weather systems is traced through barometric,
pressure measurements.

‘The wind blows out from high pressure, and in toward
low pressure systems. The wind does not flow directly from
high pressure to low, but cycles instead from one to the other.
Due to the rotational forces of the earth (the Coriolis effect),
winds in the northern hemisphere rotate clockwise around
highs and counterclockwise around lows. The jet stream, trade
winds, and other wind currents guide weather systems on th
routes (Fig. 2).

Page 178 Performance Racing Tactics



### Page 3


Fig. 2 - The dominant force in our weather are the winds which
cycle counter clockwise around lows.

Fronts

Associated with weather systems are warm and cold
fronts, and areas of relative stability and instability. Fronts are
pressure gradients between air masses. Fronts bring changing
conditions. Itis therefore important to know when a frontal
passage is expected, and even better to know what sort of
‘weather changes the frontal passage will bring.

‘There are several types of fronts. A cold front is cold air
displacing warm, A warm front is a warmer air mass pushing
aside a colder air mass (Fig. 3). An occluded front is a mixing
area of three air masses. A stationary front occurs when two air
masses lie side by side, with no movement.

Stable & Unstable Conditions

‘When warm air sits atop cold air, the weather is stable and
winds are steady. These stable conditions often bring flat layers
of clouds—stratus clouds. Stable conditions also exist in the
center of a high, characterized by clear skies and a slowly
rising barometer.

When warm air is trapped beneath cool air it rises, and we
get unstable conditions and shifty winds. Cumulus clouds,
which build vertically due to rising air currents, are a sign of
unstable weather. Cold fronts are also characterized by unstable
winds. With the passage of a cold front the barometer will fall
and rise, and winds will shift. Another unstable region is the
center of a low, where winds cycle inward and upward.

‘The exact timing and movement of fronts is difficult to
predict. We can use the weather forecast as the basis for our
expectations, and then refine the predictions through observa-
tion of local conditions.

Chapter 13: Weather

Page 179



### Page 4


COLD

Fig. 3 - Cold fronts drive cold air under warm air, forcing the
warm air up. Warm fronts push cold air away by sliding over
the cold air.

The weather systems described to this point create what
We refer to as gradients winds, which are weather system
winds generated by differences in air pressure. Our racing
winds are a combination of these gradient winds and local
winds. Local winds include thermal winds created by the
heating and cooling of land near shore, as well as the imp:
local geography on the prevailing gradient breeze.

One challenge in localized forecasting is establishing
whether gradient or local forces will dominate our race area,
Our race day may be dominated by one, the other, or a mix of
the two. At times, the gradient wind will be displaced by a
local sea breeze as the day heats up. At other times, an advanc-

ct of

ing weather system will overwhelm local effects. What will
happen, and when, is hard to know. Sometimes the forec
accurate in every respect save timing, and the predicted shift
arrives shortly after the race day ends.

‘The challenge in a localized forecast is to apply local
weather information to the very small near coastal area in
which we race. Racing near shore, we must combine gradient
winds from weather systems with very localized effects, such
as the bending of winds near shore, and the impact of local
thermals. While we may make sport of mocking the local
forecasters, the truth is that their concerns are far different from
ours. The local farmers and pilots - and weather forecasters -
care little whether the wind shifts from 200° to 220°, while for
us, such a shift is a big deal. Subtle variations across the
course - an area of less than 10 square miles - likewise are of
consequence to only those few of us who define leisure as
going back and forth at 7 miles per hour.

While these very localized forecasts are a concern to very
few, there are sources of weather information specifically
geared to our concerns. Several commercial forecasters have
made it their business to provide just the type of forecast we
are after. Sample forecasts from Ken Campbell of Command-
ers’ Weather and Chris Bedford of Sailing Weather Services
are shown at the end of this chapter.

‘The very localized concerns for day racing contrast to the
bigger picture required to plan strategy for a distance race. In
these longer races astute forecasting can win races,

Here are some ideas for interpreting weather maps and
planning strategy over a distance raci

* Find more wind. There is more id near lows. Stay
away from high pressure, favor the side of the course
near low pressure.

Page 180 Performance Racing Tactics



### Page 5


oy <
iis,

Fig. 4 - The movement of weather systems also causes
persistent shifts. The direction of the shift depends on our
position relative to the system.

+ The wind will shift. The direction of the shift depends
on your position relative to the weather system, On the
north side of a low the wind backs to the left; on the
south side the wind veers to the right. (Fig. 4.)

+ You will get gradual shifts as weather systems move,
and big shifts as you cross a front.

* Distance racing along a coast requires that you consider
local thermal effects as well as gradient weather system
winds.

For more on distance racing strategy, I will refer you to
the Distance Racing section of Chapter 14, which includes this
cautionary note: Sail the wind, not the forecast.

Fig. 5 - Wind shear is the presence of one wind at the surface
and another wind aloft. The upper wind usually displaces the
lower wind.

A further understanding of weather systems, their origins,
movements, and associated fronts can help in understanding
and predicting local weather. While such a discussion is be-
yond the scope of this text, there are several excellent books
are available, including those by William Kotsch, John
Rousmaniere, and Alan Watts. We will focus our attention on
creating a local forecast to help us form our strategy.

Local Weather

Local winds mix with weather system winds to give us
our sailing breeze. There are several types of local weather
vents. In clear weather the daily cycle of heating and cooling,
of the land creates winds. During the day, a sea breeze devel-
‘ops as the air over the land warms and rises, and cool air is
drawn in from over the water. This wind will often die and then
reverse at night, as the land cools more quickly than the water.
Local geography can also change the course of the wind, and
local storms are not uncommon along the shore, where the mix
of temperatures creates instability.

Chapter 13: Weather Page 181



### Page 6


6a Ney o “Ue

Wind Shifts

Changing wind conditions result from a mix of influences.
Among them are general weather system movement, frontal
passages, down drafts in unstable weather, local geographic
events (hills, pavement, etc.), the contour of the shore, and
local sea breezes.

Wind shifts on the race course can occur in a number of
ways. The most conventional are oscillating shifis and persis-
tent shifts. Oscillating shifts swing back and forth like a pendu-
Jum and occur in a number of different weather patterns.
Oscillations occur below a march of cumulus clouds in the
clearing wind which follows the passage of a cold front. Oscil-
lations can also be caused by a geographic obstruction, as the
wind blows alternately around one side, and then the other, of a
hill or city sky line. A sea breeze will carry long steady oscilla-
tions in a sine-wave like pattern (Fig. 6a,b,c)

Ne

6c

Fig. 6 - Oscillating shifts swing back and forth. They are
common a - after cold fronts, b - occur around geographic
obstructions, or ¢ - come in waves over open water

Persistent shifts swing gradually in one direction: Clock-
wise or counterclockwise. These are caused by the gradual
displacement of one wind by another, or by the movement of a
weather system. A local sea breeze can build over the course of
the day and gradually displace the weather system wind. The
pattern reverses later in the day as the sea breeze fades (Fig. 7).

Another type of persistent shift is the gradual shift which
‘occurs as a weather system passes. On the north side of a low,
the wind gradually backs from south to east to north. On the
south side, it gradually veers (clocks) from south, to west, to
north (Fig. 4).

Often we do not get a pure form of either oscillating or
Persistent shifts, but instead get a mix of the two. Sometimes
‘we get mixed conditions, as two winds battle for dominance in
an area. A sea breeze might battle a prevailing weather system
wind but not have the strength to completely displace it. These

Page 182

Performance Racing Tactics



### Page 7


xt

Fig. 7- Persistent shifts swing gradually in one direction. They
arc often caused by the displacement of a weather system wind
by a local sea breeze.

are often difficult conditions, as the shifts will have little or no
tern. Eventually one of ‘the breezes will be dominant; but
while the battle rages, predicting the next shift can be a frus-
i essing game.
Pagveae gegen to the occasional radical shift which
‘suddenly and dramatically changes the wind direction. These
are associated with changes in ‘the weather, on a local or
‘weather system scale.

Shore Effects ’

‘A further complication of our Jocal sailing winds is the
effects of land on winds near shore. Winds at the surface are
slower and shifted due to friction of the ground. As the wind
passes from Jand to water, there is less friction. As aresult,
‘winds blowing nearly parallel tend to be funneled more paral-

Fig. 8 a,b- Winds blowing along shore are shifted more parallel
10 shore. Winds blowing offshore are shifted more
perpendicular.

lel to shore, and winds blowing off the land nearly perpendicu-
lar tend to shift more perpendicular to shore (Fig. 8a,b).

‘Another intriguing weather phenomenon is wind shear,
which is the presence of two different winds at different
heights. This is most common when the water is very cold and
smooth. A boundary layer of surface wind attached to the cold
‘water will be entirely different from the wind aloft. Usually the
wind aloft becomes dominant; but until the shear breaks, sail
trim and strategy can be baffling (Fig. 5).

Understanding the causes of local wind shifts can help us
predict what will happen next. With time and attention you can
learn to recognize local weather patterns. Our expectations for
the wind form the basis for our strategy. So the better our
forecasts, the better our strategy.

‘Chapter 13: Weather

Page 183



### Page 8


13.3 Current

Current is another ingredient in the weather in which we
sail. Currents result from a number of causes. The most pre-
dictable are tidal and river currents. Currents can also be wind
driven—moving with the wind when it blows hard, and revers-
ing as the winds diminish.

Predictable Currents

Tidal and river currents are quite predictable. Tidal cur-
rents vary over the duration of the race, and careful planning
for changing currents is essential. Obtain a set of local tide
tables and current charts, and match these up to your own
observations. River currents are more consistent, varying from
season to season. Over the duration of a race, they can be the
‘most predictable factor in our strategic planning.

Unpredictable Currents
Wind driven currents are less predictable than tidal and
river currents. They are found wherever the wind blows

< Fig. 9 - Wind creates
current. As the wind
blows it pushes water. As
the wind subsides the
current reverses,

> Fig. 10 - Current flows in
predictable ways: Faster in
deep water or constraints,
slower in shallows or under
points.

(Fig. 9). In the Great Lakes, wind driven currents are the most
‘common currents. In coastal areas, wind driven currents can
upset the regular tidal patterns. For example, a north wind can
push water out of Chesapeake Bay with an ebb, and delay or
even prevent a flood tide. An east or north east wind can create
a high tide surge in Long Island Sound two or three feet above
normal, and block the ebb. As these winds die, the subsequent
flood or ebb will be particularly strong.

How Current Flows

Current, we are told, runs faster in deep water. True
enough, to a point. Across a river or bay, the current will run
stronger in the deepest sections; but a shallow area along a
deep run can create accelerated current, just as a narrowing of a
channel can create faster currents. Currents run faster around
points, and slower in shallows. Below points, eddies can flow
opposite the prevailing current (Fig. 10).

Page 184 Performance Racing Tactics



### Page 9


Current

Fig, 11 - Our sailing wind is a sum of the current and the true
wind. The impact depends on the direction of the current and
‘our point of sail

13.4 Current and Sailing Wind

Curent a strategic factor not only in its own right, but
also because it changes our sailing wind. Our sailing wind is a
ne ofthe “rue wind (as fet by a boat at anchor) and the
svirront wind-—which runs opposite the current.

“The impact on our sailing wind varies with the direction
of the current. When true wind and current run together, the
ctront effectively diminishes the wind. When true wind and
cuTTent are opposed, the sailing wind is strengthened. When the
Current runs across true wind, our sailing wind is shifted
Mes me impact of current when sailing depends on our course.
For example, one knot of current flowing across a ten-knot
rnd wil shift the wind 6°. Figure 12 above shows the impact
On our sailing wind for various currents and points of sal.

Strategies for racing in current are covered inthe strategy
sections of Chapter 7 - Upwind Strategy, Chapter 9 - Reaching
Strategy & Tactics, and Chapter 10 - Running Strategy &
Tactics.

Sailing

find Wind Nee
NG

true b Sailing Wind

Wind

Current

Fig. 12 The current's impact on sailing wind is an important
strategic factor.

13.5 Conclusion

Weather forecasting is essential to our strategic planning,
‘The best predictor of the conditions you can expect during a
race are the observations you make during the hour prior to the
race. Use the broader forecast to adjust your expectations, but
beware—the broader forecast is not intended to forecast the
subtle but significant changes we may experience in the small
area in which we race, and furthermore—imagine this—the
forecast may be wrong!

One other caveat: Sail the wind, not the forecast. It is

common for the predicted weather to arrive sometime after the
winners have finished.

Chapter 13: Weaiher

Page 185



### Page 10


13.6 Sample Forecasts

This sample localized forecast was provided by Commanders’
Weather. Forecasts such as this can help in strategic planning
for the day. Note in particular the error factors which would

help in determining if the weather will pan out as forecast.

From: Commanders’ Weather Corp
154 Broad St, Suite 1517 Nashua, NH 03062
Tel: 603-882-6789, Fax: 603-882-6661
‘Commanders Weather @compuserve.com
Forecast area: Newport RI
Forecast for: Friday, June 1, 2001
Outlook for: Saturday/Sunday, June 2/3, 2001
Forecast prepared: 0700 edt Friday, June 1, 2001

Summary...

1) High pressure is centered over southern New England
this morning

a) high will be offshore Cape Cod by early afternoon and
will continue to move E during the PM

2) Intensifying low in southern Michigan will move N-NE
into Canada today

4) attached cold front will be slow to move east as another
storm in the northern Great Plains heads

SE towards southern Michigan

3) Warm front over the coastal Carolinas will move north
today which will cause increasing clouds
in Newport - especially this afternoon

4) Little wind early this morning, as would be expected
with high pressure overhead

a) light NW-N wind in the Bay and along the shoreline

») light W wind offshore will become very light NW-N
this morning

5)

ittle breeze the Ist half of this morning and what

breeze there is will be a NW-NE wind

6) Sea breeze will develop along the shoreline 1030-1200,
probably favoring 1200

) tough call on where it develops from, as it could be
anywhere from 140-220

») forecast will call for 160-200, favoring the S

7) Expecting 10-14 kts from 170-200 by 1300, 1400

4) more clouds there are, the more likely the wind will
favor 160 and 10 kts while sunshine will

favor further right and a litte stronger

8) Winds will build during the afternoon and will call for
13-17 kts by evening

a) A little left turn from 1600 on - this will be caused by
the high overcast clouds

9) Despite the left bias of the wind directions, the vertical
profiles suggest the puffs will favor the
right until the skies become cloudy late today

Wind forecast

Wind directions are TRUE, wind speed in kts, and time is edt
Offshore In the Bay
330-010/ 2-6 340-020/ 3-7
light/variable 290-010/ 1-5
bemg 160-200/ 3-7 _light/variable
180-210/ 8-12 160-190/ 6-10
180-200/10-14 180-200/ 8-12

: —— 170-190/11-15 180-200/10-14
1500: 170-190/11-15 170-190/10-15

‘Sunshine will favor a little further right and the higher end of
the wind speeds while cloudy skies will favor a litle further
left and the lower end of the wind speeds

1600: 160-180/12-16 160-180/11-16

1700: 150-170/13-17 160-180/12-17

Page 186 Performance Racing Tactics



### Page 11


General weather. .Sunshine will slowly give way to increasing
high clouds. Becoming cloudy late today with highs 65-70°T.

Error factor. ‘

1) Development of the sea breeze could be slower and this
will be the primary wind generator this
morning/midday

4) uncertain whether the sea breeze develops from the SW or
SE, but ultimately will favor 160-190 ;

by must have sunshine forthe sea breeze otherwise the winds
will be slower to develop late

morning/midday

2) Max right when wind speeds are 6+ kts will be 220

4) max eft when wind speeds are 6+ kts will be 140

3) Dont think wind speeds will be over 18 kts by evening

4) better chance wind speeds will be a litle lighter than
forecast as compared to stronger than forecast

Outlook for Saturday, June 2, 2001

1) Unsettled and potentially very windy

2) Litle low along the mid-Atlantic coast will move NE with
the warm front, reaching the interior of
Massachusetts by evening

4) many showers/thunderstorms/fog and heavy rain with
preceding the warm front

}b) maybe some clearing, but more scattered thunderstorms/
patchy fog once the warm front passes during the after-
noon

3) Lots of wind potential as computer models are showing
35-45 kts at 1500-2000 ft above the ground

a) sunshine or t-storms could bring these strong winds down

44) Timing will be difficult, but will cal for

a) SE winds up to 20-25 kts and squalls 30+ thru mid-
morning

b) softer conditions midday as the warm front lifts north-
ward, maybe 10-15 kts, but still squally

c) fresher S-SW winds to finish the day, maybe 15-20 kts
and still squally

0900: 140-160/20-25, squalls

1100: 150-180/16-22, squalls

1300: 170-190/11-17

1500: 180-200/12-18, squalls 25+

1700: 190-210/15-20, squalls 30+

General weather... Mostly cloudy with areas of dense fog.
AA little afternoon sunshine possible. Scattered showers and
thundershowers likely. Muggy with highs 66-70, 19-21C.

0+
0+

Outlook for Sunday, June 3, 2001

1) Low pressure from near Toronto to northern New
England

a) cold front expected to pass early afternoon

2) S winds up to 16-22 kts and squally will precede the
cold front

a) a lull as the cold front pa
) potential for 15-20 kts and gusts to 2:
after the cold front passes

skies clear

(0900: 180-200/12-18

1100: 190-210/16-22

1300: 230-270/ 9-15, but squally

1500: 250-270/12-18

1700: 270-290/15-20, gusts 25

General weather...Fog mixed with scattered showers/
thunderstorms. Clearing in the afternoon with highs near 70f.

Regards, Ken Campbell

Chapter 13: Weather

Page 187



### Page 12


This forecast was provided by Chris Bedford of Sailing Weather
Services 617-721-5417 sailwx@mediaone.net

Once again, note the Hedge to help in interpreting the validity
of the forecast through the day.

Sailing Weather Forecast
Nautor’s Swan American Regatta - Newport, RI
Issued: 0700 EDT Tuesday, July 10, 2001

NOTICE: As of 0700 EDT, there are no active advisories
‘or warnings for the sailing area. There is a chance of strong to
severe thunderstorms in of close to the sailing area this after-
noon. Skippers should monitor NOAA on your VHF for up-to-
date official warnings and advisories.

The detailed forecast table refers to offshore courses.
Where winds within Narragansett Bay are expected to differ
substantially from offshore, comments will attempt to quantify
this difference.

Synopsis: Today should find a stronger, more consistent
sea breeze over the sailing area with improved gradient condi-
tions and good thermal forcing. Winds could build to over 20
this afternoon, though the cool water will cause substantial
shear from top to bottom of the rig.

‘The weather map continues to paint a fairly complicated
pressure pattern. A low over northern Quebec (1002MB)
extends a cold front into the eastern Great Lakes. Ahead of the
front, a weak low pressure area (1008MB) is evident just
northeast of Boston, moving slowly northeast. The front is
moving gradually east and is expected to lie from about Boston
to Providence and then west to a low near Detroit by sunset this
evening.

Ahead of the front, the gradient will start to increase from
the southwest this morning. Upper level winds are west and
northwest. This orientation of surface gradient from the south-

west and upper level wind parallel or slightly offshore is
favorable for a strong, gradient-assisted sea breeze over the
region. The sea breeze onset will be earlier and stronger than
yesterday.

Current Conditions: Some light fog is around this
moming. Most visibility reports are better than 2 miles, how-
ever isolated locations are probably seeing thicker fog with
visibility below 1 mile at times. The fog is generally thinning
with time. Radar shows some showers moving east off Cape
Cod and not a factor. Some showers are also located over
upstate New York ahead of the cold front, These are moving
east but weakening with time. Some debris clouds from these
dying showers is spreading east into southern New England as
of 0700 EDT and may pass over Newport late this morning.

Winds are light SSW to WSW across the area. All loca-
tions are reporting less than 7 knot ly. Exception is
Buzzards Bay tower which is SW at 15 this morning. Thi
location often accelerates at sunrise, so this is not unusual.
Winds have been trending a litle right most recently and align
fairly well with the surface pressure gradient.

Forecast Discussion: Mainly SW winds this morning
although there may be some brief NW winds over the Bay
through mid-morning. Offshore, the SW sea breeze will slowly
back left while filling through early afternoon. Then a gradual
right trend is expected to begin by mid-afternoon, Wind speeds
will build quickly through late morning, then plateau for an
hour or two before building again through the rest of the
afternoon. A steadier increase is expected up the Bay, with the
sea breeze more variable (bigger gust to lull ratio) and shifty
compared with offshore.

Weather: Fog will lift to hazy cloud cover this morning.
Some high-level debris cloud will likely pass over the area
from west to east later this morning, but this shouldn't be

Page 188 es Performance Racing Tactics



### Page 13


significant, Cumulus will start to develop onshore from late
morning and persist through the afternoon.

More importantly, showers and thunderstorms are ex-
pected to develop along and ahead of the approaching cold
front and move southeast toward the coast this afternoon. Some
of the thunderstorms could be strong or severe with gale force
‘wind gusts, abrupt shifts in direction, frequent lightning and
even some hail. Although most of the heavy storm activity
should hold off until after today’s sailing complete - reaching
the coast around 1900 EDT, can’t rule out thunderstorms in the
area by mid-afternoon. Keep a close eye to the northwest.

Maximum Temperature: Once the fog lifts, temperatures
should rise into to near 80F at the coast before cooling several
degrees with the sea breeze. Inland temperatures will rise to the
middle and even some upper 80's today.

Seas: Offshore: Slight south swell, otherwise less than 1
ft this morning, increasing to a rough 2 to 3 ft chop this after-
noon. Narragansett Bay: Nearly flat calm this morning building
toa | to2 ft chop this afternoon, higher chop near the entrance.

Wind Forecast for Today (07/10/2001):

Wind Speed Wind Direction (True)
‘Time Mean Range — Mean Range
09 = 8 5-10 220-205-250 ..more right offshore
10 10. 7-12. -215200-235....left trend offshore
HM 12-10-14 205
12 14 12-16 200-185-215
13. 16 © 13-18 200-185-215
14 18 15-20 205-190-220 ...gusts over 20 poss
15 18 15-21 210 195-225
16 19 16-22 215 200-230
17 19 16-23 220-205-235 ..var near t-storms
18 19 16-23 220-210-240

Hedge: 1) Note the Right to left trend during the building
phase of the sea breeze followed by the slower left to
right trend in the afternoon with mature sea breeze and
gradient mixing

2) think there will be a fair bit of shear from top to bottom
of the rig today. This will be quite pronounced during the
building phase of the sea breeze and offshore. Once the
breeze is fully developed, the shear should be less. Also,
the warmer water in the Bay will allow the stronger
winds to mix down to the surface, so shear effects will be
minimized.

3) Wind speed ranges are wider than I'd like, but this reflects
uncertainty related to the magnitude of shear and the
gradient strength. The gradient is starting out weaker this
morning. Watching that higher wind speed to the east of
Newport in case it wants to spread west with the develop-
ing sea breeze faster than what's shown in the table.

4) Front is forecast to be the focal point for developing
thunderstorms today. Front is just passing Buffalo at the
moment and will be to the southern New England coast
by 2000 EDT. Thunderstorms will spread out ahead of
the front. Should storms threaten before the end of racing,
prepare for very strong winds gusts arriving from up to
90 degrees right of the sea breeze wind direction. If still
out there following passage of storms, winds will become
very light and variable before refilling from the WSW.

Chri
5417 si

Bedford, CCM Sailing Weather Services 617-721
|wx@ mediaone.net

Chapter 13: Weather Page 189

